# FX Drop installer - run via "Install FX Drop.cmd"
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$ElectronVersion = '44.5.1'
$ElectronSha256  = '9B382492DCFEE91F8F9E92C91F7972550A1B95D2299CAC72279DAB33A600D7DB'

$here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSrc  = Join-Path $here 'app'
$dest    = Join-Path $env:LOCALAPPDATA 'Programs\FX Drop'
$cache   = Join-Path $env:LOCALAPPDATA 'FX Drop Setup'
$exe     = Join-Path $dest 'FX Drop.exe'

function Step($text) { Write-Host ''; Write-Host "  $text" -ForegroundColor Cyan }
function Done($text) { Write-Host "    $text" -ForegroundColor DarkGray }

Write-Host ''
Write-Host '  FX Drop setup' -ForegroundColor White
Write-Host '  -------------' -ForegroundColor DarkGray

if (-not (Test-Path (Join-Path $appSrc 'main.js'))) {
  throw "Can't find the 'app' folder next to this installer. Unzip the whole FX Drop Setup folder first."
}

Step 'Closing FX Drop if it is running'
Get-Process -Name 'FX Drop' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 600
Done 'ok'

# ---------------------------------------------------------------- runtime
New-Item -ItemType Directory -Force -Path $cache | Out-Null
$zip = Join-Path $cache "electron-v$ElectronVersion-win32-x64.zip"
$marker = Join-Path $dest ".runtime-$ElectronVersion"

if (-not (Test-Path $marker)) {
  $ok = (Test-Path $zip) -and ((Get-FileHash $zip -Algorithm SHA256).Hash -eq $ElectronSha256)
  if (-not $ok) {
    Step 'Downloading the app runtime (about 110 MB, one time only)'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $url = "https://github.com/electron/electron/releases/download/v$ElectronVersion/electron-v$ElectronVersion-win32-x64.zip"
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash
    if ($hash -ne $ElectronSha256) {
      Remove-Item $zip -Force
      throw 'The download looks damaged (checksum mismatch). Run the installer again.'
    }
    Done 'downloaded and verified'
  }

  Step 'Unpacking'
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
  $tmp = Join-Path $cache 'unpack'
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $tmp)
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Move-Item $tmp $dest
  Rename-Item (Join-Path $dest 'electron.exe') 'FX Drop.exe'
  $defaultApp = Join-Path $dest 'resources\default_app.asar'
  if (Test-Path $defaultApp) { Remove-Item $defaultApp -Force }
  New-Item -ItemType File -Force -Path $marker | Out-Null
  Done "installed to $dest"
}

# ---------------------------------------------------------------- app files
Step 'Copying FX Drop'
$appDest = Join-Path $dest 'resources\app'
if (Test-Path $appDest) { Remove-Item $appDest -Recurse -Force }
# leftovers from updates of older versions
foreach ($left in @('.new', '.old', '.failed')) {
  $p = $appDest + $left
  if (Test-Path $p) { Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue }
}
Copy-Item $appSrc $appDest -Recurse -Force
Get-ChildItem $appDest -Recurse -File | ForEach-Object { Unblock-File $_.FullName -ErrorAction SilentlyContinue }
Done 'ok'

# ---------------------------------------------------------------- Premiere extension (the app also does this on start)
Step 'Setting up the Premiere Pro extension'
foreach ($v in 9..14) {
  $key = "HKCU:\Software\Adobe\CSXS.$v"
  if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
  Set-ItemProperty -Path $key -Name 'PlayerDebugMode' -Value '1' -Type String
}
$cepDest = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.fxdrop'
if (Test-Path $cepDest) { Remove-Item $cepDest -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Split-Path $cepDest) | Out-Null
Copy-Item (Join-Path $appSrc 'cep') $cepDest -Recurse -Force
Done 'ok'

# ---------------------------------------------------------------- shortcuts
Step 'Adding FX Drop to the Start menu'
$programs = [Environment]::GetFolderPath('Programs')
$lnkPath = Join-Path $programs 'FX Drop.lnk'
$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut($lnkPath)
$lnk.TargetPath = $exe
$lnk.WorkingDirectory = $dest
$lnk.IconLocation = (Join-Path $appDest 'assets\icon.ico') + ',0'
$lnk.Description = 'Search and drop FX into Premiere Pro'
$lnk.Save()
Done 'ok'

Step 'Starting FX Drop'
Start-Process -FilePath $exe
Done 'FX Drop is running - look for the drop icon in the system tray.'

Write-Host ''
Write-Host '  All set. Restart Premiere Pro once, then press Ctrl+Space over the timeline.' -ForegroundColor Green
Write-Host ''
Start-Sleep -Seconds 4
