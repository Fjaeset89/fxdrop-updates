@echo off
title Installing FX Drop
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Something went wrong - see the message above.
  pause
)
