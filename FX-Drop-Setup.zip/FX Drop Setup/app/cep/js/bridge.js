/* FX Drop bridge — runs inside Premiere (CEP, Node enabled).
   Listens on 127.0.0.1 only and forwards commands from the FX Drop app to host.jsx. */
(function () {
  'use strict';
  var http = require('http');
  var fs = require('fs');
  var path = require('path');
  var os = require('os');
  var crypto = require('crypto');

  var VERSION = '1.0.0';
  var PORT = 47321;
  var cep = window.__adobe_cep__;
  var role = document.documentElement.getAttribute('data-role') || 'bridge';

  var extRoot = decodeURI(cep.getSystemPath('extension')).replace(/^file:\/{2,3}/, '');
  if (/^\/[A-Za-z]:/.test(extRoot)) extRoot = extRoot.slice(1);
  var dataDir = path.join(process.env.APPDATA || os.homedir(), 'FXDrop');
  var infoFile = path.join(dataDir, 'bridge.json');

  var listeners = [];
  var state = { listening: false, role: role, lastCommand: null, lastError: null, commands: 0 };
  function emit() { listeners.forEach(function (fn) { try { fn(state); } catch (e) {} }); }
  window.FXDBridge = { state: state, onChange: function (fn) { listeners.push(fn); fn(state); }, run: run };

  function readInfo() {
    try { return JSON.parse(fs.readFileSync(infoFile, 'utf8')); } catch (e) { return null; }
  }
  function ensureToken() {
    try { fs.mkdirSync(dataDir, { recursive: true }); } catch (e) {}
    var info = readInfo();
    if (info && info.token) return info.token;
    return crypto.randomBytes(24).toString('hex');
  }
  var token = ensureToken();

  function evalJSX(code) {
    return new Promise(function (resolve) { cep.evalScript(code, function (r) { resolve(r); }); });
  }
  function literal(v) {
    return JSON.stringify(v === undefined ? {} : v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  }

  var hostPath = path.join(extRoot, 'jsx', 'host.jsx').replace(/\\/g, '/');
  var loaded = evalJSX('try{ $.evalFile(' + JSON.stringify(hostPath) + '); "ok" }catch(e){ String(e) }')
    .then(function () { return evalJSX('FXD.dispatch("init", ' + literal({ extRoot: extRoot }) + ')'); })
    .then(function () {
      if (role === 'bridge') return evalJSX('try{ app.setExtensionPersistent("com.fxdrop.bridge", 1); }catch(e){}');
    });

  // Premiere runs one script at a time — keep commands in order
  var queue = Promise.resolve();
  function reloadHost() {
    return evalJSX('try{ $.evalFile(' + JSON.stringify(hostPath) + '); FXD.dispatch("ping", {}) }catch(e){ String(e) }');
  }

  function run(fn, args) {
    var job = queue.then(function () { return loaded; }).then(function () {
      // the app asks for this after an update, so new Premiere-side code loads without a restart
      if (fn === '__reloadHost') return reloadHost();
      return evalJSX('FXD.dispatch(' + JSON.stringify(fn) + ', ' + literal(args) + ')');
    }).then(function (raw) {
      state.commands++;
      state.lastCommand = { fn: fn, at: Date.now() };
      var out;
      if (!raw || raw === 'EvalScript error.') {
        out = { ok: false, code: 'SCRIPT_ERROR', error: 'Premiere reported a script error.' };
      } else {
        try { out = JSON.parse(raw); } catch (e) { out = { ok: false, code: 'BAD_REPLY', error: String(raw).slice(0, 300) }; }
      }
      if (!out.ok) state.lastError = { fn: fn, error: out.error, at: Date.now() };
      emit();
      return out;
    });
    queue = job.catch(function () {});
    return job;
  }

  function send(res, status, obj) {
    var body = JSON.stringify(obj);
    res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(body);
  }

  var server = http.createServer(function (req, res) {
    var host = String(req.headers.host || '');
    if (host !== '127.0.0.1:' + PORT && host !== 'localhost:' + PORT) return send(res, 403, { ok: false, error: 'bad host' });
    if (req.headers['x-fxdrop-token'] !== token) return send(res, 401, { ok: false, error: 'bad token' });
    if (req.method === 'GET' && req.url === '/health') {
      return send(res, 200, { ok: true, version: VERSION, role: role });
    }
    if (req.method !== 'POST' || req.url !== '/run') return send(res, 404, { ok: false, error: 'not found' });
    var chunks = [];
    var size = 0;
    req.on('data', function (c) {
      size += c.length;
      if (size > 20 * 1024 * 1024) { req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', function () {
      var msg;
      try { msg = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { return send(res, 400, { ok: false, error: 'bad json' }); }
      if (!msg || typeof msg.fn !== 'string') return send(res, 400, { ok: false, error: 'missing fn' });
      run(msg.fn, msg.args || {}).then(function (out) { send(res, 200, out); }, function (e) {
        send(res, 200, { ok: false, code: 'BRIDGE_ERROR', error: String(e && e.message || e) });
      });
    });
  });

  server.on('error', function (e) {
    state.listening = false;
    state.serverError = e.code === 'EADDRINUSE' ? 'in-use' : String(e.message || e);
    emit();
  });
  server.listen(PORT, '127.0.0.1', function () {
    state.listening = true;
    try {
      fs.writeFileSync(infoFile, JSON.stringify({ port: PORT, token: token, version: VERSION, role: role, pid: process.pid, startedAt: new Date().toISOString() }, null, 2));
    } catch (e) {}
    emit();
  });

  window.addEventListener('unload', function () { try { server.close(); } catch (e) {} });
})();
