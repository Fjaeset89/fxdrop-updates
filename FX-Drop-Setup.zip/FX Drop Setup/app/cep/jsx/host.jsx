/*  FX Drop — Premiere Pro side (ExtendScript, ES3 only).
    Everything is called through FXD.dispatch(name, argsObject) and returns a JSON string:
      { ok: true, result: ... }  or  { ok: false, error: "...", code: "..." }
*/

$.global.FXD = $.global.FXD || {};

(function (F) {
    F.version = "1.0.4";
    var TPS = 254016000000;
    var VIDEO = "Video", AUDIO = "Audio";

    // ------------------------------------------------------------------ JSON (stringify only)
    function quote(s) {
        return '"' + String(s).replace(/[\\"\u0000-\u001f\u2028\u2029]/g, function (c) {
            var m = { '"': '\\"', '\\': '\\\\', '\b': '\\b', '\f': '\\f', '\n': '\\n', '\r': '\\r', '\t': '\\t' };
            if (m[c]) { return m[c]; }
            var h = c.charCodeAt(0).toString(16);
            return '\\u' + ('0000' + h).slice(-4);
        }) + '"';
    }
    function stringify(v) {
        var t = typeof v;
        if (v === null || t === "undefined") { return "null"; }
        if (t === "number") { return isFinite(v) ? String(v) : "null"; }
        if (t === "boolean") { return v ? "true" : "false"; }
        if (t === "string") { return quote(v); }
        if (v instanceof Array) {
            var a = [];
            for (var i = 0; i < v.length; i++) { a.push(stringify(v[i])); }
            return "[" + a.join(",") + "]";
        }
        if (t === "object") {
            var o = [];
            for (var k in v) {
                if (v.hasOwnProperty(k) && typeof v[k] !== "function") { o.push(quote(k) + ":" + stringify(v[k])); }
            }
            return "{" + o.join(",") + "}";
        }
        return "null";
    }
    F.stringify = stringify;

    function Fail(code, message) { this.code = code; this.message = message; }

    F.dispatch = function (name, args) {
        try {
            if (!F.cmd[name]) { throw new Fail("UNKNOWN", "Unknown command: " + name); }
            var r = F.cmd[name](args || {});
            return stringify({ ok: true, result: r });
        } catch (e) {
            var out = { ok: false, error: (e && e.message) ? String(e.message) : String(e), code: (e && e.code) ? e.code : "ERROR" };
            if (e && e.line) { out.line = e.line; }
            return stringify(out);
        }
    };

    // ------------------------------------------------------------------ helpers
    function sec(t) {
        if (t === null || t === undefined) { return null; }
        if (typeof t === "number") { return t; }
        if (typeof t.seconds === "number") { return t.seconds; }
        return Number(t.ticks) / TPS;
    }
    function timeAt(seconds) {
        var t = new Time();
        t.ticks = String(Math.round(seconds * TPS));
        return t;
    }
    function ticksStr(seconds) { return String(Math.round(seconds * TPS)); }
    function now() { return new Date().getTime(); }
    function lower(s) { return String(s || "").toLowerCase(); }
    function trim(s) { return String(s || "").replace(/^\s+|\s+$/g, ""); }
    function normPath(p) { return lower(String(p || "").replace(/\//g, "\\")); }

    function seqOrFail() {
        if (!app.project) { throw new Fail("NO_PROJECT", "Open a project in Premiere first."); }
        var seq = app.project.activeSequence;
        if (!seq) { throw new Fail("NO_SEQUENCE", "Open a sequence in the timeline first."); }
        return seq;
    }
    function frameSeconds(seq) {
        try { var tb = Number(seq.timebase); if (tb > 0) { return tb / TPS; } } catch (e) {}
        return 1 / 30;
    }
    function ensureQE() { if (typeof qe === "undefined" || !qe) { app.enableQE(); } }

    function isLocked(track) {
        try { return !!track.isLocked(); } catch (e) { return false; }
    }
    function setLocked(track, on) {
        try { track.setLocked(on ? 1 : 0); return true; } catch (e) {}
        try { track.setLocked(!!on); return true; } catch (e2) {}
        return false;
    }
    function trackFree(track, s, e, eps) {
        var clips = track.clips;
        for (var i = 0; i < clips.numItems; i++) {
            var c = clips[i];
            var cs = sec(c.start), ce = sec(c.end);
            if (cs < e - eps && ce > s + eps) { return false; }
        }
        return true;
    }
    function findPlaced(track, nodeId, startSec, tol) {
        var clips = track.clips;
        for (var i = clips.numItems - 1; i >= 0; i--) {
            var c = clips[i];
            var nid = null;
            try { nid = c.projectItem.nodeId; } catch (e) {}
            if (nid === nodeId && Math.abs(sec(c.start) - startSec) <= tol) { return c; }
        }
        return null;
    }
    function trackLabel(type, index) { return (type === AUDIO ? "A" : "V") + (index + 1); }

    // ------------------------------------------------------------------ tracks
    // Fingerprint of each track (name + clips) so we can see where a new track went
    function trackSigs(coll) {
        var out = [];
        for (var i = 0; i < coll.numTracks; i++) {
            var t = coll[i], ids = [];
            try { for (var c = 0; c < t.clips.numItems; c++) { ids.push(t.clips[c].nodeId); } } catch (e) {}
            var nm = "";
            try { nm = String(t.name); } catch (e2) {}
            if (/^(audio|video|lyd)\s*\d+$/i.test(nm)) { nm = ""; } // default names renumber themselves
            out.push(nm + "|" + ids.join(","));
        }
        return out;
    }
    function removeTrackAt(seq, type, k) {
        var tries = [
            function () { ensureQE(); var q = qe.project.getActiveSequence(); if (type === VIDEO) { q.removeVideoTrack(k); } else { q.removeAudioTrack(k); } },
            function () { if (type === VIDEO) { seq.deleteVideoTrackAt(k); } else { seq.deleteAudioTrackAt(k); } },
            function () { (type === VIDEO ? seq.videoTracks : seq.audioTracks).deleteTrack(k); }
        ];
        for (var i = 0; i < tries.length; i++) {
            var before = (type === VIDEO ? seq.videoTracks : seq.audioTracks).numTracks;
            try { tries[i](); } catch (e) {}
            if ((type === VIDEO ? seq.videoTracks : seq.audioTracks).numTracks < before) { return true; }
        }
        return false;
    }

    // Adds ONE track at the far end: audio tracks only ever go at the bottom (below the
    // last audio track), video tracks only ever on top. Every method is checked after it
    // runs; a track that lands anywhere else is removed again and the next method tried.
    function addTrack(seq, type) {
        var coll = function () { return type === VIDEO ? seq.videoTracks : seq.audioTracks; };
        var n = coll().numTracks;
        var tries = type === VIDEO ? [
            function () { seq.insertVideoTrackAt(n, 1); },
            function () { ensureQE(); qe.project.getActiveSequence().addTracks(1, n, 0, 0, 1, 0, 0); },
            function () { seq.addTrack("video"); }
        ] : [
            function () { seq.insertAudioTrackAt(n, 1); },
            function () { ensureQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, n, 0, 0); },
            function () { ensureQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, n, 1, 0, 0); },
            function () { seq.addTrack("audio", 1); }
        ];
        for (var i = 0; i < tries.length; i++) {
            var before = trackSigs(coll());
            try { tries[i](); } catch (e) {}
            var after = trackSigs(coll());
            if (after.length <= before.length) { continue; }
            var ok = after.length === before.length + 1;
            for (var k = 0; ok && k < before.length; k++) { if (after[k] !== before[k]) { ok = false; } }
            if (ok) { return true; }
            // landed in the wrong place (or more than one track): put things back
            for (var j = 0; j < after.length; j++) {
                if (j >= before.length || after[j] !== before[j]) {
                    removeTrackAt(seq, type, j);
                    break;
                }
            }
            while (coll().numTracks > before.length) {
                if (!removeTrackAt(seq, type, coll().numTracks - 1)) { break; }
            }
        }
        return false;
    }

    // Lowest unlocked audio track that is empty over [s, e]
    function pickAudioTrack(seq, s, e, eps) {
        var tr = seq.audioTracks;
        for (var i = 0; i < tr.numTracks; i++) {
            if (!isLocked(tr[i]) && trackFree(tr[i], s, e, eps)) { return i; }
        }
        return -1;
    }
    // First unlocked video track above everything that occupies [s, e]
    function pickVideoTrackAbove(seq, s, e, eps) {
        var tr = seq.videoTracks;
        var top = -1;
        for (var i = 0; i < tr.numTracks; i++) {
            if (!trackFree(tr[i], s, e, eps)) { top = i; }
        }
        for (var j = top + 1; j < tr.numTracks; j++) {
            if (!isLocked(tr[j]) && trackFree(tr[j], s, e, eps)) { return j; }
        }
        return -1;
    }
    function ensureAudioTrack(seq, s, e, eps, report) {
        var idx = pickAudioTrack(seq, s, e, eps);
        if (idx < 0) {
            if (!addTrack(seq, AUDIO)) { throw new Fail("TRACK_ADD_FAILED", "Every audio track is busy here and Premiere wouldn't add a new one."); }
            report.createdTrack = true;
            idx = pickAudioTrack(seq, s, e, eps);
        }
        if (idx < 0) { throw new Fail("NO_FREE_TRACK", "Couldn't find a free audio track."); }
        return idx;
    }
    function ensureVideoTrack(seq, s, e, eps, report) {
        var idx = pickVideoTrackAbove(seq, s, e, eps);
        if (idx < 0) {
            if (!addTrack(seq, VIDEO)) { throw new Fail("TRACK_ADD_FAILED", "Every video track is busy here and Premiere wouldn't add a new one."); }
            report.createdTrack = true;
            idx = pickVideoTrackAbove(seq, s, e, eps);
        }
        if (idx < 0) { throw new Fail("NO_FREE_TRACK", "Couldn't find a free video track."); }
        return idx;
    }

    // ------------------------------------------------------------------ project items
    function findBin(parent, name) {
        for (var i = 0; i < parent.children.numItems; i++) {
            var c = parent.children[i];
            if (c && c.type === ProjectItemType.BIN && c.name === name) { return c; }
        }
        return null;
    }
    function ensureBin(parent, name) {
        var b = findBin(parent, name);
        if (b) { return b; }
        parent.createBin(name);
        b = findBin(parent, name);
        return b || parent;
    }
    function itemByPath(bin, p, depth) {
        if (depth > 12 || !bin) { return null; }
        for (var i = 0; i < bin.children.numItems; i++) {
            var c = bin.children[i];
            if (!c) { continue; }
            if (c.type === ProjectItemType.BIN) {
                var f = itemByPath(c, p, depth + 1);
                if (f) { return f; }
            } else {
                var mp = null;
                try { mp = c.getMediaPath(); } catch (e) {}
                if (mp && normPath(mp) === p) { return c; }
            }
        }
        return null;
    }
    function findExistingItem(path) {
        var p = normPath(path);
        try {
            var hits = app.project.rootItem.findItemsMatchingMediaPath(path, 1);
            if (hits) {
                for (var i = 0; i < hits.length; i++) {
                    var mp = null;
                    try { mp = hits[i].getMediaPath(); } catch (e) {}
                    var hn = String(hits[i].name);
                    if (/ \((picture|sound)\)$/.test(hn)) { continue; }
                    if (mp && normPath(mp) === p) { return hits[i]; }
                }
            }
        } catch (e2) {}
        return null;
    }
    function getOrImport(path, binName) {
        var f = new File(path);
        if (!f.exists) { throw new Fail("MISSING_FILE", "That file is gone from disk: " + path); }
        var item = findExistingItem(path);
        if (item) { return item; }
        var root = ensureBin(app.project.rootItem, "FX Drop");
        var bin = ensureBin(root, binName);
        app.project.importFiles([f.fsName], true, bin, false);
        item = itemByPath(bin, normPath(f.fsName), 0) || findExistingItem(f.fsName) || itemByPath(app.project.rootItem, normPath(f.fsName), 0);
        if (!item) { throw new Fail("IMPORT_FAILED", "Premiere couldn't import " + f.displayName + "."); }
        return item;
    }
    function itemDuration(item, kind) {
        var best = 0;
        var types = kind === "audio" ? [2, 4, undefined] : [1, 4, undefined];
        for (var i = 0; i < types.length; i++) {
            try {
                var ip = types[i] === undefined ? item.getInPoint() : item.getInPoint(types[i]);
                var op = types[i] === undefined ? item.getOutPoint() : item.getOutPoint(types[i]);
                var d = sec(op) - sec(ip);
                if (d > best) { best = d; }
            } catch (e) {}
        }
        return best;
    }

    // ------------------------------------------------------------------ placement
    function placeOn(track, item, startSec) {
        var forms = [
            function () { track.overwriteClip(item, timeAt(startSec)); },
            function () { track.overwriteClip(item, startSec); },
            function () { track.overwriteClip(item, ticksStr(startSec)); }
        ];
        var tol = 0.02;
        for (var i = 0; i < forms.length; i++) {
            var before = track.clips.numItems;
            try { forms[i](); } catch (e) {}
            var c = findPlaced(track, item.nodeId, startSec, tol + 0.05);
            if (c) { return c; }
            if (track.clips.numItems !== before) { break; }
        }
        return findPlaced(track, item.nodeId, startSec, 0.1);
    }

    // Picture-only / sound-only subclips let a visual and its sound land on exactly the
    // tracks we pick, without Premiere auto-placing (or adding tracks for) the other half.
    var PART_SUFFIX = { video: " (picture)", audio: " (sound)" };
    var subclipFlip = false; // set if this build swaps createSubClip's takeVideo/takeAudio
    function findPart(item, want) {
        var name = item.name + PART_SUFFIX[want];
        var mp = null;
        try { mp = normPath(item.getMediaPath()); } catch (e) {}
        function walk(bin, depth) {
            if (depth > 12 || !bin) { return null; }
            for (var i = 0; i < bin.children.numItems; i++) {
                var c = bin.children[i];
                if (!c) { continue; }
                if (c.type === ProjectItemType.BIN) { var f = walk(c, depth + 1); if (f) { return f; } continue; }
                if (c.name === name) {
                    var cp = null;
                    try { cp = normPath(c.getMediaPath()); } catch (e2) {}
                    if (!mp || cp === mp) { return c; }
                }
            }
            return null;
        }
        return walk(findBin(app.project.rootItem, "FX Drop"), 0) || walk(app.project.rootItem, 0);
    }
    function makePart(item, want) {
        var ip = 0, op = 0;
        try { ip = sec(item.getInPoint()); op = sec(item.getOutPoint()); } catch (e) {}
        if (!(op > ip)) { return null; }
        var takeV = want === "video" ? 1 : 0, takeA = want === "video" ? 0 : 1;
        if (subclipFlip) { var t = takeV; takeV = takeA; takeA = t; }
        var name = item.name + PART_SUFFIX[want];
        var sc = null;
        try { sc = item.createSubClip(name, timeAt(ip), timeAt(op), 0, takeV, takeA); } catch (e1) {}
        if (!sc) { try { sc = item.createSubClip(name, ticksStr(ip), ticksStr(op), 0, takeV, takeA); } catch (e2) {} }
        if (!sc) { sc = findPart(item, want); }
        return sc;
    }
    function removeItem(it) {
        try {
            var root = ensureBin(app.project.rootItem, "FX Drop");
            var trash = ensureBin(root, "_remove");
            it.moveBin(trash);
            trash.deleteBin();
        } catch (e) {}
    }
    // Places only the picture (want "video") or only the sound (want "audio") of item.
    function placePart(seq, want, index, item, startSec) {
        var tracks = want === "video" ? seq.videoTracks : seq.audioTracks;
        var other = want === "video" ? seq.audioTracks : seq.videoTracks;
        var part = findPart(item, want);
        for (var attempt = 0; attempt < 2; attempt++) {
            if (!part) { part = makePart(item, want); }
            if (!part) { break; }
            var c = placeOn(tracks[index], part, startSec);
            if (c) {
                removeStrays(other, part.nodeId, startSec, -1);
                return c;
            }
            // nothing landed: this build likely swaps the take flags — rebuild the part the other way
            removeItem(part);
            part = null;
            subclipFlip = !subclipFlip;
        }
        return null;
    }

    function selectionSnapshot(seq) {
        var out = [];
        try {
            var s = seq.getSelection();
            for (var i = 0; i < s.length; i++) { out.push(s[i]); }
        } catch (e) {}
        return out;
    }
    function restoreSelection(seq, items) {
        try {
            var cur = seq.getSelection();
            for (var i = 0; i < cur.length; i++) { try { cur[i].setSelected(0, 0); } catch (e) {} }
            for (var j = 0; j < items.length; j++) { try { items[j].setSelected(1, j === items.length - 1 ? 1 : 0); } catch (e2) {} }
        } catch (e3) {}
    }

    // Removes stray copies of item on tracks other than keepIndex (linked-audio safety net)
    function removeStrays(tracks, nodeId, startSec, keepIndex) {
        var removed = 0;
        for (var t = 0; t < tracks.numTracks; t++) {
            if (t === keepIndex) { continue; }
            var c = findPlaced(tracks[t], nodeId, startSec, 0.05);
            if (c) { try { c.remove(false, false); removed++; } catch (e) {} }
        }
        return removed;
    }

    // ------------------------------------------------------------------ effects
    // Start time (seconds) of a QE track item, or null if this Premiere build doesn't expose it
    function qeStart(q) {
        var s = null;
        try { s = q.start; } catch (e) { return null; }
        if (s === null || s === undefined) { return null; }
        if (typeof s === "number") { return s; }
        try {
            if (s.ticks !== undefined && s.ticks !== null && String(s.ticks) !== "") { return Number(s.ticks) / TPS; }
            if (s.secs !== undefined) { return Number(s.secs); }
            if (s.seconds !== undefined) { return Number(s.seconds); }
        } catch (e2) {}
        return null;
    }

    // Fast path: QE items on a track are in time order, so find the clip by its start time
    // with a binary search (a handful of lookups instead of walking a long timeline).
    function qeClipByTime(qtrack, clip, eps) {
        var target = sec(clip.start);
        var lo = 0, hi = qtrack.numItems - 1;
        var guard = 0;
        while (lo <= hi && guard++ < 64) {
            var mid = Math.floor((lo + hi) / 2);
            var q = qtrack.getItemAt(mid);
            if (!q) { return null; }
            var s = qeStart(q);
            if (s === null || isNaN(s)) { return null; }
            if (Math.abs(s - target) <= eps) {
                if (q.type === "Empty") { return null; }
                var qn = null;
                try { qn = q.name; } catch (e) {}
                if (qn !== null && qn !== undefined && String(qn) !== String(clip.name)) { return null; }
                return q;
            }
            if (s < target) { lo = mid + 1; } else { hi = mid - 1; }
        }
        return null;
    }

    function qeClipFor(seq, clip) {
        ensureQE();
        var qseq = qe.project.getActiveSequence();
        if (!qseq) { return null; }
        var isVideo = clip.mediaType === VIDEO;
        var tracks = isVideo ? seq.videoTracks : seq.audioTracks;
        var tIndex = -1, nth = -1;
        try { tIndex = clip.parentTrackIndex; } catch (e0) {}
        if (typeof tIndex === "number" && tIndex >= 0 && tIndex < tracks.numTracks) {
            try {
                var fast = qeClipByTime(isVideo ? qseq.getVideoTrackAt(tIndex) : qseq.getAudioTrackAt(tIndex), clip, frameSeconds(seq) * 0.5);
                if (fast) { return fast; }
            } catch (eF) {}
        }
        // Slow path: count clips on the track to find the matching QE item
        var order = [];
        if (typeof tIndex === "number" && tIndex >= 0 && tIndex < tracks.numTracks) { order.push(tIndex); }
        for (var t = 0; t < tracks.numTracks; t++) { if (t !== tIndex) { order.push(t); } }
        for (var o = 0; o < order.length && nth < 0; o++) {
            var tr = tracks[order[o]];
            for (var i = 0; i < tr.clips.numItems; i++) {
                if (tr.clips[i].nodeId === clip.nodeId) { nth = i; tIndex = order[o]; break; }
            }
        }
        if (nth < 0) { return null; }
        var qtrack = isVideo ? qseq.getVideoTrackAt(tIndex) : qseq.getAudioTrackAt(tIndex);
        var n = -1;
        for (var j = 0; j < qtrack.numItems; j++) {
            var q = qtrack.getItemAt(j);
            if (q && q.type !== "Empty") {
                n++;
                if (n === nth) { return q; }
            }
        }
        return null;
    }

    var effectCache = { video: {}, audio: {} };
    function findEffect(name, media) {
        ensureQE();
        var key = lower(name);
        var cache = effectCache[media];
        if (cache[key]) { return cache[key]; }
        var fx = null;
        try { fx = media === "audio" ? qe.project.getAudioEffectByName(name) : qe.project.getVideoEffectByName(name); } catch (e) {}
        if (!fx) {
            // Some effects are listed with/without a " (Legacy)" suffix depending on version
            var alt = /\s*\(legacy\)\s*$/i.test(name) ? name.replace(/\s*\(legacy\)\s*$/i, "") : name + " (Legacy)";
            try { fx = media === "audio" ? qe.project.getAudioEffectByName(alt) : qe.project.getVideoEffectByName(alt); } catch (e2) {}
        }
        if (fx) { cache[key] = fx; }
        return fx;
    }

    function componentNames(clip) {
        var out = [];
        try {
            for (var i = 0; i < clip.components.numItems; i++) {
                var c = clip.components[i];
                out.push(String(c.matchName) + "|" + String(c.displayName));
            }
        } catch (e) {}
        return out;
    }

    // Adds an effect via QE and returns the new standard-DOM component.
    // ctx (optional) carries the clip's QE item and effect list between calls on the same clip,
    // so adding several effects doesn't look the clip up again each time.
    function addEffectToClip(seq, clip, name, media, ctx) {
        ctx = ctx || {};
        var fx = findEffect(name, media);
        if (!fx) { return { error: "Premiere has no effect called \"" + name + "\"" }; }
        var t0 = now();
        var q = ctx.q || qeClipFor(seq, clip);
        ctx.lookupMs = (ctx.lookupMs || 0) + (now() - t0);
        if (!q) { return { error: "Couldn't reach that clip" }; }
        ctx.q = q;
        var before = ctx.names || componentNames(clip);
        try {
            if (media === "audio") { q.addAudioEffect(fx); } else { q.addVideoEffect(fx); }
        } catch (e) { ctx.q = null; ctx.names = null; return { error: String(e) }; }
        var after = componentNames(clip);
        ctx.names = after;
        if (after.length <= before.length) { return { error: "Premiere didn't add " + name }; }
        var idx = after.length - 1;
        for (var i = 0; i < before.length; i++) {
            if (after[i] !== before[i]) { idx = i; break; }
        }
        return { component: clip.components[idx] };
    }

    function selectedClips(seq, media) {
        var out = [];
        var s = selectionSnapshot(seq);
        for (var i = 0; i < s.length; i++) {
            var c = s[i];
            var mt = null;
            try { mt = c.mediaType; } catch (e) {}
            if (!mt) { continue; }
            if (media === "any" || (media === "video" && mt === VIDEO) || (media === "audio" && mt === AUDIO)) { out.push(c); }
        }
        return out;
    }

    // ---- preset rebuild
    var timeForm = null; // which time argument form keyframe calls accept on this build ("time" | "seconds")
    function withTime(seconds, fn) {
        var forms = timeForm ? [timeForm] : ["time", "seconds"];
        for (var i = 0; i < forms.length; i++) {
            var arg = forms[i] === "time" ? timeAt(seconds) : seconds;
            try { fn(arg); timeForm = forms[i]; return true; } catch (e) {
                if (timeForm) { timeForm = null; return withTime(seconds, fn); }
            }
        }
        return false;
    }

    function interpType(i) {
        if (i === 4 || i === 5 || i === 6 || i === 0) { return i; }
        if (i === 2 || i === 3) { return 5; }
        return 0;
    }

    function shallowWith(o, extra) {
        var out = {};
        for (var key in o) { if (o.hasOwnProperty(key)) { out[key] = o[key]; } }
        for (var k2 in extra) { if (extra.hasOwnProperty(k2)) { out[k2] = extra[k2]; } }
        return out;
    }
    function closeTo(a, b) {
        var x = Number(a), y = Number(b);
        if (isNaN(x) || isNaN(y)) { return false; }
        return Math.abs(x - y) <= 1e-6 * Math.max(1, Math.abs(y));
    }
    // true when the property already holds the value we'd write (or there's nothing to write)
    function alreadySet(prop, want) {
        if (want === null || want === undefined) { return true; }
        var cur;
        try { cur = prop.getValue(); } catch (e) { return false; }
        if (cur === null || cur === undefined) { return false; }
        if (typeof want === "boolean") {
            if (typeof cur === "boolean") { return cur === want; }
            return closeTo(cur, want ? 1 : 0);
        }
        if (typeof want === "number") { return typeof cur !== "object" && closeTo(cur, want); }
        if (want.length !== undefined) {
            if (typeof cur !== "object" || cur.length !== want.length) { return false; }
            for (var i = 0; i < want.length; i++) { if (!closeTo(cur[i], want[i])) { return false; } }
            return true;
        }
        return false;
    }

    function setParam(prop, p, clipInfo, comp, stats) {
        if (p.kind === "arb") { stats.skipped++; return; }
        var ui = false;
        if (p.keys && p.keys.length) {
            // an effect FX Drop just added can't have keyframes yet, so skip asking
            if (!comp.fresh) { try { if (prop.isTimeVarying()) { prop.setTimeVarying(false); } } catch (e0) {} }
            try { prop.setTimeVarying(true); } catch (e1) { stats.skipped++; return; }
            var placed = [];
            for (var k = 0; k < p.keys.length; k++) {
                var key = p.keys[k];
                var off;
                if (comp.anchor === 1) { off = key.t; }
                else if (comp.anchor === 2) { off = clipInfo.dur - (comp.anchorLen - key.t); }
                else { off = comp.anchorLen > 0 ? (key.t / comp.anchorLen) * clipInfo.dur : key.t; }
                var t = clipInfo.base + off * clipInfo.speed;
                placed.push(t);
                var v = key.v;
                if (p.kind === "color") { stats.skipped++; continue; }
                withTime(t, function (arg) { prop.addKey(arg); });
                withTime(t, function (arg) { prop.setValueAtKey(arg, v, ui); });
                var it = interpType(key.i);
                if (it !== 0) {
                    withTime(t, function (arg) {
                        try { prop.setInterpolationTypeAtKey(arg, it, ui); } catch (e2) { prop.setInterpolationTypeAtKey(arg, 5, ui); }
                    });
                }
                stats.keys++;
            }
            // remove any key Premiere added on its own (e.g. at the playhead when keyframing was switched on)
            try {
                var ks = prop.getKeys();
                if (ks) {
                    for (var r = ks.length - 1; r >= 0; r--) {
                        var kt = sec(ks[r]);
                        if (kt === null) { kt = Number(ks[r]); if (kt > 1000000) { kt = kt / TPS; } }
                        var keep = false;
                        for (var q = 0; q < placed.length; q++) { if (Math.abs(placed[q] - kt) < 0.0005) { keep = true; break; } }
                        if (!keep) { withTime(kt, function (arg) { prop.removeKey(arg); }); }
                    }
                }
            } catch (e3) {}
            return;
        }
        var wasKeyed = false;
        if (!comp.fresh) { try { wasKeyed = !!prop.isTimeVarying(); } catch (e4) {} }
        if (wasKeyed) {
            try { prop.setTimeVarying(false); } catch (e6) {}
        } else if (p.kind !== "color" && alreadySet(prop, p.value)) {
            // Writing a setting is slow in Premiere (each one is an undo step), and most settings
            // in a preset are just the defaults the effect already has. Only write what differs.
            stats.same = (stats.same || 0) + 1;
            return;
        }
        try {
            if (p.kind === "color" && p.value) {
                prop.setColorValue(p.value.a, p.value.r, p.value.g, p.value.b, ui);
            } else if (p.value !== null && p.value !== undefined) {
                prop.setValue(p.value, ui);
                // checkboxes (e.g. Transform's Uniform Scale) must really end up as the preset says
                if (typeof p.value === "boolean" && !alreadySet(prop, p.value)) {
                    try { prop.setValue(p.value ? 1 : 0, true); } catch (e7) {}
                    if (!alreadySet(prop, p.value)) { stats.failed++; stats.boolMiss = (stats.boolMiss || 0) + 1; }
                }
            }
            stats.values++;
        } catch (e5) { stats.failed++; }
    }

    // Pairs each preset setting with the effect's matching property.
    // 1. by name; 2. settings without a usable name (Premiere saves checkboxes like
    // "Uniform Scale" with no name) by their place between named neighbours; 3. leftover
    // unnamed ones with leftover unnamed properties, in order. Never guesses when counts differ.
    function mapParams(compObj, presetParams, stats) {
        var props = [], names = [], used = [];
        for (var i = 0; i < compObj.properties.numItems; i++) {
            var pr = compObj.properties[i];
            props.push(pr);
            var dn = "";
            try { dn = lower(trim(pr.displayName)); } catch (e0) {}
            names.push(dn);
            used.push(false);
        }
        var n = presetParams.length;
        var hitOf = [];
        var j, k, m;
        for (j = 0; j < n; j++) {
            var want = lower(trim(presetParams[j].name));
            var hit = -1;
            if (want) {
                if (j < props.length && !used[j] && names[j] === want) { hit = j; }
                for (k = 0; hit < 0 && k < props.length; k++) {
                    if (!used[k] && names[k] === want) { hit = k; }
                }
            }
            if (hit >= 0) { used[hit] = true; }
            hitOf.push(hit);
        }
        // 2. runs of unmatched settings between matched neighbours
        j = 0;
        while (j < n) {
            if (hitOf[j] >= 0) { j++; continue; }
            var b = j;
            while (b < n && hitOf[b] < 0) { b++; }
            var lo = j > 0 ? hitOf[j - 1] : -1;
            var hi = b < n ? hitOf[b] : props.length;
            var free = [];
            for (k = lo + 1; k < hi; k++) { if (!used[k]) { free.push(k); } }
            if (lo < hi && free.length === b - j) {
                for (m = 0; m < free.length; m++) { hitOf[j + m] = free[m]; used[free[m]] = true; }
            }
            j = b;
        }
        // 3. leftover unnamed settings <-> leftover unnamed properties
        var ls = [], lp = [];
        for (j = 0; j < n; j++) { if (hitOf[j] < 0 && !lower(trim(presetParams[j].name))) { ls.push(j); } }
        for (k = 0; k < props.length; k++) { if (!used[k] && !names[k]) { lp.push(k); } }
        if (ls.length && ls.length === lp.length) {
            for (m = 0; m < ls.length; m++) { hitOf[ls[m]] = lp[m]; used[lp[m]] = true; }
        }
        var pairs = [];
        var missed = [];
        for (j = 0; j < n; j++) {
            if (hitOf[j] >= 0) { pairs.push([props[hitOf[j]], presetParams[j]]); }
            else if (presetParams[j].kind !== "arb") { missed.push(j + ":" + (presetParams[j].name || "?")); }
        }
        if (missed.length && stats) {
            stats.unmapped = stats.unmapped || [];
            stats.unmapped.push(String(compObj.displayName) + " [" + missed.join(", ") + "] props=" + names.join("|"));
        }
        return pairs;
    }

    function findComponent(clip, matchName, displayName) {
        for (var i = 0; i < clip.components.numItems; i++) {
            var c = clip.components[i];
            if (c.matchName === matchName) { return c; }
        }
        for (var j = 0; j < clip.components.numItems; j++) {
            var d = clip.components[j];
            if (lower(d.displayName) === lower(displayName)) { return d; }
        }
        return null;
    }

    function clipTiming(clip, timeBase) {
        var start = sec(clip.start), end = sec(clip.end);
        var speed = 1;
        try { var sp = clip.getSpeed(); if (sp && sp > 0) { speed = sp; } } catch (e) {}
        var base = timeBase === "sequence" ? start : sec(clip.inPoint);
        return { start: start, dur: end - start, base: base, speed: timeBase === "sequence" ? 1 : speed };
    }

    function applyPresetToClip(seq, clip, preset, opts, stats) {
        var media = clip.mediaType === AUDIO ? "audio" : "video";
        var info = clipTiming(clip, opts.timeBase);
        var applied = 0;
        var ctx = {}; // reuses the clip lookup across this preset's effects
        var tAdd = 0, tSet = 0;
        for (var i = 0; i < preset.components.length; i++) {
            var c = preset.components[i];
            if (c.media !== media) { continue; }
            var compObj = null;
            var t0 = now();
            if (c.intrinsic) {
                compObj = findComponent(clip, c.matchName, c.displayName);
                if (!compObj) { stats.missing.push(c.displayName); continue; }
            } else {
                var r = addEffectToClip(seq, clip, c.displayName, media, ctx);
                if (r.error) { stats.missing.push(c.displayName); continue; }
                compObj = r.component;
                c = shallowWith(c, { fresh: true });
            }
            var t1 = now();
            var pairs = mapParams(compObj, c.params, stats);
            for (var k = 0; k < pairs.length; k++) { setParam(pairs[k][0], pairs[k][1], info, c, stats); }
            tAdd += t1 - t0;
            tSet += now() - t1;
            if (c.hasPrivateData && !c.intrinsic) { stats.partial = true; }
            applied++;
        }
        stats.ms = stats.ms || {};
        stats.ms.find = (stats.ms.find || 0) + (ctx.lookupMs || 0);
        stats.ms.add = (stats.ms.add || 0) + tAdd - (ctx.lookupMs || 0);
        stats.ms.settings = (stats.ms.settings || 0) + tSet;
        try { clip.setSelected(clip.isSelected() ? 1 : 0, 1); } catch (e) {}
        return applied;
    }

    function findAdjustmentLayer() {
        if (F.adjNodeId) {
            var cached = findByNode(app.project.rootItem, F.adjNodeId, 0);
            if (cached) { return cached; }
        }
        var found = scanAdj(app.project.rootItem, 0);
        if (found) { F.adjNodeId = found.nodeId; }
        return found;
    }
    function findByNode(bin, id, depth) {
        if (depth > 12) { return null; }
        for (var i = 0; i < bin.children.numItems; i++) {
            var c = bin.children[i];
            if (!c) { continue; }
            if (c.nodeId === id) { return c; }
            if (c.type === ProjectItemType.BIN) { var f = findByNode(c, id, depth + 1); if (f) { return f; } }
        }
        return null;
    }
    function scanAdj(bin, depth) {
        if (depth > 12) { return null; }
        var sub = [];
        for (var i = 0; i < bin.children.numItems; i++) {
            var c = bin.children[i];
            if (!c) { continue; }
            if (c.type === ProjectItemType.BIN) { sub.push(c); continue; }
            var adj = false;
            try { adj = c.isAdjustmentLayer(); } catch (e) {}
            if (adj) { return c; }
        }
        for (var j = 0; j < sub.length; j++) { var f = scanAdj(sub[j], depth + 1); if (f) { return f; } }
        return null;
    }

    // ------------------------------------------------------------------ commands
    F.cmd = {};

    F.cmd.ping = function () { return { version: F.version, premiere: app.version }; };

    F.cmd.status = function () {
        var out = { version: F.version, premiere: app.version, project: null, sequence: null, playhead: null, timecode: null, selection: { video: 0, audio: 0 } };
        if (!app.project) { return out; }
        out.project = app.project.name;
        var seq = app.project.activeSequence;
        if (!seq) { return out; }
        out.sequence = seq.name;
        var pos = seq.getPlayerPosition();
        out.playhead = sec(pos);
        try { out.timecode = pos.getFormatted(seq.getSettings().videoFrameRate, seq.videoDisplayFormat); } catch (e) {}
        var s = selectionSnapshot(seq);
        for (var i = 0; i < s.length; i++) {
            try { if (s[i].mediaType === VIDEO) { out.selection.video++; } else if (s[i].mediaType === AUDIO) { out.selection.audio++; } } catch (e2) {}
        }
        return out;
    };

    F.cmd.listEffects = function () {
        ensureQE();
        function names(list) {
            var out = [];
            if (!list) { return out; }
            var n = list.length !== undefined ? list.length : list.numItems;
            for (var i = 0; i < n; i++) {
                var v = list[i];
                if (v === null || v === undefined) { continue; }
                out.push(typeof v === "string" ? v : String(v.name));
            }
            return out;
        }
        var v = [], a = [];
        try { v = names(qe.project.getVideoEffectList()); } catch (e) {}
        try { a = names(qe.project.getAudioEffectList()); } catch (e2) {}
        return { video: v, audio: a };
    };

    // args: { path, kind: "audio"|"video"|"image", hasAudio, duration, includeAudio, name }
    // Sets the clip's Volume > Level in dB (the FX Drop "sound effect volume" setting).
    // Premiere stores Level as a gain where 1.0 = +15 dB, so 0 dB = 10^(-15/20).
    function setClipVolume(clip, db, report) {
        if (typeof db !== "number" || isNaN(db) || Math.abs(db) < 0.05 || !clip) { return; }
        db = Math.max(-60, Math.min(15, db));
        var want = Math.pow(10, (db - 15) / 20);
        try {
            var comps = clip.components;
            for (var i = 0; i < comps.numItems; i++) {
                var c = comps[i];
                var mn = "", dn = "";
                try { mn = String(c.matchName); } catch (e0) {}
                try { dn = lower(trim(c.displayName)); } catch (e1) {}
                if (mn !== "audioVolume" && dn !== "volume") { continue; }
                var level = null;
                for (var j = 0; j < c.properties.numItems; j++) {
                    var pn = "";
                    try { pn = lower(trim(c.properties[j].displayName)); } catch (e2) {}
                    if (pn === "level") { level = c.properties[j]; break; }
                }
                if (!level && c.properties.numItems >= 2) { level = c.properties[1]; }
                if (!level) { break; }
                try { level.setValue(want, true); } catch (e3) {}
                if (!closeTo(level.getValue(), want)) {
                    // keyframed by default on some setups: switch that off on this brand-new clip, then set it
                    try { level.setTimeVarying(false); } catch (e4) {}
                    try { level.setValue(want, true); } catch (e5) {}
                }
                if (closeTo(level.getValue(), want)) { report.volumeDb = db; return; }
                break;
            }
        } catch (e6) {}
        report.warnings.push("Couldn't set the sound's volume.");
    }

    F.cmd.insertMedia = function (args) {
        var seq = seqOrFail();
        var pos = sec(seq.getPlayerPosition());
        var eps = frameSeconds(seq) * 0.5;
        var isAudio = args.kind === "audio";
        var item = getOrImport(args.path, isAudio ? "Sound FX" : "Visual FX");
        var dur = args.duration > 0 ? args.duration : itemDuration(item, args.kind);
        if (!(dur > 0)) { dur = 5; }
        var end = pos + dur;
        var report = { name: item.name, start: pos, end: end, createdTrack: false, warnings: [] };
        var prevSel = selectionSnapshot(seq);

        if (isAudio) {
            var ai = ensureAudioTrack(seq, pos, end, eps, report);
            var placedA = placeOn(seq.audioTracks[ai], item, pos);
            if (!placedA) { throw new Fail("PLACE_FAILED", "Premiere didn't accept the clip on " + trackLabel(AUDIO, ai) + "."); }
            report.track = trackLabel(AUDIO, ai);
            report.end = sec(placedA.end);
            setClipVolume(placedA, args.volumeDb, report);
            restoreSelection(seq, prevSel);
            return report;
        }

        var mayHaveAudio = args.hasAudio !== false && args.kind !== "image";
        var vi = ensureVideoTrack(seq, pos, end, eps, report);
        var placedV = mayHaveAudio ? placePart(seq, "video", vi, item, pos) : placeOn(seq.videoTracks[vi], item, pos);
        if (!placedV) { throw new Fail("PLACE_FAILED", "Premiere didn't accept the clip on " + trackLabel(VIDEO, vi) + "."); }
        report.track = trackLabel(VIDEO, vi);
        report.end = sec(placedV.end);

        if (args.hasAudio && args.includeAudio) {
            var ai2 = ensureAudioTrack(seq, pos, report.end, eps, report);
            var placedAud = placePart(seq, "audio", ai2, item, pos);
            if (placedAud) {
                report.audioTrack = trackLabel(AUDIO, ai2);
                setClipVolume(placedAud, args.volumeDb, report);
                try {
                    restoreSelection(seq, [placedV, placedAud]);
                    seq.linkSelection();
                } catch (e) {}
            } else {
                report.warnings.push("Couldn't add the clip's sound.");
            }
        }
        restoreSelection(seq, prevSel);
        return report;
    };

    // args: { name, media: "video"|"audio" }
    F.cmd.applyEffect = function (args) {
        var seq = seqOrFail();
        var clips = selectedClips(seq, args.media);
        if (!clips.length) {
            throw new Fail("NO_SELECTION", "Select " + (args.media === "audio" ? "audio" : "video") + " clips in the timeline first.");
        }
        var ok = 0, err = null;
        for (var i = 0; i < clips.length; i++) {
            var r = addEffectToClip(seq, clips[i], args.name, args.media);
            if (r.error) { err = r.error; } else { ok++; }
        }
        if (!ok) { throw new Fail("EFFECT_FAILED", err || "Couldn't apply " + args.name + "."); }
        return { applied: ok, total: clips.length };
    };

    // args: { preset, timeBase: "media"|"sequence" }
    F.cmd.applyPreset = function (args) {
        var seq = seqOrFail();
        var preset = args.preset;
        var media = preset.media === "mixed" ? "any" : preset.media;
        var clips = selectedClips(seq, media);
        if (!clips.length) {
            throw new Fail("NO_SELECTION", "Select " + (media === "audio" ? "audio" : media === "video" ? "video" : "") + " clips in the timeline first.");
        }
        var stats = { keys: 0, values: 0, skipped: 0, failed: 0, missing: [], partial: false };
        var n = 0;
        var t0 = now();
        for (var i = 0; i < clips.length; i++) {
            if (applyPresetToClip(seq, clips[i], preset, args, stats) > 0) { n++; }
        }
        if (stats.ms) { stats.ms.total = now() - t0; }
        if (!n) { throw new Fail("PRESET_FAILED", stats.missing.length ? "Missing effect: " + stats.missing[0] : "Nothing in this preset fits those clips."); }
        return { applied: n, total: clips.length, stats: stats };
    };

    // args: { preset (optional), seconds, span: "selection"|"playhead", timeBase }
    F.cmd.addAdjustmentLayer = function (args) {
        var seq = seqOrFail();
        var adj = findAdjustmentLayer();
        if (!adj) {
            throw new Fail("NO_ADJ_LAYER", "This project has no adjustment layer yet. Make one once (Project panel › New Item › Adjustment Layer) and FX Drop will reuse it.");
        }
        var eps = frameSeconds(seq) * 0.5;
        var s, e;
        var sel = args.span === "selection" ? selectedClips(seq, "any") : [];
        if (sel.length) {
            s = 1e12; e = -1;
            for (var i = 0; i < sel.length; i++) {
                s = Math.min(s, sec(sel[i].start));
                e = Math.max(e, sec(sel[i].end));
            }
        } else {
            s = sec(seq.getPlayerPosition());
            e = s + (args.seconds > 0 ? args.seconds : 3);
        }
        var prevSel = selectionSnapshot(seq);
        var report = { createdTrack: false, start: s, end: e, warnings: [] };
        // make the master long enough before placing
        try { adj.setOutPoint(ticksStr(sec(adj.getInPoint()) + (e - s)), 4); } catch (e0) {}
        var vi = ensureVideoTrack(seq, s, e, eps, report);
        var clip = placeOn(seq.videoTracks[vi], adj, s);
        if (!clip) { throw new Fail("PLACE_FAILED", "Premiere didn't accept the adjustment layer on " + trackLabel(VIDEO, vi) + "."); }
        if (Math.abs(sec(clip.end) - e) > eps) {
            try { clip.end = timeAt(e); } catch (e1) {}
            if (Math.abs(sec(clip.end) - e) > eps) {
                try { clip.outPoint = timeAt(sec(clip.inPoint) + (e - s)); } catch (e2) {}
            }
        }
        report.track = trackLabel(VIDEO, vi);
        report.end = sec(clip.end);
        if (args.preset) {
            var stats = { keys: 0, values: 0, skipped: 0, failed: 0, missing: [], partial: false };
            applyPresetToClip(seq, clip, args.preset, args, stats);
            report.stats = stats;
        } else if (args.effect) {
            var r = addEffectToClip(seq, clip, args.effect, "video");
            if (r.error) { report.warnings.push(r.error); }
        }
        restoreSelection(seq, prevSel);
        return report;
    };

    // Diagnostic: describe the selected clip's effect stack (used for testing)
    F.cmd.inspectSelection = function () {
        var seq = seqOrFail();
        var clips = selectedClips(seq, "any");
        var out = [];
        for (var i = 0; i < clips.length && i < 4; i++) {
            var c = clips[i];
            var comps = [];
            for (var j = 0; j < c.components.numItems; j++) {
                var comp = c.components[j];
                var props = [];
                for (var k = 0; k < comp.properties.numItems && k < 40; k++) {
                    var pr = comp.properties[k];
                    var keys = null, val = null;
                    try { if (pr.isTimeVarying()) { var ks = pr.getKeys(); keys = []; for (var q = 0; q < ks.length && q < 12; q++) { keys.push(sec(ks[q])); } } } catch (e) {}
                    try { val = pr.getValue(); } catch (e2) {}
                    props.push({ name: pr.displayName, value: val, keys: keys });
                }
                comps.push({ name: comp.displayName, matchName: comp.matchName, props: props });
            }
            out.push({ name: c.name, type: c.mediaType, start: sec(c.start), end: sec(c.end), inPoint: sec(c.inPoint), components: comps });
        }
        return out;
    };

    // Diagnostic: which optional APIs exist on this Premiere build
    F.cmd.probe = function () {
        ensureQE();
        var out = { version: app.version };
        var seq = app.project && app.project.activeSequence;
        var qs = null;
        try { qs = qe.project.getActiveSequence(); } catch (e) {}
        out.newAdjustmentLayer = typeof qe.project.newAdjustmentLayer;
        if (seq) {
            out.insertVideoTrackAt = typeof seq.insertVideoTrackAt;
            out.insertAudioTrackAt = typeof seq.insertAudioTrackAt;
            out.addTrack = typeof seq.addTrack;
            out.deleteAudioTrackAt = typeof seq.deleteAudioTrackAt;
            out.audioTracks = trackSigs(seq.audioTracks);
            out.videoTracks = trackSigs(seq.videoTracks);
        }
        if (qs) {
            out.qeAddTracks = typeof qs.addTracks;
            out.qeRemoveAudioTrack = typeof qs.removeAudioTrack;
        }
        return out;
    };

    // Diagnostic: add one track of the given type through the normal path
    F.cmd.testAddTrack = function (args) {
        var seq = seqOrFail();
        var type = args.type === "video" ? VIDEO : AUDIO;
        var before = trackSigs(type === VIDEO ? seq.videoTracks : seq.audioTracks);
        var ok = addTrack(seq, type);
        return { ok: ok, before: before, after: trackSigs(type === VIDEO ? seq.videoTracks : seq.audioTracks) };
    };

    F.cmd.init = function (args) {
        if (args && args.extRoot) { F.extRoot = args.extRoot; }
        return { version: F.version };
    };
}($.global.FXD));
