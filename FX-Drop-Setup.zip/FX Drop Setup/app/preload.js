'use strict';
const { contextBridge, ipcRenderer } = require('electron');

function on(channel, fn) {
  const h = (e, data) => fn(data);
  ipcRenderer.on(channel, h);
  return () => ipcRenderer.removeListener(channel, h);
}

contextBridge.exposeInMainWorld('fx', {
  // popup
  ready: () => ipcRenderer.invoke('popup:ready'),
  onOpen: (fn) => on('popup:open', fn),
  onStatus: (fn) => on('popup:status', fn),
  onClosing: (fn) => on('popup:closing', fn),
  onCatalog: (fn) => on('catalog', fn),
  onKey: (fn) => on('popup:key', fn),
  onRemoteKeys: (fn) => on('popup:remoteKeys', fn),
  clipboardRead: () => ipcRenderer.invoke('clipboard:read'),
  clipboardWrite: (text) => ipcRenderer.send('clipboard:write', text),
  hide: (returnFocus) => ipcRenderer.send('popup:hide', returnFocus),
  action: (id, alt) => ipcRenderer.invoke('popup:action', { id, alt }),
  star: (id, on) => ipcRenderer.send('popup:star', { id, on }),
  remember: (query, scope) => ipcRenderer.send('popup:remember', { query, scope }),
  duration: (id, dur) => ipcRenderer.send('popup:duration', { id, dur }),
  startDrag: (id) => ipcRenderer.send('popup:startDrag', { id }),
  dragEnd: () => ipcRenderer.send('popup:dragEnd'),
  reveal: (id) => ipcRenderer.send('popup:reveal', { id }),
  openSettings: () => ipcRenderer.send('popup:openSettings'),
  peaks: (id, data) => ipcRenderer.invoke('cache:peaks', { id, data }),
  thumb: (id, dataUrl) => ipcRenderer.invoke('cache:thumb', { id, dataUrl }),
  // toast
  onToast: (fn) => on('toast', fn),
  // settings
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  addFolder: () => ipcRenderer.invoke('settings:addFolder'),
  createStarter: () => ipcRenderer.invoke('settings:createStarter'),
  choosePresetFile: () => ipcRenderer.invoke('settings:choosePresetFile'),
  reinstall: () => ipcRenderer.invoke('settings:reinstall'),
  testConnection: () => ipcRenderer.invoke('settings:test'),
  openLog: () => ipcRenderer.send('settings:openLog'),
  checkUpdate: () => ipcRenderer.invoke('settings:checkUpdate'),
  installPlugin: () => ipcRenderer.invoke('settings:installPlugin'),
  installUpdate: () => ipcRenderer.send('settings:installUpdate'),
  openFolder: (p) => ipcRenderer.send('settings:openFolder', p),
  tryPopup: () => ipcRenderer.send('settings:tryPopup'),
  rescan: () => ipcRenderer.send('settings:rescan'),
  onSettingsChanged: (fn) => on('settings:changed', fn),
  platform: process.platform,
});
