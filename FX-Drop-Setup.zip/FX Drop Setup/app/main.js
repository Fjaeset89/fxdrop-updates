'use strict';
const { app, BrowserWindow, globalShortcut, ipcMain, screen, Tray, Menu, nativeImage, protocol, dialog, shell, clipboard } = require('electron');
const path = require('path');
const fs = require('fs');
const { Readable } = require('stream');

const { Settings, Store } = require('./lib/settings');
const { Indexer } = require('./lib/indexer');
const { buildCatalog, findPremierePresetFile, PremierePresets, FALLBACK_EFFECTS } = require('./lib/catalog');
const bridge = require('./lib/bridge');
const { WinHelper, isPremiere, keyName } = require('./lib/winhelper');
const cep = require('./lib/cepinstall');
const { Updater, cmpVer } = require('./lib/updater');
const { PluginBridge } = require('./lib/wsserver');
const uxpPlugin = require('./lib/uxpinstall');

const VERSION = require('./package.json').version;
const HOST_VERSION = (fs.readFileSync(path.join(__dirname, 'cep', 'jsx', 'host.jsx'), 'utf8').match(/F\.version = "([^"]+)"/) || [])[1];
const POPUP = { w: 820, h: 520 }; // includes the transparent shadow margin
const MARGIN = 18;

protocol.registerSchemesAsPrivileged([
  { scheme: 'fxmedia', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } },
]);

app.setAppUserModelId('com.fxdrop.app');
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  main();
}

function main() {
  const USER = app.getPath('userData');
  fs.mkdirSync(USER, { recursive: true });
  const LOG = path.join(USER, 'fxdrop.log');
  const THUMBS = path.join(USER, 'thumbs');
  fs.mkdirSync(THUMBS, { recursive: true });

  // On the PC that publishes FX Drop (it has the "FX Drop Release" folder) the log is also kept
  // next to the release files, so problems can be looked at without digging in AppData.
  let MIRROR = null;
  try {
    const rel = path.join(app.getPath('documents'), 'Adobe', 'Premiere Pro', 'FX Drop Release');
    if (fs.existsSync(rel)) MIRROR = path.join(rel, 'fxdrop-log.txt');
  } catch (e) {}
  function log(...a) {
    const line = new Date().toISOString() + ' ' + a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ') + '\n';
    if (MIRROR) {
      try {
        if (fs.existsSync(MIRROR) && fs.statSync(MIRROR).size > 1024 * 1024) fs.renameSync(MIRROR, MIRROR.replace(/\.txt$/, '.old.txt'));
        fs.appendFileSync(MIRROR, line);
      } catch (e) {}
    }
    try {
      if (fs.existsSync(LOG) && fs.statSync(LOG).size > 1024 * 1024) fs.renameSync(LOG, LOG + '.old');
      fs.appendFileSync(LOG, line);
    } catch (e) {}
    if (!app.isPackaged) process.stdout.write(line);
  }
  process.on('uncaughtException', (e) => log('uncaught', e && e.stack));
  app.on('child-process-gone', (e, d) => log('helper process of FX Drop stopped:', d && d.type, d && d.reason));

  const settings = new Settings(USER);
  const usage = new Store(path.join(USER, 'usage.json'), { stars: {}, usage: {} });
  // Star profiles: each profile has its own starred list (one per channel/client, say).
  // usage.data.stars always IS the active profile's list, so the rest of FX Drop needn't know.
  (function initProfiles() {
    const d = usage.data;
    if (!Array.isArray(d.profiles) || !d.profiles.length) d.profiles = [{ id: 'p1', name: 'Starred', stars: d.stars || {} }];
    d.profiles = d.profiles.filter((x) => x && x.id).map((x) => ({ id: String(x.id), name: String(x.name || 'Starred').slice(0, 30), stars: x.stars && typeof x.stars === 'object' ? x.stars : {} }));
    const active = d.profiles.find((x) => x.id === d.profile) || d.profiles[0];
    d.profile = active.id;
    d.stars = active.stars;
  })();
  function profilesInfo() {
    return { active: usage.data.profile, list: usage.data.profiles.map((x) => ({ id: x.id, name: x.name, count: Object.keys(x.stars).length })) };
  }
  const peaks = new Store(path.join(USER, 'peaks.json'), {});
  const effectsStore = new Store(path.join(USER, 'effects.json'), { video: null, audio: null });
  const indexer = new Indexer(path.join(USER, 'index-cache.json'), log);
  const premierePresets = new PremierePresets(log);
  const helper = new WinHelper(log);

  let catalog = { items: [], recipes: new Map() };
  let byId = new Map();
  let popup = null;
  let toast = null;
  let settingsWin = null;
  let tray = null;
  let hotkeyRegistered = false;
  let hotkeyError = null;
  let helperOk = process.platform === 'win32';
  let lastPremiereHwnd = null;
  let connected = false;
  let lastStatus = null;
  let dragging = false;
  let needsRestart = false;
  let effectsFetched = false;
  let popupShownAt = 0;
  let durTimer = null;
  let lastActivity = Date.now(); // last time the popup was opened or used
  let actionsRunning = 0;

  // ------------------------------------------------------------ catalog
  function presetFile() {
    return settings.get('premierePresetsFile') || findPremierePresetFile(app.getPath('documents'));
  }

  function rebuild() {
    const eff = effectsStore.data.video ? effectsStore.data : FALLBACK_EFFECTS;
    catalog = buildCatalog({
      media: indexer.media,
      premierePresets: settings.get('usePremierePresets') ? premierePresets.presets : [],
      packPresets: indexer.libraryPresets || [],
      shortcuts: premierePresets.shortcuts,
      effects: eff,
      stars: usage.data.stars,
      usage: usage.data.usage,
    });
    byId = new Map(catalog.items.map((i) => [i.id, i]));
    if (popup && !popup.isDestroyed()) popup.webContents.send('catalog', catalog.items);
    if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed');
    updateTray();
  }

  async function scanLibrary() {
    await indexer.scan(settings.get('libraryFolders'));
    rebuild();
  }

  function loadPremierePresets() {
    if (!settings.get('usePremierePresets')) return;
    premierePresets.load(presetFile());
  }

  // watch library folders and the Premiere preset file
  let watchers = [];
  let rescanTimer = null;
  function watchLibrary() {
    for (const w of watchers) { try { w.close(); } catch (e) {} }
    watchers = [];
    for (const root of settings.get('libraryFolders')) {
      try {
        watchers.push(fs.watch(root, { recursive: true }, () => {
          clearTimeout(rescanTimer);
          rescanTimer = setTimeout(scanLibrary, 1500);
        }));
      } catch (e) { log('watch failed', root, e.message); }
    }
  }
  let watchedPresetFile = null;
  function watchPresetFile() {
    if (watchedPresetFile) fs.unwatchFile(watchedPresetFile);
    watchedPresetFile = presetFile();
    if (!watchedPresetFile) return;
    fs.watchFile(watchedPresetFile, { interval: 4000 }, () => {
      if (premierePresets.load(watchedPresetFile)) rebuild();
    });
  }

  // ------------------------------------------------------------ Premiere connection
  // Two ways into Premiere: the new UXP plugin (one undo step per action, faster) and the older
  // CEP extension. Each command goes to the plugin when it's connected and says it can do it.
  const PLUGIN_PORT = 47322;
  function pluginToken() {
    const f = path.join(USER, 'plugin-token.json');
    try { const t = JSON.parse(fs.readFileSync(f, 'utf8')).token; if (t && t.length >= 32) return t; } catch (e) {}
    const t = require('crypto').randomBytes(24).toString('hex');
    try { fs.writeFileSync(f, JSON.stringify({ token: t })); } catch (e) {}
    return t;
  }
  const plugin = new PluginBridge({ port: PLUGIN_PORT, token: pluginToken(), log });
  plugin.on('connected', () => { setConnected(true); refreshStatus(); });
  plugin.on('disconnected', () => { refreshStatus(); });
  function viaPlugin(fn) {
    return settings.get('usePlugin') !== false && plugin.connected && plugin.info.can.includes(fn);
  }
  // Premiere's internal name for an effect (e.g. Transform = "AE.ADBE Geometry2"), learned from the
  // user's own presets - lets the plugin add it directly
  function effectMatchName(name, media) {
    const want = String(name || '').trim().toLowerCase();
    for (const p of premierePresets.presets || []) {
      for (const c of p.components || []) {
        if (!c.intrinsic && c.matchName && (!media || c.media === media) && String(c.displayName || '').trim().toLowerCase() === want) return c.matchName;
      }
    }
    return undefined;
  }

  let lastRoute = null; // 'plugin' | 'classic' - how the last command reached Premiere
  // The plugin running in Premiere is older than the one FX Drop installed: Premiere needs a restart
  function pluginOutdated() {
    const inst = settings.get('premierePlugin') || {};
    return !!(plugin.connected && inst.ok && inst.version && plugin.info && plugin.info.version && plugin.info.version !== inst.version);
  }
  const RESTART_HINT = 'Restart Premiere once to finish FX Drop’s update';
  async function runPremiere(fn, args, timeoutMs) {
    if (viaPlugin(fn)) {
      try {
        const r = await plugin.run(fn, args, timeoutMs);
        lastRoute = 'plugin';
        // an older plugin could report "done" although Premiere took none of the settings
        const st = r && r.stats;
        if (fn === 'applyPreset' && st && st.failed > 0 && !(st.keys + st.values)) {
          throw Object.assign(new Error('Premiere didn’t take the preset. ' + (pluginOutdated() ? RESTART_HINT + '.' : 'Try again.')), { code: 'PREMIERE_REFUSED' });
        }
        return r;
      } catch (e) {
        // Presets never go the classic way while the plugin is there: the classic route isn't one
        // step in Premiere's History, so Ctrl+Z would undo the user's own earlier edits instead.
        if (fn !== 'applyPreset' && (e.code === 'USE_CLASSIC' || e.code === 'PREMIERE_REFUSED')) log('plugin refused', fn, e.message, e.detail || '');
        if (fn === 'applyPreset' && e.code !== 'NO_PLUGIN') {
          if (e.code === 'USE_CLASSIC' || e.code === 'PREMIERE_REFUSED') {
            log('plugin refused', fn, e.message, e.detail || '');
            throw Object.assign(new Error(pluginOutdated() ? 'Premiere didn’t take the preset, so nothing changed. ' + RESTART_HINT + '.' : e.message), { code: 'PREMIERE_REFUSED' });
          }
          throw e;
        }
        // fall back ONLY when the plugin changed nothing: it wasn't reached, or it checked that the
        // clips are untouched and handed the job over. Anything else could add effects twice.
        if (e.code !== 'NO_PLUGIN' && e.code !== 'USE_CLASSIC') throw e;
        log('plugin handed', fn, 'to the classic route:', e.message);
      }
    }
    const r = await bridge.run(fn, args, timeoutMs);
    lastRoute = 'classic';
    return r;
  }

  // ---- freeze meter: notes what FX Drop just did, and logs any moment Premiere stops answering
  const marks = [];
  function mark(what) { marks.push({ at: Date.now(), what }); if (marks.length > 40) marks.shift(); }
  let freezeLines = 0;
  let unwatchTimer = null;
  function watchPremiere(hwnd) {
    clearTimeout(unwatchTimer);
    if (hwnd) helper.watch(hwnd);
  }

  // Installs (or updates) the plugin inside Premiere when it changed. Never blocks startup.
  async function installPlugin(force) {
    try {
      const r = await uxpPlugin.ensure({ workDir: path.join(USER, 'premiere-plugin'), token: plugin.token, port: PLUGIN_PORT,
        version: VERSION, state: settings.get('premierePlugin'), log, force });
      if (r.changed) {
        const first = !(settings.get('premierePlugin') || {}).ok;
        settings.set({ premierePlugin: { hash: r.hash, ok: r.ok, missing: !!r.missing, ccx: r.ccx, version: r.version, startup: !!r.startup, at: Date.now() } });
        if (r.ok) {
          log('premiere plugin', first ? 'installed' : 'updated', r.startup ? '(starts with Premiere)' : '(plain)');
          if (!plugin.connected || first) showToast(RESTART_TOAST);
          else showToast({ text: RESTART_HINT, sub: 'FX Drop’s Premiere plugin was updated – presets need the restart', tone: 'warn', ms: 9000 });
        }
        if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed');
      }
      if (process.platform === 'win32') {
        const sync = uxpPlugin.syncInstalled({ token: plugin.token, port: PLUGIN_PORT, version: VERSION, log });
        if (sync.updated.length && !r.changed && plugin.connected) showToast({ text: RESTART_HINT, sub: 'FX Drop’s Premiere plugin was updated – presets need the restart', tone: 'warn', ms: 9000 });
      }
      return r;
    } catch (e) {
      log('premiere plugin install error', e.message);
      return { ok: false, error: e.message };
    }
  }

  // ---- the plugin isn't running in Premiere: tell the user (once per Premiere session) what to do
  const RESTART_TOAST = { text: 'Restart Premiere once to finish FX Drop’s update', sub: 'Makes presets smooth, and Ctrl+Z undoes them in one step', tone: 'warn', ms: 7000 };
  const PANEL_TOAST = { text: 'FX Drop’s Premiere plugin isn’t connected yet', sub: 'In Premiere: Window › UXP Plugins › FX Drop shows what’s wrong', tone: 'warn', ms: 7000 };
  let classicSince = 0;
  let remindedFor = null;
  function premiereStartedAt() {
    const info = bridge.readInfo();
    const t = info && Date.parse(info.startedAt);
    return t > 0 ? t : 0;
  }
  function pluginReminder(force) {
    const inst = settings.get('premierePlugin') || {};
    if (process.platform !== 'win32' || plugin.connected || !inst.ok || settings.get('usePlugin') === false) { classicSince = 0; return; }
    if (!connected) { classicSince = 0; return; }
    if (!classicSince) classicSince = Date.now();
    const started = premiereStartedAt();
    const key = String(started);
    if (remindedFor === key) return;
    if (!force && Date.now() - classicSince < 45000) return;
    const inFront = helper.foreground && isPremiere(helper.foreground.name);
    if (!force && (!inFront || (popup && popup.isVisible()))) return;
    remindedFor = key;
    // Premiere started before the plugin was installed: a restart loads it. Otherwise it didn't start by itself.
    const restart = !started || started < (inst.at || 0);
    log('premiere plugin not running -', restart ? 'asked to restart Premiere' : 'asked to open the panel once');
    showToast(restart ? RESTART_TOAST : PANEL_TOAST);
  }

  let hostChecked = false;
  async function checkHostVersion() {
    if (hostChecked) return;
    hostChecked = true;
    try {
      const p = await bridge.run('ping', {}, 4000);
      if (HOST_VERSION && p && p.version !== HOST_VERSION) {
        log('Premiere side is', p.version, '- loading', HOST_VERSION);
        await bridge.run('__reloadHost', {}, 10000);
      }
    } catch (e) { hostChecked = false; }
  }
  async function refreshStatus() {
    try {
      // the plugin reads it without going through Premiere's old script engine
      if (viaPlugin('status')) {
        try { lastStatus = await plugin.run('status', {}, 4000); mark('status read via plugin'); setConnected(true); return lastStatus; } catch (e) {}
      }
      try {
        lastStatus = await bridge.run('status', {}, 4000);
        mark('status read via old script route');
      } catch (e) {
        if (!viaPlugin('status')) throw e;
        lastStatus = await plugin.run('status', {}, 4000);
        hostChecked = true;
      }
      if (!hostChecked) {
        hostChecked = true;
        if (HOST_VERSION && lastStatus.version !== HOST_VERSION) {
          log('Premiere side is', lastStatus.version, '- loading', HOST_VERSION);
          try { await bridge.run('__reloadHost', {}, 10000); lastStatus = await bridge.run('status', {}, 4000); } catch (e) { log('reload failed', e.message); }
        }
      }
      setConnected(true);
      if (!effectsFetched) fetchEffects();
    } catch (e) {
      lastStatus = null;
      setConnected(plugin.connected);
    }
    return lastStatus;
  }
  function setConnected(v) {
    if (connected === v) return;
    connected = v;
    if (!v) { effectsFetched = false; hostChecked = false; }
    updateTray();
    if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed');
  }
  async function fetchEffects() {
    effectsFetched = true;
    try {
      const r = await runPremiere('listEffects', {}, 15000);
      if (r && r.video && r.video.length) {
        effectsStore.data = { video: r.video, audio: r.audio || [] };
        effectsStore.saveNow();
        rebuild();
      }
    } catch (e) { effectsFetched = false; log('listEffects failed', e.message); }
  }
  setInterval(async () => {
    const classicOk = await bridge.health();
    const ok = plugin.connected || classicOk;
    setConnected(ok);
    if (classicOk) checkHostVersion();
    if (ok && !effectsFetched) fetchEffects();
    pluginReminder(false);
  }, 12000);

  // ------------------------------------------------------------ hotkey
  function wantHotkey() {
    if (!settings.get('hotkeyOnlyInPremiere') || !helperOk) return true;
    const fg = helper.foreground;
    if (!fg) return true;
    if (popup && popup.isVisible()) return true;
    return isPremiere(fg.name) || fg.pid === process.pid;
  }
  function registerHotkey() {
    const acc = settings.get('hotkey');
    try {
      const ok = globalShortcut.register(acc, onHotkey);
      hotkeyRegistered = ok;
      hotkeyError = ok ? null : 'Another app already uses ' + acc + '. Pick a different shortcut.';
    } catch (e) {
      hotkeyRegistered = false;
      hotkeyError = 'That shortcut isn\'t valid.';
    }
    if (hotkeyError) log('hotkey', hotkeyError);
  }
  function syncHotkey() {
    const want = wantHotkey();
    if (want && !hotkeyRegistered) registerHotkey();
    else if (!want && hotkeyRegistered) {
      globalShortcut.unregisterAll();
      hotkeyRegistered = false;
    }
  }
  function resetHotkey() {
    globalShortcut.unregisterAll();
    hotkeyRegistered = false;
    syncHotkey();
  }
  function onHotkey() {
    if (popup.isVisible()) hidePopup(true);
    else if (Date.now() - closedByKeyAt > 400) openPopup();
  }

  helper.on('freeze', (ms) => {
    if (ms < 250 || freezeLines > 400) return;
    freezeLines++;
    const start = Date.now() - ms;
    let ev = null;
    for (let i = marks.length - 1; i >= 0; i--) if (marks[i].at <= start + 30) { ev = marks[i]; break; }
    log('Premiere froze', ms + 'ms', ev ? `(${Math.max(0, start - ev.at)}ms after: ${ev.what})` : '');
  });
  // key delay meter: a key that reached Premiere late because something held it up on the way
  let keyLines = 0;
  helper.on('keylate', (k) => {
    if (keyLines > 300) return;
    keyLines++;
    const key = (k.vk >= 0x30 && k.vk <= 0x5A) ? String.fromCharCode(k.vk) : 'key ' + k.vk;
    log('Key held up on its way to Premiere', k.ms + 'ms', '(' + key + ')');
  });
  helper.on('keystat', (k) => log('Key delay check:', k.n, 'presses, average', k.avg + 'ms, slowest', k.max + 'ms,', k.slow, 'slow'));
  helper.on('foreground', (fg) => {
    if (isPremiere(fg.name)) {
      if (!lastFg || !isPremiere(lastFg.name)) {
        mark('Premiere came to front' + (lastFg && lastFg.pid === process.pid ? ' (from FX Drop)' : ''));
        notePremiereDisplay();
      }
      watchPremiere(fg.hwnd);
    } else if (fg.pid !== process.pid) {
      clearTimeout(unwatchTimer);
      unwatchTimer = setTimeout(() => helper.unwatch(), 20000);
    }
    lastFg = fg;
    // switched to another app while the search box is open: close it
    if (popupMode === 'keys' && popup && popup.isVisible() && fg.pid !== process.pid && !isPremiere(fg.name) && Date.now() - popupShownAt > 300) hidePopup(false);
    if (isPremiere(fg.name)) lastPremiereHwnd = fg.hwnd;
    syncHotkey();
    syncPasteKeys();
  });
  helper.on('unavailable', () => { helperOk = false; syncHotkey(); });
  helper.on('ready', () => {
    syncPasteKeys();
    if (settings.get('smartPaste') !== false) setTimeout(disableOldSmartPaste, 4000);
  });

  // ---- Smart paste + Ctrl+V for copied pictures (keys watched by the window helper while
  //      Premiere is in front; no AutoHotkey needed)
  function combo(name, fallback) {
    const a = parseAccel(settings.get(name) || fallback);
    if (!a.vk) return parseAccel(fallback);
    return Object.assign(a, { mods: (a.shift ? 1 : 0) | (a.ctrl ? 2 : 0) | (a.alt ? 4 : 0) });
  }
  function comboOf(name, fallback) { const a = combo(name, fallback); a.mods = (a.shift ? 1 : 0) | (a.ctrl ? 2 : 0) | (a.alt ? 4 : 0); return a; }
  function syncPasteKeys() {
    const fg = helper.foreground;
    const flags = (settings.get('smartPaste') !== false ? 1 : 0) | (settings.get('pasteImagesCtrlV') !== false ? 2 : 0);
    if (process.platform !== 'win32' || !helperOk || !fg || !isPremiere(fg.name) || !flags) { helper.spOff(); return; }
    helper.spKeys(fg.pid, comboOf('smartCutKey', 'Control+Alt+X'), comboOf('smartPasteKey', 'Alt+V'), flags);
  }
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  // where the selected clips sit, read by the Premiere plugin (Premiere's old script engine can miss
  // the selection in newer Premiere versions)
  async function spPluginItems() {
    if (!viaPlugin('selectedClips')) return null;
    try { const r = await plugin.run('selectedClips', {}, 2500); return r && r.items && r.items.length ? r.items : null; } catch (e) { log('smart paste: plugin could not read the selection -', e.message); return null; }
  }
  let spCopyAt = 0, spNoted = null;
  async function spCapture() {
    spCopyAt = Date.now();
    let r = null, via = 'script';
    try { r = await bridge.run('spCapture', {}, 3000); } catch (e) { log('smart paste: could not note the copied clips -', e.message); }
    if (!r || !r.clips) {
      const items = await spPluginItems();
      if (items) {
        via = 'plugin';
        try { r = await bridge.run('spCapture', { items }, 3000); } catch (e) { log('smart paste: could not note the copied clips -', e.message); }
      }
    }
    spNoted = r && r.clips ? r : null;
    mark('smart paste noted ' + ((r && r.clips) || 0) + ' clips');
    if (!spNoted) log('smart paste: copy seen, but no selected clips found');
    else if (via === 'plugin') log('smart paste: noted', r.clips, 'clips (read via the plugin)');
    return r;
  }
  let spBusy = false;
  helper.on('smartpaste', async (what) => {
    lastActivity = Date.now();
    if (what === 'copy') { setTimeout(spCapture, 60); return; }
    if (what === 'cut') {
      // note the clips first (they're gone once cut), then do the cut the user asked for
      await Promise.race([spCapture(), wait(900)]);
      await helper.sendKeys(comboOf('smartCutKey', 'Control+Alt+X'));
      return;
    }
    if (what === 'image') { pasteImageFromCtrlV(); return; }
    if (what !== 'paste' || spBusy) return;
    spBusy = true;
    const pasteKey = comboOf('premierePasteKey', 'Control+V');
    try {
      let r = null;
      try {
        r = await bridge.run('spPrepare', {}, 6000);
        if (r && r.passthru) {
          // nothing noted at copy time and the old script engine sees no selection: ask the plugin
          const items = await spPluginItems();
          if (items) r = await bridge.run('spPrepare', { items }, 6000);
        }
      } catch (e) {
        const noLink = /NO_BRIDGE|NO_PREMIERE|TIMEOUT|NET/.test(e.code || '');
        log('smart paste failed:', e.code, e.message);
        if (noLink) await helper.sendKeys(pasteKey); // can't reach Premiere's side: at least paste normally
        else showToast({ text: 'Smart paste: ' + e.message, tone: 'error' });
        return;
      }
      await helper.sendKeys(pasteKey);
      if (r && r.passthru) {
        mark('smart paste: nothing noted, normal paste');
        log('smart paste: no copied clips known, pasted normally -', spCopyAt ? 'last copy ' + Math.round((Date.now() - spCopyAt) / 1000) + 's ago, ' + (spNoted ? 'clips noted' : 'nothing found') : 'no copy (Ctrl+C / cut) seen since FX Drop started');
        return;
      }
      if (r.guessed) log('smart paste: used the selected clips (nothing was noted at copy time)');
      mark('smart paste to ' + [r.video, r.audio].filter(Boolean).join(' + ') + (r.added ? ' (+' + r.added + ' tracks)' : ''));
      await wait(700); // let Premiere finish pasting before the old track targeting comes back
      try { await bridge.run('spRestore', {}, 3000); } catch (e) { log('smart paste: could not restore track targeting -', e.message); }
    } finally { spBusy = false; }
  });
  async function pasteImageFromCtrlV() {
    try {
      const out = { kind: 'paste', res: await pasteClipboardImage() };
      const d = describe(PASTE_ITEM, out);
      showToast(d);
      log('action ok paste (Ctrl+V)', out.res && out.res.track, out.res && out.res.file);
    } catch (e) {
      const f = friendly(e);
      log('action failed paste (Ctrl+V)', f.code, f.message);
      showToast({ text: f.message, sub: 'Paste image', tone: 'error' });
    }
  }

  // The old Smart Paste (a separate panel + AutoHotkey script) would fight FX Drop over the same
  // keys: stop its script and move its panel aside (kept in FX Drop's folder, nothing deleted).
  const OLD_SP_DIR = path.join(process.env.APPDATA || '', 'Adobe', 'CEP', 'extensions', 'SmartPaste');
  let oldSpDone = false, oldSpTries = 0;
  function disableOldSmartPaste() {
    if (oldSpDone || process.platform !== 'win32' || settings.get('smartPaste') === false) return;
    helper.stopOldSmartPaste();
    if (!fs.existsSync(OLD_SP_DIR)) { oldSpDone = true; return; }
    setTimeout(() => {
      const dest = path.join(USER, 'old Smart Paste');
      try {
        fs.rmSync(dest, { recursive: true, force: true });
        fs.renameSync(OLD_SP_DIR, dest);
        oldSpDone = true;
        log('old Smart Paste switched off (moved to', dest + ')');
        showToast({ text: 'Smart Paste is now part of FX Drop', sub: 'The old Smart Paste and its AutoHotkey script are switched off', tone: 'ok', ms: 6000 });
      } catch (e) {
        // Premiere still has its panel open: try again later (its script is stopped meanwhile)
        if (oldSpTries++ < 1) log('old Smart Paste is in use, will retry:', e.code || e.message);
        setTimeout(disableOldSmartPaste, 120000);
      }
    }, 2500);
  }

  // ---- keyboard for the search box while Premiere keeps focus
  let popupMode = null; // 'keys' (Premiere keeps focus) | 'focus' (classic) | null
  let lastFg = null;
  // tell the helper we're alive while it holds the keyboard (it lets go by itself if we stop)
  setInterval(() => { if (popupMode === 'keys' && popup && popup.isVisible()) helper.keysAlive(); }, 1500);
  let closedByKeyAt = 0;
  function parseAccel(acc) {
    const parts = String(acc || '').split('+').map((x) => x.trim().toLowerCase());
    const key = parts.pop() || '';
    const named = { space: 0x20, tab: 0x09, enter: 0x0d, return: 0x0d, escape: 0x1b, esc: 0x1b, backspace: 0x08, delete: 0x2e, insert: 0x2d,
      up: 0x26, down: 0x28, left: 0x25, right: 0x27, home: 0x24, end: 0x23, pageup: 0x21, pagedown: 0x22 };
    let vk = named[key];
    if (vk === undefined && /^f([1-9]|1[0-2])$/.test(key)) vk = 0x6f + Number(key.slice(1));
    if (vk === undefined && /^[a-z0-9]$/.test(key)) vk = key.toUpperCase().charCodeAt(0);
    return {
      vk, shift: parts.includes('shift'), alt: parts.includes('alt') || parts.includes('option'),
      ctrl: parts.some((x) => ['control', 'ctrl', 'commandorcontrol', 'cmdorctrl'].includes(x)),
    };
  }
  helper.on('key', (ev) => {
    if (popupMode !== 'keys' || !popup.isVisible()) return;
    lastActivity = Date.now();
    const hk = parseAccel(settings.get('hotkey'));
    if ((hk.vk === ev.vk && hk.ctrl === ev.ctrl && hk.shift === ev.shift && hk.alt === ev.alt) || (ev.alt && !ev.ctrl && ev.vk === 0x73)) { // shortcut again, or Alt+F4
      closedByKeyAt = Date.now();
      hidePopup(false);
      return;
    }
    popup.webContents.send('popup:key', { key: keyName(ev), text: ev.text, shift: ev.shift, ctrl: ev.ctrl, alt: ev.alt });
  });
  helper.on('click', () => {
    if (popupMode !== 'keys' || !popup.isVisible() || dragging) return;
    // a click anywhere outside the search box closes it (the click itself still goes where it was aimed)
    setTimeout(() => {
      if (popupMode !== 'keys' || !popup.isVisible() || dragging) return;
      const pt = screen.getCursorScreenPoint();
      const b = popup.getBounds();
      const inside = pt.x >= b.x + MARGIN && pt.x < b.x + b.width - MARGIN && pt.y >= b.y + MARGIN && pt.y < b.y + b.height - MARGIN;
      if (!inside) hidePopup(false);
    }, 30);
  });
  // Clicks on the search box while Premiere keeps focus: Windows doesn't hand a never-activated
  // window its button press, so FX Drop passes the press in itself. The release still arrives
  // normally; a second (synthetic) release is harmless, so every click lands exactly once.
  let injectedDown = false;
  function popupPoint() {
    const pt = screen.getCursorScreenPoint();
    const b = popup.getBounds();
    const x = pt.x - b.x, y = pt.y - b.y;
    return { x, y, onCard: x >= MARGIN && x < b.width - MARGIN && y >= MARGIN && y < b.height - MARGIN };
  }
  helper.on('mdown', () => {
    if (popupMode !== 'keys' || !popup.isVisible() || dragging) return;
    const p = popupPoint();
    if (!p.onCard) return;
    lastActivity = Date.now();
    injectedDown = true;
    popup.webContents.sendInputEvent({ type: 'mouseDown', x: Math.round(p.x), y: Math.round(p.y), button: 'left', clickCount: 1 });
  });
  helper.on('mup', () => {
    if (!injectedDown) return;
    injectedDown = false;
    if (!popup || popup.isDestroyed() || !popup.isVisible()) return;
    const p = popupPoint();
    popup.webContents.sendInputEvent({ type: 'mouseUp', x: Math.round(p.x), y: Math.round(p.y), button: 'left', clickCount: 1 });
  });
  helper.on('close', () => { if (popupMode === 'keys') hidePopup(false); }); // Alt+Tab
  helper.on('keysfail', () => {
    // the keyboard couldn't be taken - switch this search box to the classic way
    if (popupMode !== 'keys' || !popup.isVisible()) return;
    mark('search box switched to taking focus');
    popupMode = 'focus';
    popup.setFocusable(true);
    if (!helper.open(hwndOf(popup))) { popup.show(); popup.focus(); }
    setTimeout(() => { if (popup.isVisible()) popup.webContents.focus(); }, 200);
    popup.webContents.send('popup:remoteKeys', false);
  });
  let awaitingOpen = false;
  helper.on('opened', () => {
    if (!awaitingOpen) return;
    awaitingOpen = false;
    setTimeout(() => { if (popup.isVisible()) popup.webContents.focus(); }, 20);
  });

  // ------------------------------------------------------------ windows
  const ICON = nativeImage.createFromPath(path.join(__dirname, 'assets', 'icon.png'));

  function createPopup() {
    popup = new BrowserWindow({
      width: POPUP.w, height: POPUP.h, show: false, frame: false, transparent: true, resizable: false,
      movable: false, minimizable: false, maximizable: false, fullscreenable: false, skipTaskbar: true,
      alwaysOnTop: true, hasShadow: false, backgroundColor: '#00000000', icon: ICON, title: 'FX Drop',
      // On Windows the search box never takes focus from Premiere (Premiere stalls for seconds every
      // time it gets focus back); the helper hands it the keyboard instead while it's open.
      focusable: process.platform !== 'win32',
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false, backgroundThrottling: false, spellcheck: false, autoplayPolicy: 'no-user-gesture-required' },
    });
    popup.setAlwaysOnTop(true, 'pop-up-menu');
    popup.loadFile(path.join(__dirname, 'renderer', 'popup.html'));
    const mine = popup;
    mine.webContents.on('render-process-gone', (e, d) => { log('search box stopped working:', d && d.reason); if (popup === mine) rebuildPopup('stopped', false); });
    mine.on('unresponsive', () => log('search box is not responding'));
    popup.on('blur', () => {
      if (popupMode === 'keys' || dragging) return;
      if (Date.now() - popupShownAt < 250) return;
      hidePopup(false);
    });
    popup.webContents.on('before-input-event', (e, input) => {
      if (input.type === 'keyDown' && input.key === 'F12' && !app.isPackaged) popup.webContents.openDevTools({ mode: 'detach' });
    });
  }

  function createToast() {
    toast = new BrowserWindow({
      width: 460, height: 120, show: false, frame: false, transparent: true, resizable: false, focusable: false,
      skipTaskbar: true, alwaysOnTop: true, hasShadow: false, backgroundColor: '#00000000',
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false },
    });
    toast.setAlwaysOnTop(true, 'pop-up-menu');
    toast.setIgnoreMouseEvents(true);
    toast.loadFile(path.join(__dirname, 'renderer', 'toast.html'));
  }

  let lastPopupBounds = null;
  let loggedMode = null;
  // The search box is a see-through window: if its page has died or Windows has stopped drawing it,
  // opening it shows nothing at all. So every open is checked - the page must answer that it drew,
  // and (now and then) a picture of the window must not be empty. If not, the window is built anew
  // and opened again, once.
  let drawTimer = null;
  let drawChecked = 0; // when a picture of the window was last checked
  let rebuilds = [];
  function rebuildPopup(why, reopen, atCenter) {
    const nowT = Date.now();
    rebuilds = rebuilds.filter((t) => nowT - t < 60000);
    if (rebuilds.length >= 3) { log('search box: not rebuilding again (' + why + ')'); return; }
    rebuilds.push(nowT);
    log('search box rebuilt:', why);
    clearTimeout(drawTimer);
    const old = popup;
    try { if (popupMode === 'keys') helper.keysOff(); } catch (e) {}
    popupMode = null;
    try { old.removeAllListeners(); old.destroy(); } catch (e) {}
    createPopup();
    drawChecked = 0;
    if (reopen) popup.webContents.once('did-finish-load', () => setTimeout(() => openPopup(atCenter, true), 150));
  }
  ipcMain.on('popup:shown', () => {
    clearTimeout(drawTimer);
    drawTimer = null;
    if (Date.now() - drawChecked < 10 * 60000) return;
    const win = popup;
    setTimeout(async () => {
      if (win !== popup || !win.isVisible()) return;
      try {
        const img = await win.webContents.capturePage();
        if (win !== popup || !win.isVisible()) return;
        const size = img.getSize();
        const bmp = size.width && size.height ? img.toBitmap() : Buffer.alloc(0);
        let seen = 0;
        for (let i = 3; i < bmp.length; i += 4 * 97) if (bmp[i] > 8) seen++;
        if (!seen) {
          // right after a rebuild an empty picture proves nothing more: leave it be
          if (lastAgain) { log('search box: picture still empty after rebuild'); drawChecked = Date.now(); return; }
          rebuildPopup('nothing was drawn', true, lastAtCenter);
          return;
        }
        drawChecked = Date.now();
      } catch (e) { log('search box check failed', e && e.message); }
    }, 250);
  });
  let lastAtCenter = false;
  let lastAgain = false;

  function openPopup(atCenter, again) {
    lastAtCenter = !!atCenter;
    lastAgain = !!again;
    clearTimeout(drawTimer);
    drawTimer = setTimeout(() => { if (popup.isVisible()) rebuildPopup('it did not draw', !again, atCenter); }, 1500);
    lastActivity = Date.now();
    const pt = screen.getCursorScreenPoint();
    const wa = screen.getDisplayNearestPoint(pt).workArea;
    let x = atCenter ? wa.x + (wa.width - POPUP.w) / 2 : pt.x - MARGIN - 44;
    let y = atCenter ? wa.y + wa.height * 0.18 : pt.y - MARGIN - 30;
    x = Math.max(wa.x, Math.min(x, wa.x + wa.width - POPUP.w));
    y = Math.max(wa.y, Math.min(y, wa.y + wa.height - POPUP.h));
    lastPopupBounds = { x: Math.round(x), y: Math.round(y), width: POPUP.w, height: POPUP.h };
    if (!atCenter || (helper.foreground && isPremiere(helper.foreground.name))) notePremiereDisplay();
    popup.setBounds(lastPopupBounds);
    if (helper.foreground && isPremiere(helper.foreground.name)) lastPremiereHwnd = helper.foreground.hwnd;
    const keysMode = process.platform === 'win32' && helperOk && helper.keysOn();
    popupMode = keysMode ? 'keys' : 'focus';
    if (popupMode !== loggedMode) { loggedMode = popupMode; log('search box:', keysMode ? 'Premiere keeps focus' : 'takes focus (classic)'); }
    mark('search opened' + (keysMode ? '' : ' (takes focus)'));
    watchPremiere(lastPremiereHwnd);
    popup.webContents.send('popup:open', { status: lastStatus, connected, restart: pluginOutdated(), settings: rendererSettings(), remoteKeys: keysMode });
    setTimeout(sendClip, 0);
    popupShownAt = Date.now();
    if (keysMode) {
      // Premiere keeps focus the whole time; keys arrive through the helper
      popup.showInactive();
    } else if (process.platform === 'win32' && (popup.setFocusable(true), helper.open(hwndOf(popup)))) {
      // fallback: hand focus to the popup (the helper notes which panel had it, to give it back)
      // the helper waits until the shortcut keys are let go before it brings the popup forward
      popup.showInactive();
      awaitingOpen = true;
      setTimeout(() => { if (awaitingOpen) { awaitingOpen = false; if (popup.isVisible()) popup.webContents.focus(); } }, 1800);
    } else {
      popup.show();
      popup.focus();
      popup.webContents.focus();
    }
    syncHotkey();
    refreshStatus().then((st) => {
      if (popup.isVisible()) popup.webContents.send('popup:status', { status: st, connected, restart: pluginOutdated() });
    });
  }

  function hwndOf(win) {
    const h = win.getNativeWindowHandle();
    return h.length >= 8 ? h.readBigUInt64LE(0).toString() : String(h.readUInt32LE(0));
  }

  function hidePopup(returnFocus) {
    if (!popup || !popup.isVisible()) return;
    clearTimeout(drawTimer);
    popup.webContents.send('popup:closing');
    popup.hide();
    mark('search closed');
    injectedDown = false;
    if (popupMode === 'keys') {
      helper.keysOff(); // Premiere never lost focus, nothing to give back
    } else if (returnFocus && !helper.restore() && lastPremiereHwnd) {
      setTimeout(() => helper.focus(lastPremiereHwnd), 60);
    }
    if (process.platform === 'win32' && popupMode === 'focus') popup.setFocusable(false);
    popupMode = null;
  }

  let toastTimer = null;
  // Every message appears in the same place: top centre of the screen Premiere is on
  // (the screen you last used Premiere or FX Drop on), never next to the mouse.
  let premiereDisplayId = null;
  function notePremiereDisplay() {
    try { premiereDisplayId = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).id; } catch (e) {}
  }
  function toastDisplay() {
    const all = screen.getAllDisplays();
    return all.find((d) => d.id === premiereDisplayId) || screen.getPrimaryDisplay() || all[0];
  }
  function showToast(payload) {
    if (!toast || toast.isDestroyed()) return;
    const wa = toastDisplay().workArea;
    toast.setBounds({ x: Math.round(wa.x + (wa.width - 460) / 2), y: Math.round(wa.y + 28), width: 460, height: 120 });
    toast.webContents.send('toast', payload);
    toast.showInactive();
    mark('message shown: ' + payload.text);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { if (!toast.isDestroyed()) toast.hide(); }, payload.ms || (payload.tone === 'error' ? 5200 : 2200));
  }

  // ---------------------------------------------------------------- what's new
  // A page inside Settings (content: whatsnew.json). Nothing pops up: after an update a small
  // "New" mark shows in the search box and in the settings menu until the page has been opened.
  function whatsNewEntries(since) {
    let all = [];
    try { all = JSON.parse(fs.readFileSync(path.join(__dirname, 'whatsnew.json'), 'utf8')); } catch (e) { log('whatsnew.json unreadable', e.message); }
    return all.filter((e) => cmpVer(e.version, VERSION) <= 0 && (!since || cmpVer(e.version, since) > 0));
  }
  // the version whose news this person had already seen when FX Drop started (kept for the session,
  // so the "New for you" tags stay put after the page has been opened)
  let whatsNewSince = null;
  function initWhatsNew() {
    let seen = settings.get('whatsNewSeen');
    // brand-new install: the welcome covers it, nothing is "new"
    if (!seen && !settings.get('welcomeDone')) { seen = VERSION; settings.set({ whatsNewSeen: VERSION }); }
    // people who had FX Drop before this existed: everything from 1.2.0 on is new to them
    whatsNewSince = seen || '1.2.0';
    if (whatsNewUnseen()) log("what's new: unseen since", whatsNewSince);
  }
  function whatsNewUnseen() {
    const seen = settings.get('whatsNewSeen') || whatsNewSince || VERSION;
    return cmpVer(VERSION, seen) > 0 && whatsNewEntries(seen).length > 0;
  }
  function whatsNewData() {
    return { entries: whatsNewEntries(null), unseen: whatsNewUnseen(), seenBefore: whatsNewSince };
  }
  ipcMain.on('whatsnew:seen', () => {
    if (settings.get('whatsNewSeen') === VERSION) return;
    settings.set({ whatsNewSeen: VERSION });
    log("what's new: seen");
    if (popup && !popup.isDestroyed()) popup.webContents.send('popup:whatsNew', false);
  });

  function openSettings(page) {
    page = typeof page === 'string' && /^[a-z]+$/.test(page) ? page : '';
    if (settingsWin && !settingsWin.isDestroyed()) {
      if (page) settingsWin.webContents.send('settings:page', page);
      settingsWin.show(); settingsWin.focus(); return;
    }
    settingsWin = new BrowserWindow({
      width: 760, height: 720, minWidth: 640, minHeight: 520, show: false, title: 'FX Drop Settings',
      backgroundColor: '#1d1f22', icon: ICON, autoHideMenuBar: true,
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false },
    });
    settingsWin.setMenuBarVisibility(false);
    settingsWin.loadFile(path.join(__dirname, 'renderer', 'settings.html'), page ? { hash: page } : undefined);
    settingsWin.once('ready-to-show', () => settingsWin.show());
    settingsWin.on('closed', () => { settingsWin = null; });
  }

  function updateTray() {
    if (!tray) return;
    const acc = prettyAccel(settings.get('hotkey'));
    tray.setToolTip(connected ? `FX Drop — connected to Premiere (${acc})` : 'FX Drop — waiting for Premiere');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: `Open search   ${acc}`, click: () => openPopup(true) },
      { label: 'Settings…', click: () => openSettings() },
      { label: 'Rescan FX library', click: () => { loadPremierePresets(); scanLibrary(); } },
      { label: 'Check for updates', click: () => trayCheckForUpdates() },
      { label: "What's new", click: () => openSettings('whatsnew') },
      { type: 'separator' },
      { label: connected ? 'Premiere: connected' : 'Premiere: not connected', enabled: false },
      { type: 'separator' },
      { label: 'Quit FX Drop', click: () => app.quit() },
    ]));
  }

  function prettyAccel(a) {
    return String(a || '').replace(/CommandOrControl|Control/g, 'Ctrl').replace(/\+/g, '+');
  }

  function rendererSettings() {
    const s = settings.all();
    return {
      autoPreview: s.autoPreview, previewVolume: s.previewVolume, lastScope: s.lastScope, lastQuery: s.lastQuery,
      hotkey: prettyAccel(s.hotkey), adjSeconds: s.adjSeconds, vfxIncludeAudio: s.vfxIncludeAudio,
      hasLibrary: s.libraryFolders.length > 0, pasteFit: s.pasteFit, pasteMotion: s.pasteMotion, pasteZoomTo: s.pasteZoomTo,
      whatsNew: whatsNewUnseen(), collapsed: s.collapsed || [], profiles: profilesInfo(),
    };
  }

  // ------------------------------------------------------------ actions
  // ---------------------------------------------------------------- pasting a copied image
  const PASTE_ID = 'paste:clipboard';
  const PASTE_ITEM = { id: PASTE_ID, type: 'paste', name: 'Paste copied image' };
  const IMAGE_FILE = /\.(png|jpe?g|gif|bmp|tiff?|psd)$/i;
  let lastPastedSig = null;
  // a file copied in Explorer (Windows keeps its path on the clipboard)
  function copiedFile() {
    if (process.platform !== 'win32') return null;
    try {
      const buf = clipboard.readBuffer('FileNameW');
      if (!buf || !buf.length) return null;
      const p = buf.toString('ucs2').split('\0')[0];
      return p && fs.existsSync(p) ? p : null;
    } catch (e) { return null; }
  }
  // what's on the clipboard: an image (copied from a browser, a screenshot) or a copied image file
  function readClip() {
    let img = null, file = null;
    try { img = clipboard.readImage(); } catch (e) { img = null; }
    if (!img || img.isEmpty()) {
      // some browsers only leave a PNG copy on the clipboard
      for (const fmt of ['PNG', 'image/png']) {
        try {
          const buf = clipboard.readBuffer(fmt);
          if (buf && buf.length > 8) { const pi = nativeImage.createFromBuffer(buf); if (!pi.isEmpty()) { img = pi; break; } }
        } catch (e) {}
      }
    }
    if (!img || img.isEmpty()) {
      img = null;
      const f = copiedFile();
      if (f && IMAGE_FILE.test(f)) {
        file = f;
        try { const fi = nativeImage.createFromPath(f); if (!fi.isEmpty()) img = fi; } catch (e) {}
      }
    }
    if (!img && !file) return null;
    const size = img ? img.getSize() : { width: 0, height: 0 };
    return { img, file, w: size.width, h: size.height };
  }
  function shrink(img, max) {
    const { width, height } = img.getSize();
    if (width <= max && height <= max) return img;
    return width >= height ? img.resize({ width: max, quality: 'good' }) : img.resize({ height: max, quality: 'good' });
  }
  function clipSig(c) {
    if (c.file) return 'file:' + c.file;
    try { return require('crypto').createHash('sha1').update(shrink(c.img, 64).toBitmap()).digest('hex').slice(0, 16) + ':' + c.w + 'x' + c.h; } catch (e) { return null; }
  }
  // tells the search box whether there's an image to paste (after it's shown, so opening stays instant)
  let lastClipNote = '';
  function sendClip() {
    let info = null;
    try {
      const c = readClip();
      // one log line whenever the clipboard looks different (helps when a picture isn't seen)
      let formats = [];
      try { formats = clipboard.availableFormats(); } catch (e) {}
      const note = c ? `picture ${c.w}x${c.h}${c.file ? ' (file)' : ''}` : 'no picture';
      const key = note + '|' + formats.join(',');
      if (key !== lastClipNote) { lastClipNote = key; log('clipboard:', note, '- formats:', formats.join(', ') || 'none'); }
      if (c) {
        let text = '';
        try { text = clipboard.readText().trim(); } catch (e) {}
        // browsers sometimes add the picture's web address as text - that doesn't count as text
        const realText = !!text && !/^https?:\/\/\S+$/i.test(text) && !/<img\b/i.test(text);
        info = {
          w: c.w, h: c.h, file: !!c.file, hasText: realText,
          thumb: c.img ? shrink(c.img, 120).toDataURL() : null,
          big: c.img ? shrink(c.img, 540).toDataURL() : null,
          pasted: clipSig(c) === lastPastedSig,
        };
      }
    } catch (e) { log('clipboard check failed', e.message); }
    if (popup && !popup.isDestroyed()) popup.webContents.send('popup:clip', info);
  }
  // A Transform effect that zooms 100% -> N% over the whole image (its own effect, so the image's
  // own size in Motion can still be changed and the zoom stays centred). Same shape as a preset.
  function slowZoomPreset(endPct) {
    const to = Math.max(100.5, Math.min(200, Number(endPct) || 105));
    const keep = (name, kind) => ({ name, kind, value: null, keys: [] });
    return {
      name: 'FX Drop slow zoom', media: 'video',
      components: [{
        matchName: 'AE.ADBE Geometry2', displayName: 'Transform', instanceName: 'Transform', intrinsic: false, media: 'video',
        channelType: null, anchor: 0, anchorLen: 1, hasPrivateData: false,
        params: [
          keep('Anchor Point', 'point'), keep('Position', 'point'),
          { name: '', kind: 'bool', value: true, keys: [] }, // Uniform Scale
          { name: 'Scale Height', kind: 'float', value: 100, timeVarying: true, keys: [{ t: 0, v: 100, i: 0 }, { t: 0.999, v: to, i: 0 }] },
          keep('Scale Width', 'float'), keep('Skew', 'float'), keep('Skew Axis', 'float'), keep('Rotation', 'float'),
          keep('Opacity', 'float'), keep('', 'bool'), keep('Shutter Angle', 'float'), keep('Sampling', 'int'),
        ],
      }],
    };
  }

  // Premiere can give paths in Windows' long form (\\?\C:\...), which some tools can't use
  function plainPath(p) {
    if (!p) return p;
    let s = String(p);
    if (/^\\\\\?\\UNC\\/i.test(s)) s = '\\\\' + s.slice(8);
    else if (/^\\\\\?\\/.test(s)) s = s.slice(4);
    return s;
  }
  async function pasteFolder() {
    let pp = lastStatus && lastStatus.projectPath;
    if (!pp) { const st = await refreshStatus(); pp = st && st.projectPath; }
    pp = plainPath(pp);
    if (pp && /\.prproj$/i.test(pp) && fs.existsSync(path.dirname(pp))) return path.join(path.dirname(pp), 'FX Drop Pastes');
    return path.join(app.getPath('documents'), 'FX Drop Pastes');
  }
  async function pasteClipboardImage() {
    let c = readClip();
    if (!c && process.platform !== 'win32') { await new Promise((r) => setTimeout(r, 80)); c = readClip(); }
    if (!c && process.platform === 'win32' && helperOk) {
      // let the window helper fetch the picture itself (it reads the clipboard a different way,
      // and waits if another app is using it). It saves to a plain temp path; FX Drop moves it.
      const tmp = path.join(require('os').tmpdir(), 'fxdrop-paste-' + Date.now() + '.png');
      const r = await helper.clipSave(tmp);
      if (r.ok && fs.existsSync(tmp)) {
        const dir = await pasteFolder();
        fs.mkdirSync(dir, { recursive: true });
        const hash = require('crypto').createHash('sha1').update(fs.readFileSync(tmp)).digest('hex').slice(0, 10);
        const named = path.join(dir, `Pasted image ${hash}.png`);
        if (!fs.existsSync(named)) fs.copyFileSync(tmp, named);
        fs.rmSync(tmp, { force: true });
        c = { img: null, file: named, w: r.w, h: r.h, saved: true };
      } else {
        try { fs.rmSync(tmp, { force: true }); } catch (e) {}
        log('paste image: the helper found no picture either -', r.why);
      }
    }
    if (!c) {
      let formats = [];
      try { formats = clipboard.availableFormats(); } catch (e) {}
      log('paste image: no picture found - clipboard formats:', formats.join(', ') || 'none');
      throw Object.assign(new Error('Copy an image first (right-click it › Copy image), then paste.'), { code: 'NO_IMAGE' });
    }
    let file = c.file;
    if (!file) {
      const png = c.img.toPNG();
      const hash = require('crypto').createHash('sha1').update(png).digest('hex').slice(0, 10);
      const dir = await pasteFolder();
      fs.mkdirSync(dir, { recursive: true });
      file = path.join(dir, `Pasted image ${hash}.png`);
      if (!fs.existsSync(file)) fs.writeFileSync(file, png);
    }
    const fit = settings.get('pasteFit') !== false && c.w > 0 && c.h > 0 ? { w: c.w, h: c.h } : null;
    const motion = settings.get('pasteMotion') !== false ? slowZoomPreset(settings.get('pasteZoomTo')) : null;
    const res = await runPremiere('insertMedia', { path: file, kind: 'image', bin: 'Pasted Images', fit, motion });
    lastPastedSig = c.saved ? null : clipSig(c);
    res.file = file;
    return res;
  }

  function friendly(e) {
    return { message: e.message || String(e), code: e.code || 'ERROR' };
  }

  async function perform(item, alt) {
    const timeBase = settings.get('keyframeTimeBase');
    if (item.type === 'paste') return { kind: 'paste', res: await pasteClipboardImage() };
    if (item.type === 'sfx' || item.type === 'vfx') {
      return {
        kind: 'insert',
        res: await runPremiere('insertMedia', {
          path: item.path, kind: item.kind, duration: item.dur || 0,
          hasAudio: item.hasAudio, includeAudio: settings.get('vfxIncludeAudio'),
          volumeDb: Number(settings.get('sfxVolumeDb')) || 0,
        }),
      };
    }
    if (item.type === 'effect') {
      if (alt && item.media === 'video') {
        return { kind: 'adjust', res: await runPremiere('addAdjustmentLayer', { effect: item.name, seconds: settings.get('adjSeconds'), span: settings.get('adjSpanSelection') ? 'selection' : 'playhead' }) };
      }
      return { kind: 'effect', res: await runPremiere('applyEffect', { name: item.name, media: item.media, matchName: effectMatchName(item.name, item.media) }) };
    }
    if (item.type === 'preset') {
      const recipe = catalog.recipes.get(item.id);
      if (!recipe) throw Object.assign(new Error('That preset is no longer available.'), { code: 'GONE' });
      const asLayer = (alt ? !item.adjDefault : item.adjDefault) && recipe.media !== 'audio';
      if (asLayer) {
        return { kind: 'adjust', res: await runPremiere('addAdjustmentLayer', { preset: recipe, timeBase, seconds: settings.get('adjSeconds'), span: settings.get('adjSpanSelection') ? 'selection' : 'playhead' }) };
      }
      return { kind: 'preset', res: await runPremiere('applyPreset', { preset: recipe, timeBase }) };
    }
    throw new Error('Unknown item');
  }

  function describe(item, out) {
    const r = out.res || {};
    const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
    let text, sub = [];
    if (out.kind === 'paste') {
      text = `Image → ${r.track}`;
      if (typeof r.scale === 'number' && r.scale !== 100) text += ` · fitted (${r.scale}%)`;
      if (r.motion) text += ' · slow zoom';
      if (r.createdTrack) sub.push('added a new track');
    } else if (out.kind === 'insert') {
      text = `${item.name} → ${r.track}${r.audioTrack ? ' + ' + r.audioTrack : ''}`;
      if (typeof r.volumeDb === 'number') text += ` · ${r.volumeDb > 0 ? '+' : r.volumeDb < 0 ? '−' : ''}${Math.abs(r.volumeDb)} dB`;
      if (r.createdTrack) sub.push('added a new track');
    } else if (out.kind === 'effect') {
      text = `${item.name} → ${plural(r.applied, 'clip')}`;
    } else if (out.kind === 'preset') {
      text = `${item.name} → ${plural(r.applied, 'clip')}`;
    } else {
      text = `${item.name} → adjustment layer on ${r.track}`;
      if (r.createdTrack) sub.push('added a new track');
    }
    const st = r.stats;
    if (st) {
      if (st.missing && st.missing.length) sub.push('skipped ' + Array.from(new Set(st.missing)).join(', '));
      if (st.skipped) sub.push("some settings (masks, curves, text) can't be copied");
      if (st.failed) sub.push(`Premiere didn’t take ${plural(st.failed, 'setting')}`);
    }
    if (r.warnings && r.warnings.length) sub.push(r.warnings[0]);
    return { text, sub: sub.join(' · '), tone: sub.length ? 'warn' : 'ok' };
  }

  function recordUse(item) {
    const u = usage.data.usage[item.id] || { n: 0, t: 0 };
    u.n++; u.t = Date.now();
    usage.data.usage[item.id] = u;
    usage.saveSoon();
    item.uses = u.n; item.lastUsed = u.t;
  }

  // ------------------------------------------------------------ IPC
  ipcMain.handle('popup:ready', () => ({ items: catalog.items, settings: rendererSettings(), connected, status: lastStatus }));

  ipcMain.on('popup:hide', (e, returnFocus) => hidePopup(returnFocus !== false));
  ipcMain.handle('clipboard:read', () => clipboard.readText());
  ipcMain.on('clipboard:write', (e, text) => clipboard.writeText(String(text || '')));

  // the same item picked twice within a moment (a double click) is only applied once
  let lastPick = { id: null, at: 0 };
  ipcMain.handle('popup:action', async (e, { id, alt }) => {
    const item = id === PASTE_ID ? PASTE_ITEM : byId.get(id);
    if (!item) return { ok: false, error: 'Item not found' };
    if (lastPick.id === id && Date.now() - lastPick.at < 700) { log('ignored a double pick of', item.name); return { ok: true, text: '', sub: '' }; }
    lastPick = { id, at: Date.now() };
    const keepOpen = !!alt && (item.type === 'sfx' || item.type === 'vfx');
    if (!keepOpen) hidePopup(true);
    lastActivity = Date.now();
    actionsRunning++;
    const started = Date.now();
    mark(`${item.type} "${item.name}" sent`);
    try {
      const out = await perform(item, keepOpen ? false : alt);
      out.roundTripMs = Date.now() - started;
      out.route = lastRoute;
      mark(`${item.type} "${item.name}" done via ${lastRoute === 'plugin' ? 'plugin' : 'old script route'} in ${out.roundTripMs}ms`);
      if (item.type !== 'paste') recordUse(item);
      const d = describe(item, out);
      if (keepOpen) {
        refreshStatus().then((st) => popup.webContents.send('popup:status', { status: st, connected, restart: pluginOutdated() }));
      } else {
        showToast(d);
      }
      // went the old way although the plugin is installed: say how to fix that (once per Premiere session)
      if (out.route === 'classic') setTimeout(() => pluginReminder(true), 2600);
      log('action ok', item.type, item.name, out.roundTripMs + 'ms', 'via ' + out.route, out.res);
      if (!keepOpen) helper.check();
      return { ok: true, ...d };
    } catch (err) {
      const f = friendly(err);
      log('action failed', item.type, item.name, f.code, f.message);
      if (!keepOpen) showToast({ text: f.message, sub: item.name, tone: 'error' });
      return { ok: false, error: f.message, code: f.code };
    } finally {
      actionsRunning--;
      lastActivity = Date.now();
    }
  });

  function profilesChanged(starsChanged) {
    usage.saveSoon();
    if (starsChanged) rebuild();
    else if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed');
    if (popup && !popup.isDestroyed()) popup.webContents.send('popup:profiles', profilesInfo());
  }
  function switchProfile(id) {
    const d = usage.data;
    const to = d.profiles.find((x) => x.id === id);
    if (!to || to.id === d.profile) return;
    d.profile = to.id;
    d.stars = to.stars;
    profilesChanged(true);
  }
  ipcMain.on('profiles:switch', (e, id) => switchProfile(String(id)));
  ipcMain.handle('profiles:add', (e, name) => {
    const d = usage.data;
    name = String(name || '').trim().slice(0, 30);
    if (!name || d.profiles.length >= 12) return profilesInfo();
    let n = d.profiles.length + 1;
    while (d.profiles.some((x) => x.id === 'p' + n)) n++;
    d.profiles.push({ id: 'p' + n, name, stars: {} });
    switchProfile('p' + n);
    return profilesInfo();
  });
  ipcMain.handle('profiles:rename', (e, { id, name }) => {
    const x = usage.data.profiles.find((q) => q.id === id);
    name = String(name || '').trim().slice(0, 30);
    if (x && name && name !== x.name) { x.name = name; profilesChanged(false); }
    return profilesInfo();
  });
  ipcMain.handle('profiles:delete', (e, id) => {
    const d = usage.data;
    if (d.profiles.length < 2 || !d.profiles.some((x) => x.id === id)) return profilesInfo();
    const wasActive = d.profile === id;
    d.profiles = d.profiles.filter((x) => x.id !== id);
    if (wasActive) { d.profile = d.profiles[0].id; d.stars = d.profiles[0].stars; }
    profilesChanged(wasActive);
    return profilesInfo();
  });

  ipcMain.on('popup:star', (e, { id, on }) => {
    if (on) usage.data.stars[id] = 1; else delete usage.data.stars[id];
    usage.saveSoon();
    const it = byId.get(id);
    if (it) it.star = !!on;
    if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed');
  });

  ipcMain.on('popup:remember', (e, { query, scope }) => {
    settings.data.lastQuery = query;
    settings.data.lastScope = scope;
    settings.save();
  });

  ipcMain.on('popup:duration', (e, { id, dur }) => {
    const it = byId.get(id);
    if (it && it.path && dur > 0) {
      it.dur = dur;
      indexer.rememberDuration(it.path, dur);
      clearTimeout(durTimer);
      durTimer = setTimeout(() => indexer.saveCache(), 3000);
    }
  });

  ipcMain.on('popup:startDrag', (e, { id }) => {
    const it = byId.get(id);
    if (!it || !it.path) return;
    dragging = true;
    setTimeout(() => { dragging = false; }, 8000);
    try {
      e.sender.startDrag({ file: it.path, icon: ICON.resize({ width: 32, height: 32 }) });
    } catch (err) { log('drag failed', err.message); }
  });
  ipcMain.on('popup:dragEnd', () => { dragging = false; });

  ipcMain.on('popup:reveal', (e, { id }) => {
    const it = byId.get(id);
    if (it && it.path) shell.showItemInFolder(it.path);
  });
  ipcMain.on('popup:openSettings', (e, page) => { hidePopup(false); openSettings(page); });
  // folded folders in the search box (remembered between openings)
  ipcMain.on('popup:folds', (e, keys) => {
    if (Array.isArray(keys)) settings.set({ collapsed: keys.filter((k) => typeof k === 'string').slice(-1500) });
  });

  ipcMain.handle('cache:peaks', (e, { id, data }) => {
    if (data) { peaks.data[id] = data; peaks.saveSoon(); return true; }
    return peaks.data[id] || null;
  });
  ipcMain.handle('cache:thumb', (e, { id, dataUrl }) => {
    const file = path.join(THUMBS, id.replace(/[^a-z0-9]/gi, '_') + '.jpg');
    if (dataUrl) {
      try { fs.writeFileSync(file, Buffer.from(dataUrl.split(',')[1], 'base64')); } catch (err) {}
      return true;
    }
    return fs.existsSync(file) ? 'fxmedia://thumb/' + encodeURIComponent(path.basename(file)) : null;
  });

  // settings window
  ipcMain.handle('settings:get', () => {
    const counts = { sfx: 0, vfx: 0, preset: 0, effect: 0 };
    for (const it of catalog.items) counts[it.type] = (counts[it.type] || 0) + 1;
    return {
      settings: settings.all(),
      version: VERSION,
      detectedPresetFile: findPremierePresetFile(app.getPath('documents')),
      presetFile: presetFile(),
      premierePresetCount: premierePresets.presets.length,
      counts,
      connected,
      extensionInstalled: cep.isInstalled(),
      needsRestart,
      hotkeyError,
      helperOk,
      logFile: LOG,
      scanning: indexer.scanning,
      update: { enabled: updater.enabled, ...updater.state, staged: updater.staged ? updater.staged.version : null },
      premierePlugin: { connected: plugin.connected, ...(settings.get('premierePlugin') || {}) },
      whatsNew: whatsNewData(),
      profiles: profilesInfo(),
    };
  });

  ipcMain.handle('settings:set', async (e, patch) => {
    const before = settings.all();
    settings.set(patch);
    if (patch.autoUpdate) tryApplyUpdate();
    if ('hotkey' in patch || 'hotkeyOnlyInPremiere' in patch) resetHotkey();
    if (['smartPaste', 'pasteImagesCtrlV', 'smartPasteKey', 'smartCutKey', 'premierePasteKey'].some((k) => k in patch)) syncPasteKeys();
    if (patch.smartPaste === true) disableOldSmartPaste();
    if ('startWithWindows' in patch) setLoginItem();
    if ('libraryFolders' in patch) { watchLibrary(); scanLibrary(); }
    if ('premierePresetsFile' in patch || ('usePremierePresets' in patch && patch.usePremierePresets !== before.usePremierePresets)) {
      loadPremierePresets(); watchPresetFile(); rebuild();
    }
    return { ok: true, hotkeyError };
  });

  ipcMain.handle('settings:addFolder', async () => {
    const r = await dialog.showOpenDialog(settingsWin, { title: 'Choose an FX folder', properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    const folders = settings.get('libraryFolders').slice();
    if (!folders.some((f) => f.toLowerCase() === r.filePaths[0].toLowerCase())) folders.push(r.filePaths[0]);
    settings.set({ libraryFolders: folders });
    watchLibrary();
    scanLibrary();
    return folders;
  });

  ipcMain.handle('settings:createStarter', async () => {
    const r = await dialog.showOpenDialog(settingsWin, { title: 'Where should the FX Library folder go?', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    const root = path.join(r.filePaths[0], 'FX Library');
    const tree = {
      'Sound FX': ['Whooshes', 'Impacts & Hits', 'Risers', 'Pops & Clicks', 'Glitches', 'Memes', 'Transitions', 'Ambience', 'UI'],
      'Visual FX': ['Overlays', 'Light Leaks', 'Glitches', 'Explosions', 'Smoke & Dust', 'Shapes & Arrows', 'Green Screen'],
      'Preset Packs': [],
      'Adjustment Layer Packs': [],
    };
    for (const [top, subs] of Object.entries(tree)) {
      fs.mkdirSync(path.join(root, top), { recursive: true });
      for (const s of subs) fs.mkdirSync(path.join(root, top, s), { recursive: true });
    }
    fs.writeFileSync(path.join(root, 'Read me.txt'),
      'FX Drop library\r\n\r\n' +
      '- Sound FX: drop sound files (wav, mp3, aiff...) into any folder. Folder names become search words.\r\n' +
      '- Visual FX: overlays and clips (mp4, mov, png...).\r\n' +
      '- Preset Packs: .prfpset files. Their presets apply to the clips you select.\r\n' +
      '- Adjustment Layer Packs: .prfpset files meant for adjustment layers. FX Drop drops them as a new adjustment layer.\r\n' +
      '\r\nNew files show up in FX Drop automatically.\r\n');
    const folders = settings.get('libraryFolders').slice();
    if (!folders.includes(root)) folders.push(root);
    settings.set({ libraryFolders: folders });
    watchLibrary();
    scanLibrary();
    shell.openPath(root);
    return folders;
  });

  ipcMain.handle('settings:choosePresetFile', async () => {
    const r = await dialog.showOpenDialog(settingsWin, { title: 'Choose Premiere\'s preset file', properties: ['openFile'], filters: [{ name: 'Premiere presets', extensions: ['prfpset'] }] });
    if (r.canceled || !r.filePaths[0]) return null;
    settings.set({ premierePresetsFile: r.filePaths[0] });
    loadPremierePresets(); watchPresetFile(); rebuild();
    return r.filePaths[0];
  });

  ipcMain.handle('settings:reinstall', async () => {
    try {
      const r = await cep.install({ force: true });
      needsRestart = true;
      return { ok: true, path: r.path };
    } catch (e) { return { ok: false, error: e.message }; }
  });

  ipcMain.handle('settings:test', async () => {
    const st = await refreshStatus();
    return { connected, status: st };
  });

  ipcMain.on('settings:openLog', () => shell.openPath(LOG));
  ipcMain.handle('settings:installPlugin', async () => {
    const r = await installPlugin(true);
    if (!r.ok && r.ccx) shell.openPath(r.ccx); // let Creative Cloud install it after one click
    return { ok: !!r.ok };
  });
  ipcMain.handle('settings:checkUpdate', async () => {
    await checkForUpdate();
    return { ...updater.state, staged: updater.staged ? updater.staged.version : null };
  });
  ipcMain.on('settings:installUpdate', () => {
    if (!updater.staged) return;
    if (settingsWin && !settingsWin.isDestroyed()) settingsWin.close();
    showToast({ text: 'Updating FX Drop to ' + updater.staged.version, sub: 'Back in a few seconds', tone: 'ok' });
    setTimeout(() => installStaged('manual'), 1200);
  });
  ipcMain.on('settings:openFolder', (e, p) => shell.openPath(p));
  ipcMain.on('settings:tryPopup', () => openPopup(true));
  ipcMain.on('settings:rescan', () => { loadPremierePresets(); scanLibrary(); });

  // ------------------------------------------------------------ media protocol (library files + thumbnails)
  const MIME = {
    wav: 'audio/wav', mp3: 'audio/mpeg', ogg: 'audio/ogg', opus: 'audio/ogg', flac: 'audio/flac', m4a: 'audio/mp4', aac: 'audio/aac',
    aif: 'audio/aiff', aiff: 'audio/aiff', mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm',
    mkv: 'video/x-matroska', gif: 'image/gif', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', bmp: 'image/bmp',
  };
  function allowed(p) {
    const lp = path.resolve(p).toLowerCase();
    return settings.get('libraryFolders').some((r) => lp.startsWith(path.resolve(r).toLowerCase() + path.sep));
  }
  function serveFile(file, req) {
    const st = fs.statSync(file);
    const ext = path.extname(file).slice(1).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const range = req.headers.get('range');
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let start = m && m[1] ? parseInt(m[1], 10) : 0;
      let end = m && m[2] ? parseInt(m[2], 10) : st.size - 1;
      if (!(start >= 0) || start >= st.size) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${st.size}` } });
      end = Math.min(end, st.size - 1);
      const body = Readable.toWeb(fs.createReadStream(file, { start, end }));
      return new Response(body, { status: 206, headers: { 'Content-Type': type, 'Content-Length': String(end - start + 1), 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*' } });
    }
    return new Response(Readable.toWeb(fs.createReadStream(file)), { status: 200, headers: { 'Content-Type': type, 'Content-Length': String(st.size), 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*' } });
  }

  // ------------------------------------------------------------ self-update
  function feedUrl() {
    if (settings.get('updateFeed')) return settings.get('updateFeed');
    try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'update.json'), 'utf8')).feed || null; } catch (e) { return null; }
  }
  // Only a real install (…\resources\app inside FX Drop.exe) updates itself
  const canSelfUpdate = process.platform === 'win32' && app.isPackaged && path.basename(__dirname) === 'app' &&
    path.resolve(path.dirname(__dirname)) === path.resolve(process.resourcesPath);
  const updater = new Updater({
    feedUrl: canSelfUpdate ? feedUrl() : null,
    currentVersion: VERSION,
    appDir: __dirname,
    workDir: path.join(USER, 'updates'),
    log,
  });
  updater.on('state', () => { if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed'); });

  // When an update gets installed (it restarts FX Drop for a few seconds):
  //  - when FX Drop starts (nobody is using it yet), or when you click "Install now", or
  //  - after FX Drop has been unused for 30 minutes while Premiere isn't the app in front.
  // If an install doesn't take, FX Drop won't try again on its own for a day (no restart loops).
  function updateAttempt() { return settings.get('updateAttempt') || null; }
  function installBlocked() {
    const a = updateAttempt();
    return !!(a && a.failed && Date.now() - a.at < 24 * 3600000);
  }
  function installStaged(reason) {
    if (!updater.staged) return false;
    settings.set({ updateAttempt: { version: updater.staged.version, at: Date.now(), reason } });
    settings.saveNow && settings.saveNow();
    log('installing update', updater.staged.version, '(' + reason + ')');
    if (!updater.launchSwap(process.execPath, LOG, MIRROR)) return false;
    app.quit();
    return true;
  }
  let applyTimer = null;
  function tryApplyUpdate() {
    clearTimeout(applyTimer);
    if (!updater.staged || !settings.get('autoUpdate') || installBlocked()) return;
    const inPremiere = !!(helper.foreground && isPremiere(helper.foreground.name));
    const settingsOpen = settingsWin && !settingsWin.isDestroyed() && settingsWin.isVisible();
    const idle = !popup.isVisible() && !dragging && actionsRunning === 0 && !settingsOpen && !inPremiere &&
      Date.now() - lastActivity > 30 * 60000;
    if (!idle) { applyTimer = setTimeout(tryApplyUpdate, 60000); return; }
    installStaged('idle');
  }
  updater.on('ready', () => tryApplyUpdate());

  async function trayCheckForUpdates() {
    if (!updater.enabled) { showToast({ text: 'Updates aren’t set up for this copy', sub: 'Install FX Drop with its installer to get updates', tone: 'warn' }); return; }
    showToast({ text: 'Checking for updates…', sub: 'FX Drop ' + VERSION, tone: 'ok' });
    // a check may already be running in the background: wait for it instead of reporting an error
    for (let i = 0; i < 240 && updater.busy; i++) await new Promise((r) => setTimeout(r, 500));
    if (!updater.staged) await checkForUpdate();
    const st = updater.state;
    if (updater.staged) {
      showToast({ text: 'Updating FX Drop to ' + updater.staged.version, sub: 'Back in a few seconds', tone: 'ok' });
      setTimeout(() => installStaged('manual'), 1500);
    } else if (st.status === 'current') {
      showToast({ text: 'FX Drop is up to date', sub: 'Version ' + VERSION, tone: 'ok' });
    } else {
      showToast({ text: 'Couldn’t check for updates', sub: st.error || 'Try again in a moment', tone: 'error' });
    }
  }

  async function checkForUpdate() {
    if (!updater.enabled) return;
    await updater.checkAndStage();
  }
  function removeDir(d) {
    try { if (fs.existsSync(d)) fs.rmSync(d, { recursive: true, force: true }); } catch (e) { log('cleanup', d, e.message); }
  }
  // Runs first thing at startup. Returns true if FX Drop is restarting to install an update.
  let updateOutcome = null;
  function startupUpdate() {
    if (!canSelfUpdate) return false;
    const a = updateAttempt();
    if (a && cmpVer(VERSION, a.version) >= 0) {
      settings.set({ updateAttempt: null });
      updateOutcome = 'installed';
    } else if (a && !a.failed && process.argv.includes('--updated')) {
      settings.set({ updateAttempt: Object.assign({}, a, { failed: true, at: Date.now() }) });
      log('update to', a.version, 'did not install - keeping', VERSION, '(see updater lines above)');
      updateOutcome = 'failed';
    }
    removeDir(__dirname + '.old');
    removeDir(__dirname + '.failed');
    const staged = updater.stagedOnDisk();
    if (!staged) { removeDir(__dirname + '.new'); return false; }
    if (updateOutcome === 'failed' || installBlocked() || !settings.get('autoUpdate')) return false;
    return installStaged('startup');
  }

  // ------------------------------------------------------------ startup
  function setLoginItem() {
    if (process.platform !== 'win32') return;
    app.setLoginItemSettings({ openAtLogin: !!settings.get('startWithWindows'), args: ['--hidden'] });
  }

  app.on('second-instance', () => openSettings());
  app.on('window-all-closed', (e) => { /* stay in tray */ });
  app.on('will-quit', () => { globalShortcut.unregisterAll(); helper.stop(); plugin.stop(); usage.saveNow(); peaks.saveNow(); });

  app.whenReady().then(async () => {
    if (startupUpdate()) return; // restarting into the new version
    if (updateOutcome === 'failed') {
      const a = updateAttempt();
      updater.set({ status: 'error', error: `Version ${a.version} couldn’t be installed. FX Drop will try again tomorrow, or click Install now.` });
    }
    protocol.handle('fxmedia', (req) => {
      try {
        const u = new URL(req.url);
        const rest = decodeURIComponent(u.pathname.replace(/^\//, ''));
        if (u.host === 'thumb') {
          const f = path.join(THUMBS, path.basename(rest));
          return fs.existsSync(f) ? serveFile(f, req) : new Response(null, { status: 404 });
        }
        if (u.host === 'file') {
          if (!allowed(rest) || !fs.existsSync(rest)) return new Response(null, { status: 404 });
          return serveFile(rest, req);
        }
      } catch (e) { log('protocol', e.message); }
      return new Response(null, { status: 400 });
    });

    tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray.png')));
    tray.on('click', () => openPopup(true));
    updateTray();

    initWhatsNew();
    createPopup();
    createToast();

    plugin.start();
    const justUpdated = process.argv.includes('--updated');
    let premiereRestartHint = false;
    try {
      const r = await cep.install();
      if (r.changed) {
        // the Premiere-side script reloads by itself; anything else in the extension needs a Premiere restart
        const onlyScript = r.files && r.files.length && r.files.every((f) => /(^|[\\/])host\.jsx$/.test(f));
        if (!justUpdated) needsRestart = true;
        else if (!onlyScript) premiereRestartHint = true;
        log('extension installed at', r.path, r.files ? r.files.join(', ') : '');
      }
    } catch (e) { log('extension install failed', e.message); }

    setLoginItem();
    helper.start();
    setTimeout(() => installPlugin(false), 4000);
    syncHotkey();

    loadPremierePresets();
    watchPresetFile();
    rebuild();
    await scanLibrary();
    watchLibrary();
    refreshStatus();

    if (!settings.get('welcomeDone') || needsRestart) openSettings();
    if (justUpdated && updateOutcome !== 'failed') {
      setTimeout(() => showToast({
        text: 'FX Drop updated to ' + VERSION,
        sub: premiereRestartHint ? 'Restart Premiere when it suits you to finish the update'
          : whatsNewUnseen() ? "See what's new: click “New” in the search box" : 'Everything is ready',
        tone: premiereRestartHint ? 'warn' : 'ok',
      }), 2500);
    }
    if (updater.enabled) {
      setTimeout(checkForUpdate, justUpdated ? 10 * 60000 : 30000);
      setInterval(checkForUpdate, 6 * 3600000);
    }
    if (process.argv.includes('--open-popup')) setTimeout(() => openPopup(true), 800);
    if (process.env.FXDROP_DEV && !app.isPackaged) {
      require(process.env.FXDROP_DEV)({ app, popup, toast, openPopup, hidePopup, openSettings, showToast, getSettingsWin: () => settingsWin, log });
    }
    log('FX Drop', VERSION, 'ready');
  });
}
