# FX Drop window helper: reports which app is in front and can hand focus back to Premiere.
# Talks to the FX Drop app over stdin/stdout. Exits when FX Drop closes.
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class FXW {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int cmd);
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO {
    public int cbSize; public int flags; public IntPtr hwndActive; public IntPtr hwndFocus; public IntPtr hwndCapture;
    public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret; public RECT rcCaret;
  }
  [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint idThread, ref GUITHREADINFO info);
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint mapType);
  static IntPtr savedTop = IntPtr.Zero;
  static IntPtr savedFocus = IntPtr.Zero;
  static bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

  // The FX Drop shortcut is pressed while Premiere is in front. If FX Drop takes the keyboard
  // while Ctrl/Shift are still held, Premiere never sees them let go and keeps acting as if
  // they were down (Space then reads as Ctrl+Space and does nothing). So wait for them to be
  // released first, letting Premiere see the release itself. Not done for Alt: a lone Alt
  // release would open Premiere's menu bar.
  public static void WaitForModifiers(int maxMs) {
    System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
    while (sw.ElapsedMilliseconds < maxMs) {
      if (Down(0x12)) return;
      if (!Down(0x11) && !Down(0x10) && !Down(0x5B) && !Down(0x5C)) return;
      System.Threading.Thread.Sleep(4);
    }
  }

  // Safety net after handing focus back: tell the app in front that Ctrl and Shift are up
  // (only for keys that really are up), in case it missed the release while FX Drop had focus.
  public static void ReleaseModifiers() {
    int[] keys = new int[] { 0xA2, 0xA3, 0xA0, 0xA1 }; // left/right Ctrl, left/right Shift
    for (int i = 0; i < keys.Length; i++) {
      int vk = keys[i];
      if (Down(vk)) continue;
      uint flags = 0x0002; // key up
      if (vk == 0xA3) flags = flags | 0x0001; // right Ctrl is an extended key
      keybd_event((byte)vk, (byte)MapVirtualKey((uint)vk, 0), flags, UIntPtr.Zero);
    }
  }

  public static string Describe() {
    IntPtr fg = GetForegroundWindow();
    uint ignored;
    uint t = GetWindowThreadProcessId(fg, out ignored);
    GUITHREADINFO gi = new GUITHREADINFO();
    gi.cbSize = Marshal.SizeOf(typeof(GUITHREADINFO));
    IntPtr f = GetGUIThreadInfo(t, ref gi) ? gi.hwndFocus : IntPtr.Zero;
    return "fg=" + fg.ToInt64() + " saved=" + savedTop.ToInt64() + " focus=" + f.ToInt64() + " savedFocus=" + savedFocus.ToInt64() +
      " ctrl=" + (Down(0x11) ? 1 : 0) + " shift=" + (Down(0x10) ? 1 : 0) + " alt=" + (Down(0x12) ? 1 : 0);
  }
  public static uint Pid(IntPtr h) { uint p; GetWindowThreadProcessId(h, out p); return p; }
  // Remember the window in front AND the exact control inside it that has keyboard focus
  // (e.g. Premiere's timeline panel), so it can be handed back exactly as it was.
  public static void Save() {
    IntPtr fg = GetForegroundWindow();
    uint ignored;
    uint t = GetWindowThreadProcessId(fg, out ignored);
    GUITHREADINFO gi = new GUITHREADINFO();
    gi.cbSize = Marshal.SizeOf(typeof(GUITHREADINFO));
    savedFocus = GetGUIThreadInfo(t, ref gi) ? gi.hwndFocus : IntPtr.Zero;
    savedTop = fg;
  }
  public static void Restore() {
    if (savedTop == IntPtr.Zero || !IsWindow(savedTop)) return;
    Focus(savedTop);
    if (savedFocus != IntPtr.Zero && IsWindow(savedFocus)) {
      uint ignored;
      uint t = GetWindowThreadProcessId(savedTop, out ignored);
      uint me = GetCurrentThreadId();
      bool attached = (t != 0 && t != me) ? AttachThreadInput(me, t, true) : false;
      SetFocus(savedFocus);
      if (attached) AttachThreadInput(me, t, false);
    }
    if (GetForegroundWindow() == savedTop) ReleaseModifiers();
  }
  public static void Focus(IntPtr h) {
    if (h == IntPtr.Zero) return;
    IntPtr fg = GetForegroundWindow();
    uint ignored;
    uint fgThread = GetWindowThreadProcessId(fg, out ignored);
    uint me = GetCurrentThreadId();
    if (IsIconic(h)) ShowWindow(h, 9);
    bool attached = false;
    if (fgThread != 0 && fgThread != me) attached = AttachThreadInput(me, fgThread, true);
    SetForegroundWindow(h);
    BringWindowToTop(h);
    if (attached) AttachThreadInput(me, fgThread, false);
  }
}
"@

# Keyboard capture for the FX Drop search box. While the search box is open, keys go to FX Drop
# instead of Premiere, so Premiere never loses focus (it stalls for seconds whenever it gets
# focus back). Runs in its own thread with its own message loop so it can never slow typing down.
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Threading;
using System.Collections.Concurrent;
using System.Runtime.InteropServices;
public static class FXK {
  public delegate IntPtr HookProc(int code, IntPtr wParam, IntPtr lParam);
  [DllImport("user32.dll", SetLastError = true)] static extern IntPtr SetWindowsHookEx(int idHook, HookProc fn, IntPtr hMod, uint threadId);
  [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
  [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string name);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int x; public int y; }
  [StructLayout(LayoutKind.Sequential)] public struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public POINT pt; }
  [StructLayout(LayoutKind.Sequential)] public struct KBD { public uint vk; public uint scan; public uint flags; public uint time; public IntPtr extra; }
  [DllImport("user32.dll")] static extern int GetMessage(out MSG msg, IntPtr hwnd, uint min, uint max);
  [DllImport("user32.dll")] static extern bool PeekMessage(out MSG msg, IntPtr hwnd, uint min, uint max, uint remove);
  [DllImport("user32.dll")] static extern bool TranslateMessage(ref MSG msg);
  [DllImport("user32.dll")] static extern IntPtr DispatchMessage(ref MSG msg);
  [DllImport("user32.dll")] static extern bool PostThreadMessage(uint tid, uint msg, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern int ToUnicodeEx(uint vk, uint scan, byte[] state, StringBuilder buf, int cch, uint flags, IntPtr hkl);
  [DllImport("user32.dll")] static extern IntPtr GetKeyboardLayout(uint tid);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
  [DllImport("user32.dll")] static extern short GetKeyState(int vk);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);

  const uint MSG_ON = 0x8001, MSG_OFF = 0x8002;
  static HookProc kbProc = new HookProc(KbHook);
  static HookProc msProc = new HookProc(MsHook);
  static IntPtr kb = IntPtr.Zero, ms = IntPtr.Zero;
  static uint loopThread = 0;
  static bool[] swallowed = new bool[256];
  static bool[] heldBefore = new bool[256];
  static bool shift, ctrl, alt, win;
  public static volatile bool Active = false;
  public static volatile int LastAlive = 0; // FX Drop says it's alive every 1.5 s while the search box is open
  public static readonly ConcurrentQueue<string> Out = new ConcurrentQueue<string>();
  public static readonly AutoResetEvent Signal = new AutoResetEvent(false);

  static bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }
  static void Emit(string s) { Out.Enqueue(s); Signal.Set(); }

  public static bool Start() {
    ManualResetEvent ready = new ManualResetEvent(false);
    Thread t = new Thread(delegate () {
      loopThread = GetCurrentThreadId();
      MSG m;
      PeekMessage(out m, IntPtr.Zero, 0, 0, 0); // creates this thread's message queue
      ready.Set();
      while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) {
        if (m.message == MSG_ON) { Install(); continue; }
        if (m.message == MSG_OFF) { Remove(); continue; }
        TranslateMessage(ref m);
        DispatchMessage(ref m);
      }
    });
    t.IsBackground = true;
    t.Start();
    return ready.WaitOne(3000);
  }
  public static void On() { LastAlive = Environment.TickCount; Active = true; PostThreadMessage(loopThread, MSG_ON, IntPtr.Zero, IntPtr.Zero); }
  public static void Alive() { LastAlive = Environment.TickCount; }
  // if FX Drop stops answering, give the keyboard back after 5 s no matter what
  static bool Live() { return Active && unchecked(Environment.TickCount - LastAlive) < 5000; }
  public static void Off() { Active = false; PostThreadMessage(loopThread, MSG_OFF, IntPtr.Zero, IntPtr.Zero); }

  static void Install() {
    Remove();
    for (int i = 0; i < 256; i++) { swallowed[i] = false; heldBefore[i] = i > 0 && Down(i); }
    shift = Down(0x10); ctrl = Down(0x11); alt = Down(0x12); win = Down(0x5B) || Down(0x5C);
    IntPtr mod = GetModuleHandle(null);
    kb = SetWindowsHookEx(13, kbProc, mod, 0);
    ms = SetWindowsHookEx(14, msProc, mod, 0);
    Emit(kb != IntPtr.Zero ? "KEYS ON" : "KEYS FAIL " + Marshal.GetLastWin32Error());
  }
  static void Remove() {
    if (kb != IntPtr.Zero) { UnhookWindowsHookEx(kb); kb = IntPtr.Zero; }
    if (ms != IntPtr.Zero) { UnhookWindowsHookEx(ms); ms = IntPtr.Zero; }
  }

  // the text a key types on the user's own keyboard layout (e.g. æ ø å, AltGr+2 = @), as hex UTF-16
  static string Chars(KBD k, bool withCtrlAlt) {
    byte[] st = new byte[256];
    if (shift) { st[0x10] = 0x80; st[0xA0] = 0x80; }
    if (withCtrlAlt && ctrl) { st[0x11] = 0x80; st[0xA2] = 0x80; }
    if (withCtrlAlt && alt) { st[0x12] = 0x80; st[0xA5] = 0x80; }
    if ((GetKeyState(0x14) & 1) != 0) st[0x14] = 0x01;
    uint pid;
    IntPtr hkl = GetKeyboardLayout(GetWindowThreadProcessId(GetForegroundWindow(), out pid));
    StringBuilder sb = new StringBuilder(8);
    int n = ToUnicodeEx(k.vk, k.scan, st, sb, 8, 4, hkl);
    if (n <= 0) return "-";
    StringBuilder hex = new StringBuilder();
    for (int i = 0; i < n && i < sb.Length; i++) hex.Append(((int)sb[i]).ToString("x4"));
    return hex.Length > 0 ? hex.ToString() : "-";
  }

  static IntPtr KbHook(int code, IntPtr wParam, IntPtr lParam) {
    if (code < 0 || !Live()) return CallNextHookEx(IntPtr.Zero, code, wParam, lParam);
    KBD k = (KBD)Marshal.PtrToStructure(lParam, typeof(KBD));
    if ((k.flags & 0x10) != 0) return CallNextHookEx(IntPtr.Zero, code, wParam, lParam); // typed by software, not the user
    int msg = wParam.ToInt32();
    bool down = msg == 0x100 || msg == 0x104;
    uint vk = k.vk & 0xFF;
    if (vk == 0x10 || vk == 0xA0 || vk == 0xA1) shift = down;
    else if (vk == 0x11 || vk == 0xA2 || vk == 0xA3) ctrl = down;
    else if (vk == 0x12 || vk == 0xA4 || vk == 0xA5) alt = down;
    else if (vk == 0x5B || vk == 0x5C) win = down;
    // keys already held when the search box opened (e.g. Ctrl from the shortcut) stay Premiere's
    if (heldBefore[vk]) { if (!down) heldBefore[vk] = false; return CallNextHookEx(IntPtr.Zero, code, wParam, lParam); }
    if (!down) {
      if (swallowed[vk]) { swallowed[vk] = false; return (IntPtr)1; }
      return CallNextHookEx(IntPtr.Zero, code, wParam, lParam);
    }
    // never take Windows' own shortcuts
    if (win || vk == 0x5B || vk == 0x5C || vk == 0x14 || vk == 0x90 || vk == 0x91) return CallNextHookEx(IntPtr.Zero, code, wParam, lParam);
    if (alt && !ctrl && vk == 0x09) {
      // Alt+Tab: close the search box and hand Alt+Tab to Windows. Alt itself was kept from
      // Windows, so press it again on the user's behalf; the real Alt release then goes through.
      if (!(swallowed[0x12] || swallowed[0xA4] || swallowed[0xA5])) return CallNextHookEx(IntPtr.Zero, code, wParam, lParam);
      swallowed[0x12] = false; swallowed[0xA4] = false; swallowed[0xA5] = false;
      swallowed[vk] = true;
      Emit("CLOSE");
      keybd_event(0xA4, 0x38, 0, UIntPtr.Zero);
      keybd_event(0x09, 0x0F, 0, UIntPtr.Zero);
      keybd_event(0x09, 0x0F, 2, UIntPtr.Zero);
      return (IntPtr)1;
    }
    swallowed[vk] = true;
    bool isMod = vk == 0x10 || vk == 0x11 || vk == 0x12 || (vk >= 0xA0 && vk <= 0xA5);
    if (!isMod) {
      int mods = (shift ? 1 : 0) | (ctrl ? 2 : 0) | (alt ? 4 : 0);
      Emit("KEY " + vk + " " + mods + " " + Chars(k, true) + " " + Chars(k, false));
    }
    return (IntPtr)1;
  }

  // Freeze meter: asks Premiere's window a harmless "are you there" (WM_NULL) many times a second.
  // A frozen Premiere answers late; every late answer is reported with how long it took.
  static volatile bool watching = false;
  static long watchTarget = 0;
  static Thread watcher = null;
  public static void Watch(long hwnd) {
    Interlocked.Exchange(ref watchTarget, hwnd);
    watching = true;
    if (watcher != null && watcher.IsAlive) return;
    watcher = new Thread(delegate () {
      System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
      while (watching) {
        IntPtr h = new IntPtr(Interlocked.Read(ref watchTarget));
        if (h == IntPtr.Zero || !IsWindow(h)) { Thread.Sleep(250); continue; }
        IntPtr r;
        sw.Reset();
        sw.Start();
        SendMessageTimeout(h, 0, IntPtr.Zero, IntPtr.Zero, 0, 30000, out r);
        long ms = sw.ElapsedMilliseconds;
        if (ms >= 150) Emit("FREEZE " + ms);
        Thread.Sleep(60);
      }
    });
    watcher.IsBackground = true;
    watcher.Start();
  }
  public static void Unwatch() { watching = false; }

  static IntPtr MsHook(int code, IntPtr wParam, IntPtr lParam) {
    if (code >= 0 && Live()) {
      int msg = wParam.ToInt32();
      if (msg == 0x201 || msg == 0x204 || msg == 0x207) Emit("CLICK");
    }
    return CallNextHookEx(IntPtr.Zero, code, wParam, lParam);
  }
}
"@
$fxk = $false
try { [void][FXK]::Out.Count; $fxk = $true } catch { $fxk = $false }
$keysOk = $false
if ($fxk) { try { $keysOk = [bool][FXK]::Start() } catch { $keysOk = $false } }

$reader = [Console]::In
$task = $reader.ReadLineAsync()
$lastH = [IntPtr]::Zero
$names = @{}
[Console]::Out.WriteLine("READY")
if (-not $keysOk) { [Console]::Out.WriteLine("KEYS FAIL could not start") }
[Console]::Out.Flush()
while ($true) {
  if ($task.IsCompleted) {
    $line = $task.Result
    if ($line -eq $null) { break }
    if ($line.StartsWith('OPEN ')) {
      # remember where the user was, let go of the shortcut keys, then bring the popup to the front
      [FXW]::Save()
      [FXW]::WaitForModifiers(1500)
      $v = 0L
      if ([Int64]::TryParse($line.Substring(5), [ref]$v)) { [FXW]::Focus([IntPtr]$v) }
      [Console]::Out.WriteLine("OPENED")
      [Console]::Out.Flush()
    } elseif ($line -eq 'RESTORE') {
      [FXW]::Restore()
      [Console]::Out.WriteLine("RESTORED " + [FXW]::Describe())
      [Console]::Out.Flush()
    } elseif ($line -eq 'CHECK') {
      [Console]::Out.WriteLine("CHECK " + [FXW]::Describe())
      [Console]::Out.Flush()
    } elseif ($line -eq 'KEYS ON') {
      if ($keysOk) { [FXK]::On() } else { [Console]::Out.WriteLine("KEYS FAIL thread"); [Console]::Out.Flush() }
    } elseif ($line -eq 'KEYS ALIVE') {
      if ($keysOk) { [FXK]::Alive() }
    } elseif ($line -eq 'KEYS OFF') {
      if ($keysOk) { [FXK]::Off() }
    } elseif ($line.StartsWith('WATCH ')) {
      $v = 0L
      if ($fxk -and [Int64]::TryParse($line.Substring(6), [ref]$v)) { [FXK]::Watch($v) }
    } elseif ($line -eq 'UNWATCH') {
      if ($fxk) { [FXK]::Unwatch() }
    } elseif ($line.StartsWith('FOCUS ')) {
      $v = 0L
      if ([Int64]::TryParse($line.Substring(6), [ref]$v)) { [FXW]::Focus([IntPtr]$v) }
    }
    $lastH = [IntPtr]::Zero
    $task = $reader.ReadLineAsync()
  }
  $h = [FXW]::GetForegroundWindow()
  if ($h -ne $lastH) {
    $lastH = $h
    $fgpid = [FXW]::Pid($h)
    $name = $names[$fgpid]
    if (-not $name) {
      $p = Get-Process -Id $fgpid -ErrorAction SilentlyContinue
      $name = if ($p) { $p.ProcessName } else { '?' }
      $names[$fgpid] = $name
    }
    [Console]::Out.WriteLine("FG $fgpid $([Int64]$h) $name")
    [Console]::Out.Flush()
  }
  if ($fxk) {
    # forward captured keys right away (the wait wakes up as soon as a key arrives)
    $item = $null
    $sent = $false
    while ([FXK]::Out.TryDequeue([ref]$item)) { [Console]::Out.WriteLine($item); $sent = $true }
    if ($sent) { [Console]::Out.Flush() }
    [void][FXK]::Signal.WaitOne(15)
  } else {
    Start-Sleep -Milliseconds 15
  }
}
