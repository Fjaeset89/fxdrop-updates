# FX Drop window helper: reports which app is in front and can hand focus back to Premiere.
# Talks to the FX Drop app over stdin/stdout. Exits when FX Drop closes.
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class FXW {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int cmd);
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO {
    public int cbSize; public int flags; public IntPtr hwndActive; public IntPtr hwndFocus; public IntPtr hwndCapture;
    public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret; public RECT rcCaret;
  }
  [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint idThread, ref GUITHREADINFO info);
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint mapType);
  static IntPtr savedTop = IntPtr.Zero;
  static IntPtr savedFocus = IntPtr.Zero;
  static bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

  // The FX Drop shortcut is pressed while Premiere is in front. If FX Drop takes the keyboard
  // while Ctrl/Shift are still held, Premiere never sees them let go and keeps acting as if
  // they were down (Space then reads as Ctrl+Space and does nothing). So wait for them to be
  // released first, letting Premiere see the release itself. Not done for Alt: a lone Alt
  // release would open Premiere's menu bar.
  public static void WaitForModifiers(int maxMs) {
    System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
    while (sw.ElapsedMilliseconds < maxMs) {
      if (Down(0x12)) return;
      if (!Down(0x11) && !Down(0x10) && !Down(0x5B) && !Down(0x5C)) return;
      System.Threading.Thread.Sleep(4);
    }
  }

  // Safety net after handing focus back: tell the app in front that Ctrl and Shift are up
  // (only for keys that really are up), in case it missed the release while FX Drop had focus.
  public static void ReleaseModifiers() {
    int[] keys = new int[] { 0xA2, 0xA3, 0xA0, 0xA1 }; // left/right Ctrl, left/right Shift
    for (int i = 0; i < keys.Length; i++) {
      int vk = keys[i];
      if (Down(vk)) continue;
      uint flags = 0x0002; // key up
      if (vk == 0xA3) flags = flags | 0x0001; // right Ctrl is an extended key
      keybd_event((byte)vk, (byte)MapVirtualKey((uint)vk, 0), flags, UIntPtr.Zero);
    }
  }

  public static string Describe() {
    IntPtr fg = GetForegroundWindow();
    uint ignored;
    uint t = GetWindowThreadProcessId(fg, out ignored);
    GUITHREADINFO gi = new GUITHREADINFO();
    gi.cbSize = Marshal.SizeOf(typeof(GUITHREADINFO));
    IntPtr f = GetGUIThreadInfo(t, ref gi) ? gi.hwndFocus : IntPtr.Zero;
    return "fg=" + fg.ToInt64() + " saved=" + savedTop.ToInt64() + " focus=" + f.ToInt64() + " savedFocus=" + savedFocus.ToInt64() +
      " ctrl=" + (Down(0x11) ? 1 : 0) + " shift=" + (Down(0x10) ? 1 : 0) + " alt=" + (Down(0x12) ? 1 : 0);
  }
  public static uint Pid(IntPtr h) { uint p; GetWindowThreadProcessId(h, out p); return p; }
  // Remember the window in front AND the exact control inside it that has keyboard focus
  // (e.g. Premiere's timeline panel), so it can be handed back exactly as it was.
  public static void Save() {
    IntPtr fg = GetForegroundWindow();
    uint ignored;
    uint t = GetWindowThreadProcessId(fg, out ignored);
    GUITHREADINFO gi = new GUITHREADINFO();
    gi.cbSize = Marshal.SizeOf(typeof(GUITHREADINFO));
    savedFocus = GetGUIThreadInfo(t, ref gi) ? gi.hwndFocus : IntPtr.Zero;
    savedTop = fg;
  }
  public static void Restore() {
    if (savedTop == IntPtr.Zero || !IsWindow(savedTop)) return;
    Focus(savedTop);
    if (savedFocus != IntPtr.Zero && IsWindow(savedFocus)) {
      uint ignored;
      uint t = GetWindowThreadProcessId(savedTop, out ignored);
      uint me = GetCurrentThreadId();
      bool attached = (t != 0 && t != me) ? AttachThreadInput(me, t, true) : false;
      SetFocus(savedFocus);
      if (attached) AttachThreadInput(me, t, false);
    }
    if (GetForegroundWindow() == savedTop) ReleaseModifiers();
  }
  public static void Focus(IntPtr h) {
    if (h == IntPtr.Zero) return;
    IntPtr fg = GetForegroundWindow();
    uint ignored;
    uint fgThread = GetWindowThreadProcessId(fg, out ignored);
    uint me = GetCurrentThreadId();
    if (IsIconic(h)) ShowWindow(h, 9);
    bool attached = false;
    if (fgThread != 0 && fgThread != me) attached = AttachThreadInput(me, fgThread, true);
    SetForegroundWindow(h);
    BringWindowToTop(h);
    if (attached) AttachThreadInput(me, fgThread, false);
  }
}
"@

$reader = [Console]::In
$task = $reader.ReadLineAsync()
$lastH = [IntPtr]::Zero
$names = @{}
[Console]::Out.WriteLine("READY")
[Console]::Out.Flush()
while ($true) {
  if ($task.IsCompleted) {
    $line = $task.Result
    if ($line -eq $null) { break }
    if ($line.StartsWith('OPEN ')) {
      # remember where the user was, let go of the shortcut keys, then bring the popup to the front
      [FXW]::Save()
      [FXW]::WaitForModifiers(1500)
      $v = 0L
      if ([Int64]::TryParse($line.Substring(5), [ref]$v)) { [FXW]::Focus([IntPtr]$v) }
      [Console]::Out.WriteLine("OPENED")
      [Console]::Out.Flush()
    } elseif ($line -eq 'RESTORE') {
      [FXW]::Restore()
      [Console]::Out.WriteLine("RESTORED " + [FXW]::Describe())
      [Console]::Out.Flush()
    } elseif ($line -eq 'CHECK') {
      [Console]::Out.WriteLine("CHECK " + [FXW]::Describe())
      [Console]::Out.Flush()
    } elseif ($line.StartsWith('FOCUS ')) {
      $v = 0L
      if ([Int64]::TryParse($line.Substring(6), [ref]$v)) { [FXW]::Focus([IntPtr]$v) }
    }
    $lastH = [IntPtr]::Zero
    $task = $reader.ReadLineAsync()
  }
  $h = [FXW]::GetForegroundWindow()
  if ($h -ne $lastH) {
    $lastH = $h
    $fgpid = [FXW]::Pid($h)
    $name = $names[$fgpid]
    if (-not $name) {
      $p = Get-Process -Id $fgpid -ErrorAction SilentlyContinue
      $name = if ($p) { $p.ProcessName } else { '?' }
      $names[$fgpid] = $name
    }
    [Console]::Out.WriteLine("FG $fgpid $([Int64]$h) $name")
    [Console]::Out.Flush()
  }
  Start-Sleep -Milliseconds 15
}
