/* FX Drop search: forgiving, fast word-based ranking with typo tolerance and FX synonyms.
   Works in the browser (window.FXSearch) and in Node (module.exports) for tests. */
(function (root) {
  'use strict';

  var SYN = {
    whoosh: ['swoosh', 'swish', 'woosh', 'swipe', 'passby', 'swoop'],
    swoosh: ['whoosh', 'swish'],
    swish: ['whoosh', 'swoosh'],
    impact: ['hit', 'boom', 'punch', 'thud', 'slam', 'smash'],
    hit: ['impact', 'punch', 'slam'],
    boom: ['impact', 'explosion', 'bass', 'thud'],
    explosion: ['boom', 'blast', 'explode'],
    riser: ['rise', 'build', 'uplifter', 'tension', 'swell'],
    pop: ['click', 'bubble', 'blip', 'plop'],
    click: ['pop', 'tick', 'mouse'],
    ding: ['bell', 'chime', 'notification'],
    glitch: ['digital', 'error', 'distort', 'static', 'datamosh'],
    zoom: ['scale', 'push'],
    shake: ['wobble', 'earthquake', 'handheld', 'jitter', 'rumble'],
    blur: ['defocus', 'soft'],
    transition: ['wipe', 'slide', 'swipe'],
    meme: ['funny', 'bruh', 'vine', 'fail'],
    funny: ['meme', 'comedy', 'cartoon'],
    flash: ['light', 'white', 'strobe'],
    light: ['leak', 'flare', 'flash'],
    leak: ['light leak', 'flare'],
    smoke: ['dust', 'fog'],
    fire: ['flame', 'burn'],
    cash: ['money', 'coin', 'register'],
    money: ['cash', 'coin', 'register'],
    reverb: ['echo', 'room', 'hall'],
    eq: ['equalizer', 'equaliser'],
    compressor: ['compress', 'dynamics'],
    slide: ['slides', 'move', 'push'],
    text: ['title', 'subtitle', 'caption'],
    subtitle: ['subtitles', 'caption', 'text'],
    bass: ['low', 'sub', 'boom'],
    vinyl: ['scratch', 'record'],
    record: ['scratch', 'vinyl', 'rewind'],
    rewind: ['tape', 'reverse', 'record scratch'],
    typing: ['keyboard', 'type'],
    camera: ['shutter', 'snap', 'photo'],
    wind: ['air', 'breeze'],
    crowd: ['audience', 'applause', 'cheer'],
    applause: ['clap', 'cheer', 'crowd'],
    green: ['greenscreen', 'chroma', 'key'],
    key: ['keying', 'chroma', 'green'],
    color: ['colour', 'grade', 'lumetri'],
    colour: ['color', 'grade', 'lumetri'],
  };

  var TYPE_WORDS = {
    sfx: 'sound sfx audio sound effect',
    vfx: 'visual vfx video overlay',
    effect: 'effect fx',
    preset: 'preset',
  };

  function norm(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[_\-./\\()[\]{}&,+:;'"!?#|~]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function prepare(item) {
    var name = norm(item.name);
    var extra = [];
    if (item.folders) extra.push(item.folders.join(' '));
    extra.push(TYPE_WORDS[item.type] || '');
    if (item.type === 'effect') extra.push(item.media === 'audio' ? 'audio' : 'video');
    if (item.type === 'preset') {
      if (item.components) extra.push(item.components.join(' '));
      if (item.adjDefault) extra.push('adjustment layer');
      extra.push(item.media === 'audio' ? 'audio' : 'video');
    }
    if (item.ext) extra.push(item.ext);
    var tags = norm(extra.join(' '));
    item._n = name;
    item._nw = name ? name.split(' ') : [];
    item._t = tags;
    item._tw = tags ? tags.split(' ') : [];
    return item;
  }

  // fuzzy subsequence; returns 0..1 quality
  function fuzzy(tok, hay) {
    if (tok.length < 3) return 0;
    var hi = 0, first = -1, last = -1, gaps = 0;
    for (var i = 0; i < tok.length; i++) {
      var c = tok.charCodeAt(i);
      var found = -1;
      for (var j = hi; j < hay.length; j++) { if (hay.charCodeAt(j) === c) { found = j; break; } }
      if (found < 0) return 0;
      if (first < 0) first = found;
      if (last >= 0 && found > last + 1) gaps += found - last - 1;
      last = found; hi = found + 1;
    }
    var span = last - first + 1;
    var q = tok.length / span;
    if (gaps > tok.length * 2) return 0;
    return q;
  }

  // typo tolerance for words of 4+ letters: one edit away
  function oneEdit(a, b) {
    if (Math.abs(a.length - b.length) > 1) return false;
    var i = 0, j = 0, edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) { i++; j++; continue; }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (a.length < b.length) j++;
      else { i++; j++; }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }

  function wordScore(tok, words, exact, prefix, typo) {
    var best = 0;
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (w === tok) return exact;
      if (w.length > tok.length && w.indexOf(tok) === 0) {
        var s = prefix - Math.min(0.12, (w.length - tok.length) * 0.012);
        if (s > best) best = s;
      } else if (typo && tok.length >= 4 && w.length >= 4 && best < typo && oneEdit(tok, w)) {
        best = typo;
      }
    }
    return best;
  }

  function tokenScore(tok, item) {
    var s = wordScore(tok, item._nw, 1, 0.84, 0.5);
    if (s < 0.62 && item._n.indexOf(tok) > 0 && tok.length >= 2) s = Math.max(s, 0.6);
    if (s < 0.55) s = Math.max(s, wordScore(tok, item._tw, 0.55, 0.46, 0.3));
    if (s < 0.3 && item._t.indexOf(tok) >= 0 && tok.length >= 3) s = Math.max(s, 0.3);
    if (s < 0.36) {
      var f = fuzzy(tok, item._n);
      if (f > 0.45) s = Math.max(s, 0.36 * f);
    }
    if (s < 0.6 && SYN[tok]) {
      var syn = SYN[tok];
      for (var k = 0; k < syn.length; k++) {
        var parts = syn[k].split(' ');
        var ss = 0;
        for (var p = 0; p < parts.length; p++) {
          var v = wordScore(parts[p], item._nw, 1, 0.84, 0) || wordScore(parts[p], item._tw, 0.55, 0.46, 0) * 0.8;
          if (!v) { ss = 0; break; }
          ss += v;
        }
        ss = (ss / parts.length) * 0.66;
        if (ss > s) s = ss;
      }
    }
    return s;
  }

  function highlight(item, toks) {
    var ranges = [];
    var name = String(item.name);
    var low = name.toLowerCase();
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i];
      if (!t) continue;
      var re = 0, idx;
      while ((idx = low.indexOf(t, re)) >= 0) {
        var atWord = idx === 0 || /[^a-z0-9]/.test(low[idx - 1]);
        if (atWord || t.length >= 3) { ranges.push([idx, idx + t.length]); break; }
        re = idx + 1;
      }
    }
    ranges.sort(function (a, b) { return a[0] - b[0]; });
    var merged = [];
    for (var r = 0; r < ranges.length; r++) {
      var last = merged[merged.length - 1];
      if (last && ranges[r][0] <= last[1]) last[1] = Math.max(last[1], ranges[r][1]);
      else merged.push(ranges[r].slice());
    }
    return merged;
  }

  function boost(item, ctx) {
    var b = 0;
    if (item.star) b += 0.22;
    if (item.uses) b += Math.min(0.18, Math.log(1 + item.uses) * 0.06);
    if (item.lastUsed && ctx.now - item.lastUsed < 86400000) b += 0.05;
    if (item.premiereFav) b += 0.05;
    if (ctx.hasSelection && (item.type === 'effect' || item.type === 'preset')) b += 0.07;
    if (!ctx.hasSelection && (item.type === 'sfx' || item.type === 'vfx')) b += 0.03;
    return b;
  }

  function inScope(item, scope) {
    if (!scope || scope === 'all') return true;
    if (scope === 'star') return !!item.star;
    return item.type === scope;
  }

  function search(items, query, scope, ctx) {
    ctx = ctx || {};
    ctx.now = ctx.now || Date.now();
    var q = norm(query);
    var toks = q ? q.split(' ') : [];
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (!inScope(it, scope)) continue;
      if (!it._n && it._n !== '') prepare(it);
      var total = 0, ok = true;
      for (var t = 0; t < toks.length; t++) {
        var s = tokenScore(toks[t], it);
        if (s <= 0) { ok = false; break; }
        total += s;
      }
      if (!ok) continue;
      var score = toks.length ? total / toks.length : 0;
      if (q && it._n === q) score += 0.3;
      else if (q && it._n.indexOf(q) === 0) score += 0.12;
      score += boost(it, ctx);
      score -= Math.min(0.08, it._n.length / 400);
      out.push({ item: it, score: score });
    }
    out.sort(function (a, b) { return b.score - a.score || (a.item.name < b.item.name ? -1 : 1); });
    for (var k = 0; k < out.length && k < 400; k++) out[k].hl = highlight(out[k].item, toks);
    return out;
  }

  var api = { search: search, prepare: prepare, norm: norm, highlight: highlight, inScope: inScope, SYN: SYN };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.FXSearch = api;
})(typeof window !== 'undefined' ? window : this);
