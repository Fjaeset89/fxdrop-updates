/* FX Drop popup */
(function () {
  'use strict';
  var fx = window.fx;
  var Search = window.FXSearch;

  var ROW_H = 46, HEAD_H = 30, TOP_PAD = 6, OVERSCAN = 6;
  var SCOPES = [
    { id: 'all', label: 'All', accent: 'var(--text)' },
    { id: 'sfx', label: 'Sounds', accent: 'var(--sfx)' },
    { id: 'vfx', label: 'Visuals', accent: 'var(--vfx)' },
    { id: 'effect', label: 'Effects', accent: 'var(--effect)' },
    { id: 'preset', label: 'Presets', accent: 'var(--preset)' },
    { id: 'star', label: 'Starred', accent: '#e9c46a' },
  ];
  var TYPE_LABEL = { sfx: 'Sounds', vfx: 'Visuals', effect: 'Effects', preset: 'Presets' };
  var ICON = {
    sfx: '<path d="M4 10v4M8 7v10M12 4v16M16 8v8M20 11v2"/>',
    vfx: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M12 8.6l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z"/>',
    effect: '<path d="M5 19 14.5 9.5"/><path d="M14.5 9.5l2 2"/><path d="M16 3.5v2.5M19.5 7H22M18.6 4.4 17.2 5.8"/><path d="M10.5 4l.6 1.4 1.4.6-1.4.6-.6 1.4-.6-1.4L8.5 6l1.4-.6z"/>',
    preset: '<path d="M12 4.5 17 12l-5 7.5L7 12z"/>',
    adj: '<path d="M12 4 20 8 12 12 4 8z"/><path d="M4 12l8 4 8-4"/><path d="M4 16l8 4 8-4"/>',
    paste: '<rect x="5" y="4.5" width="14" height="16" rx="2.5"/><path d="M9 4.5V3.5h6v1"/><path d="M8.5 16.5l2.6-3 2 2.2 1.6-1.7 1.8 2.5"/><circle cx="10" cy="10" r="1.2"/>',
  };
  // "Paste copied image": shown when an image is on the clipboard (S.clip comes from the app)
  var PASTE = { id: 'paste:clipboard', type: 'paste', name: 'Paste copied image', folders: [] };
  var PASTE_WORDS = ['paste', 'paste image', 'image', 'img', 'billede', 'indsæt', 'clipboard', 'udklipsholder'];
  function asksForPaste(q) {
    q = q.toLowerCase();
    return q.length >= 2 && PASTE_WORDS.some(function (w) { return w.indexOf(q) === 0; });
  }

  var S = {
    items: [], byId: new Map(), query: '', scope: 'all', rows: [], offsets: [], total: 0, sel: -1,
    settings: {}, status: null, connected: false, peaks: new Map(), thumbs: new Map(), playing: null,
    hoverTimer: null, previewTimer: null, open: false, remote: false, anchor: null, clip: null,
  };

  var $ = function (id) { return document.getElementById(id); };
  var q = $('q'), list = $('list'), rowsEl = $('rows'), spacer = $('spacer'), preview = $('preview');
  var scopesEl = $('scopes'), ctxEl = $('ctx'), keysEl = $('keys'), flashEl = $('flash'), shell = $('shell');

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function svg(type) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.innerHTML = ICON[type] || ICON.preset;
    return s;
  }
  function mediaUrl(p) { return 'fxmedia://file/' + encodeURIComponent(p); }
  function iconType(it) { return it.type === 'preset' && it.adjDefault ? 'adj' : it.type; }
  function fmtDur(d) {
    if (!(d > 0)) return '';
    if (d < 10) return d.toFixed(1) + 's';
    if (d < 60) return Math.round(d) + 's';
    var m = Math.floor(d / 60), s = Math.round(d % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  }
  function fmtSize(b) {
    if (!b) return '';
    if (b < 1024 * 1024) return Math.max(1, Math.round(b / 1024)) + ' KB';
    return (b / 1024 / 1024).toFixed(1) + ' MB';
  }
  function crumbText(it) {
    if (it.type === 'paste') return S.clip ? 'From the clipboard · ' + S.clip.w + ' × ' + S.clip.h : 'From the clipboard';
    if (it.type === 'effect') return (it.media === 'audio' ? 'Audio effect' : 'Video effect') + (it.premiereFav ? ' — in your ' + it.premiereFav + ' bin' : '');
    if (it.folders && it.folders.length) return it.folders;
    if (it.type === 'preset') return it.origin === 'premiere' ? 'Premiere presets' : 'Preset pack';
    return it.file || '';
  }
  function sel() { var r = S.rows[S.sel]; return r && r.item ? r.item : null; }
  function selectionCount(media) {
    var s = S.status && S.status.selection;
    if (!s) return 0;
    if (media === 'audio') return s.audio;
    if (media === 'video') return s.video;
    return Math.max(s.video, s.audio);
  }

  // ------------------------------------------------------------ rows
  function sortByFolder(a, b) {
    var fa = (a.folders || []).join('/'), fb = (b.folders || []).join('/');
    if (fa !== fb) return fa < fb ? -1 : 1;
    return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
  }

  function buildRows() {
    var rows = [];
    var scope = S.scope;
    var ctx = { hasSelection: selectionCount() > 0 };
    if (S.query.trim()) {
      var res = Search.search(S.items, S.query, scope, ctx);
      for (var i = 0; i < res.length; i++) rows.push({ item: res[i].item, hl: res[i].hl });
    } else {
      var inScope = S.items.filter(function (it) { return Search.inScope(it, scope); });
      var seen = new Set();
      var recent = inScope.filter(function (it) { return it.lastUsed; })
        .sort(function (a, b) { return b.lastUsed - a.lastUsed; }).slice(0, scope === 'star' ? 0 : 6);
      if (recent.length) {
        rows.push({ head: 'Recently used' });
        recent.forEach(function (it) { rows.push({ item: it }); seen.add(it.id); });
      }
      if (scope !== 'star') {
        var starred = inScope.filter(function (it) { return it.star && !seen.has(it.id); }).sort(sortByFolder);
        if (starred.length) {
          rows.push({ head: 'Starred', count: starred.length });
          starred.forEach(function (it) { rows.push({ item: it }); seen.add(it.id); });
        }
      }
      var rest = inScope.filter(function (it) { return !seen.has(it.id); });
      if (scope === 'all') {
        ['sfx', 'vfx', 'preset', 'effect'].forEach(function (t) {
          var group = rest.filter(function (it) { return it.type === t; }).sort(sortByFolder);
          if (!group.length) return;
          rows.push({ head: TYPE_LABEL[t], count: group.length });
          group.forEach(function (it) { rows.push({ item: it }); });
        });
      } else if (scope === 'effect') {
        ['video', 'audio'].forEach(function (m) {
          var group = rest.filter(function (it) { return it.media === m; }).sort(sortByFolder);
          if (!group.length) return;
          rows.push({ head: m === 'video' ? 'Video effects' : 'Audio effects', count: group.length });
          group.forEach(function (it) { rows.push({ item: it }); });
        });
      } else {
        rest.sort(sortByFolder);
        var last = null;
        rest.forEach(function (it) {
          var key = (it.folders || []).join(' / ') || (scope === 'star' ? TYPE_LABEL[it.type] : 'Top folder');
          if (scope === 'star') key = TYPE_LABEL[it.type];
          if (key !== last) { rows.push({ head: key }); last = key; }
          rows.push({ item: it });
        });
      }
    }
    // copied image: on top when the search is empty (unless it was already pasted) or asks for it
    var qq = S.query.trim();
    if (S.clip && (scope === 'all' || scope === 'vfx') && (qq ? asksForPaste(qq) : !S.clip.pasted)) {
      rows.unshift({ head: 'Clipboard' }, { item: PASTE });
    }
    S.rows = rows;
    var offs = [], y = TOP_PAD;
    for (var k = 0; k < rows.length; k++) { offs.push(y); y += rows[k].head ? HEAD_H : ROW_H; }
    S.offsets = offs;
    S.total = y + 8;
    spacer.style.height = S.total + 'px';
    S.sel = nextItem(-1, 1);
  }

  function nextItem(from, dir) {
    for (var i = from + dir; i >= 0 && i < S.rows.length; i += dir) if (S.rows[i].item) return i;
    return from >= 0 && from < S.rows.length && S.rows[from] && S.rows[from].item ? from : -1;
  }

  function firstVisible(top) {
    var lo = 0, hi = S.offsets.length - 1;
    while (lo < hi) {
      var mid = (lo + hi + 1) >> 1;
      if (S.offsets[mid] <= top) lo = mid; else hi = mid - 1;
    }
    return lo;
  }

  function renderRows() {
    rowsEl.textContent = '';
    var oldEmpty = list.querySelector('.empty');
    if (oldEmpty) oldEmpty.remove();
    if (!S.rows.length) { renderEmpty(); return; }
    var top = list.scrollTop, h = list.clientHeight;
    var start = Math.max(0, firstVisible(top) - OVERSCAN);
    var frag = document.createDocumentFragment();
    var waves = [];
    for (var i = start; i < S.rows.length; i++) {
      var y = S.offsets[i];
      if (y > top + h + OVERSCAN * ROW_H) break;
      var r = S.rows[i];
      if (r.head) {
        var hd = el('div', 'head', r.head);
        if (r.count) hd.appendChild(el('span', 'count', String(r.count)));
        hd.style.top = y + 'px';
        frag.appendChild(hd);
        continue;
      }
      var row = renderRow(r, i);
      row.style.top = y + 'px';
      frag.appendChild(row);
      if (r.item.type === 'sfx') waves.push([row.querySelector('canvas'), r.item]);
    }
    rowsEl.appendChild(frag);
    waves.forEach(function (w) { drawRowWave(w[0], w[1]); });
  }

  function renderRow(r, i) {
    var it = r.item;
    var row = el('div', 'row' + (i === S.sel ? ' sel' : ''));
    row.dataset.i = i;
    row.dataset.type = it.type;
    row.dataset.adj = it.adjDefault ? '1' : '0';
    row.setAttribute('role', 'option');
    if (i === S.sel) row.setAttribute('aria-selected', 'true');
    var g = el('div', 'glyph');
    g.appendChild(svg(iconType(it)));
    row.appendChild(g);

    var label = el('div', 'label');
    var name = el('div', 'name');
    appendHighlighted(name, it.name, r.hl);
    label.appendChild(name);
    var c = crumbText(it);
    var crumb = el('div', 'crumb');
    if (Array.isArray(c)) {
      c.forEach(function (part, k) {
        if (k) crumb.appendChild(el('span', 'sep', '/'));
        crumb.appendChild(document.createTextNode(part));
      });
    } else crumb.textContent = c;
    label.appendChild(crumb);
    row.appendChild(label);

    var aside = el('div', 'aside');
    if (it.type === 'sfx') {
      var cv = el('canvas', 'wave');
      cv.width = 144; cv.height = 44;
      aside.appendChild(cv);
      queuePeaks(it);
    } else if (it.type === 'vfx') {
      var t = S.thumbs.get(it.id);
      if (t) { var im = el('img', 'thumb'); im.src = t; im.alt = ''; aside.appendChild(im); }
      else if (t === undefined) queueThumb(it);
    } else if (it.type === 'paste') {
      if (S.clip && S.clip.thumb) { var pim = el('img', 'thumb'); pim.src = S.clip.thumb; pim.alt = ''; aside.appendChild(pim); }
      aside.appendChild(el('span', 'tag', 'Ctrl V'));
    } else if (it.type === 'preset') {
      if (it.adjDefault) aside.appendChild(el('span', 'tag', 'Layer'));
      else if (it.media === 'audio') aside.appendChild(el('span', 'tag', 'Audio'));
    } else if (it.type === 'effect' && it.media === 'audio') {
      aside.appendChild(el('span', 'tag', 'Audio'));
    }
    if (it.star) aside.appendChild(el('span', 'star', '★'));
    var meta = '';
    if (it.type === 'sfx' || it.type === 'vfx') meta = it.kind === 'image' ? it.ext.toUpperCase() : fmtDur(it.dur);
    aside.appendChild(el('span', 'meta', meta));
    row.appendChild(aside);

    if (it.type === 'sfx' || it.type === 'vfx') row.draggable = true;
    return row;
  }

  function appendHighlighted(node, text, ranges) {
    if (!ranges || !ranges.length) { node.textContent = text; return; }
    var pos = 0;
    ranges.forEach(function (r) {
      if (r[0] > pos) node.appendChild(document.createTextNode(text.slice(pos, r[0])));
      node.appendChild(el('mark', null, text.slice(r[0], r[1])));
      pos = r[1];
    });
    if (pos < text.length) node.appendChild(document.createTextNode(text.slice(pos)));
  }

  function renderEmpty() {
    var box = el('div', 'empty');
    var media = S.scope === 'sfx' || S.scope === 'vfx';
    if (!S.items.length) {
      box.appendChild(el('h2', null, 'Loading your library…'));
    } else if (S.query.trim()) {
      box.appendChild(el('h2', null, 'Nothing matches “' + S.query.trim() + '”'));
      box.appendChild(el('p', null, S.scope === 'all' ? 'Try fewer or different words.' : 'Try fewer words, or press Tab to search the other tabs.'));
    } else if (media && !S.settings.hasLibrary) {
      box.appendChild(el('h2', null, 'Point FX Drop at your FX folder'));
      box.appendChild(el('p', null, 'Add the folder where you keep sound and visual effects. Subfolder names become search words.'));
      var b = el('button', 'btn', 'Open settings');
      b.onclick = function () { fx.openSettings(); };
      box.appendChild(b);
    } else if (S.scope === 'star') {
      box.appendChild(el('h2', null, 'No starred items yet'));
      box.appendChild(el('p', null, 'Press Ctrl+D on anything you use a lot. Starred items show up first.'));
    } else {
      box.appendChild(el('h2', null, 'This folder is empty'));
      box.appendChild(el('p', null, 'Drop files into your FX folder — they show up here automatically.'));
    }
    list.appendChild(box);
  }

  function ensureVisible(i) {
    if (i < 0) return;
    var y = S.offsets[i], top = list.scrollTop, h = list.clientHeight;
    var prevHead = i > 0 && S.rows[i - 1].head ? HEAD_H : 0;
    if (y - prevHead < top) list.scrollTop = Math.max(0, y - prevHead - TOP_PAD);
    else if (y + ROW_H > top + h) list.scrollTop = y + ROW_H - h + 4;
  }

  function setSel(i, how) {
    if (i < 0 || i === S.sel) return;
    S.sel = i;
    if (how !== 'mouse') ensureVisible(i);
    renderRows();
    renderPreview();
    renderKeys();
    schedulePreview(how);
  }

  // ------------------------------------------------------------ waveforms
  var peakQueue = [], peakBusy = 0;
  function queuePeaks(it) {
    if (S.peaks.has(it.id)) return;
    S.peaks.set(it.id, null);
    peakQueue.push(it);
    pumpPeaks();
  }
  function pumpPeaks() {
    while (peakBusy < 2 && peakQueue.length) {
      var it = peakQueue.shift();
      peakBusy++;
      loadPeaks(it).catch(function () {}).then(function () { peakBusy--; pumpPeaks(); });
    }
  }
  function loadPeaks(it) {
    return fx.peaks(it.id).then(function (cached) {
      if (cached && cached.length) { S.peaks.set(it.id, Uint8Array.from(cached)); redrawWave(it); return; }
      if (it.size > 60 * 1024 * 1024) { S.peaks.set(it.id, false); return; }
      return fetch(mediaUrl(it.path)).then(function (r) { return r.arrayBuffer(); }).then(function (buf) {
        // an offline context decodes without needing an audio device
        var oc = new OfflineAudioContext(1, 1, 44100);
        return oc.decodeAudioData(buf);
      }).then(function (ab) {
        var n = 160, out = new Uint8Array(n), len = ab.length, chans = ab.numberOfChannels;
        var data = [];
        for (var c = 0; c < chans; c++) data.push(ab.getChannelData(c));
        var bucket = Math.max(1, Math.floor(len / n)), step = Math.max(1, Math.floor(bucket / 400));
        var peaksF = new Float32Array(n), max = 0;
        for (var b = 0; b < n; b++) {
          var m = 0, s0 = b * bucket, s1 = Math.min(len, s0 + bucket);
          for (var c2 = 0; c2 < chans; c2++) {
            var d = data[c2];
            for (var s = s0; s < s1; s += step) { var v = d[s] < 0 ? -d[s] : d[s]; if (v > m) m = v; }
          }
          peaksF[b] = m; if (m > max) max = m;
        }
        for (var k = 0; k < n; k++) out[k] = max > 0 ? Math.round(Math.pow(peaksF[k] / max, 0.8) * 255) : 0;
        S.peaks.set(it.id, out);
        fx.peaks(it.id, Array.from(out));
        if (!it.dur && ab.duration > 0) { it.dur = ab.duration; fx.duration(it.id, ab.duration); }
        redrawWave(it);
      });
    }).catch(function () { S.peaks.set(it.id, false); });
  }
  function redrawWave(it) {
    var rows = rowsEl.querySelectorAll('.row');
    for (var i = 0; i < rows.length; i++) {
      var r = S.rows[+rows[i].dataset.i];
      if (r && r.item === it) {
        drawRowWave(rows[i].querySelector('canvas'), it);
        var meta = rows[i].querySelector('.meta');
        if (meta && it.dur) meta.textContent = fmtDur(it.dur);
      }
    }
    if (sel() === it) drawStageWave();
  }
  function drawBars(ctx, peaks, w, h, bars, color, progressColor, progress) {
    ctx.clearRect(0, 0, w, h);
    if (!peaks) {
      ctx.fillStyle = 'rgba(255,255,255,0.08)';
      ctx.fillRect(0, h / 2 - 1, w, 2);
      return;
    }
    var gap = w / bars, bw = Math.max(1, gap * 0.58);
    for (var i = 0; i < bars; i++) {
      var a = Math.floor(i * peaks.length / bars), b = Math.max(a + 1, Math.floor((i + 1) * peaks.length / bars));
      var m = 0;
      for (var k = a; k < b; k++) if (peaks[k] > m) m = peaks[k];
      var bh = Math.max(2, (m / 255) * (h - 2));
      ctx.fillStyle = progress !== undefined && i / bars < progress ? progressColor : color;
      ctx.fillRect(i * gap + (gap - bw) / 2, (h - bh) / 2, bw, bh);
    }
  }
  function drawRowWave(cv, it) {
    if (!cv) return;
    var p = S.peaks.get(it.id);
    var playing = S.playing === it.id;
    var prog = playing && audio.duration ? audio.currentTime / audio.duration : undefined;
    drawBars(cv.getContext('2d'), p || null, cv.width, cv.height, 36, playing ? 'rgba(242,181,68,0.45)' : 'rgba(242,181,68,0.62)', '#f2b544', prog);
  }
  function drawStageWave() {
    var cv = preview.querySelector('canvas.stagewave');
    var it = sel();
    if (!cv || !it) return;
    var p = S.peaks.get(it.id);
    var playing = S.playing === it.id;
    var prog = playing && audio.duration ? audio.currentTime / audio.duration : undefined;
    drawBars(cv.getContext('2d'), p || null, cv.width, cv.height, 64, 'rgba(242,181,68,0.42)', '#f2b544', prog === undefined ? -1 : prog);
    var t = preview.querySelector('.play .t');
    if (t) t.textContent = playing ? fmtDur(audio.currentTime || 0.01) + ' / ' + fmtDur(it.dur || audio.duration) : fmtDur(it.dur);
  }

  // ------------------------------------------------------------ thumbnails
  var thumbQueue = [], thumbBusy = false;
  function queueThumb(it) {
    if (S.thumbs.has(it.id)) return;
    S.thumbs.set(it.id, null);
    if (it.kind === 'image') { S.thumbs.set(it.id, mediaUrl(it.path)); return; }
    thumbQueue.push(it);
    pumpThumbs();
  }
  function pumpThumbs() {
    if (thumbBusy || !thumbQueue.length) return;
    thumbBusy = true;
    var it = thumbQueue.shift();
    makeThumb(it).then(function (url) {
      S.thumbs.set(it.id, url || false);
      if (url) renderRows();
    }).catch(function () { S.thumbs.set(it.id, false); }).then(function () { thumbBusy = false; pumpThumbs(); });
  }
  function makeThumb(it) {
    return fx.thumb(it.id).then(function (cached) {
      if (cached) return cached;
      return new Promise(function (resolve) {
        var v = document.createElement('video');
        var done = false;
        var finish = function (url) { if (done) return; done = true; v.removeAttribute('src'); v.load(); resolve(url); };
        v.muted = true; v.preload = 'auto'; v.crossOrigin = 'anonymous';
        v.onloadedmetadata = function () { v.currentTime = Math.min(2, (v.duration || 1) * 0.35); };
        v.onseeked = function () {
          try {
            var c = document.createElement('canvas');
            c.width = 96; c.height = 54;
            var g = c.getContext('2d');
            var r = Math.max(96 / v.videoWidth, 54 / v.videoHeight);
            var w = v.videoWidth * r, h = v.videoHeight * r;
            g.fillStyle = '#2b2e33'; g.fillRect(0, 0, 96, 54);
            g.drawImage(v, (96 - w) / 2, (54 - h) / 2, w, h);
            var url = c.toDataURL('image/jpeg', 0.75);
            if (!it.dur && v.duration > 0 && isFinite(v.duration)) { it.dur = v.duration; fx.duration(it.id, v.duration); }
            fx.thumb(it.id, url);
            finish(url);
          } catch (e) { finish(null); }
        };
        v.onerror = function () { finish(null); };
        setTimeout(function () { finish(null); }, 5000);
        v.src = mediaUrl(it.path);
      });
    });
  }

  // ------------------------------------------------------------ preview pane
  var audio = new Audio();
  audio.preload = 'auto';
  var rafId = 0;
  function tick() {
    cancelAnimationFrame(rafId);
    if (!S.playing) return;
    var it = S.byId.get(S.playing);
    if (it) {
      drawStageWave();
      var rows = rowsEl.querySelectorAll('.row');
      for (var i = 0; i < rows.length; i++) {
        var r = S.rows[+rows[i].dataset.i];
        if (r && r.item === it) drawRowWave(rows[i].querySelector('canvas'), it);
      }
    }
    rafId = requestAnimationFrame(tick);
  }
  audio.addEventListener('ended', function () { var id = S.playing; S.playing = null; var it = S.byId.get(id); if (it) redrawWave(it); renderKeys(); });
  audio.addEventListener('loadedmetadata', function () {
    var it = S.byId.get(S.playing);
    if (it && !it.dur && audio.duration > 0 && isFinite(audio.duration)) { it.dur = audio.duration; fx.duration(it.id, audio.duration); }
  });

  function play(it) {
    if (it.type === 'vfx') {
      var v = preview.querySelector('video');
      if (v) { v.muted = !v.muted; v.currentTime = 0; v.play().catch(function () {}); }
      return;
    }
    if (it.type !== 'sfx') return;
    stopAudio();
    audio.src = mediaUrl(it.path);
    audio.volume = S.settings.previewVolume != null ? S.settings.previewVolume : 0.8;
    S.playing = it.id;
    audio.play().catch(function () { S.playing = null; });
    tick();
    renderKeys();
  }
  function stopAudio() {
    var id = S.playing;
    S.playing = null;
    try { audio.pause(); } catch (e) {}
    cancelAnimationFrame(rafId);
    var it = S.byId.get(id);
    if (it) redrawWave(it);
  }
  function togglePlay() {
    var it = sel();
    if (!it) return;
    if (it.type === 'sfx' && S.playing === it.id) { stopAudio(); renderKeys(); return; }
    play(it);
  }
  // how: 'key' (arrowing), 'type' (typing), 'mouse' (hover), 'open' (never auto-plays)
  function schedulePreview(how) {
    clearTimeout(S.previewTimer);
    var it = sel();
    if (S.playing && (!it || it.id !== S.playing)) stopAudio();
    if (!it || it.type !== 'sfx' || !S.settings.autoPreview || how === 'open') return;
    var delay = how === 'mouse' ? 380 : how === 'type' ? 420 : 130;
    S.previewTimer = setTimeout(function () { if (sel() === it && S.open) play(it); }, delay);
  }

  function fact(dl, k, v) {
    if (v === undefined || v === null || v === '') return;
    dl.appendChild(el('dt', null, k));
    dl.appendChild(el('dd', null, v));
  }

  function anchorText(a) {
    if (a === 1) return 'Starts at the clip’s start';
    if (a === 2) return 'Ends at the clip’s end';
    return 'Stretches to fit the clip';
  }

  function renderPreview() {
    var it = sel();
    preview.textContent = '';
    if (!it) return;
    preview.style.setProperty('--tc', 'var(--' + (it.type === 'preset' && it.adjDefault ? 'adj' : it.type) + ')');
    var stage = el('div', 'stage');

    if (it.type === 'sfx') {
      var cv = el('canvas', 'stagewave');
      cv.width = 536; cv.height = 300;
      stage.appendChild(cv);
      var pl = el('div', 'play');
      var ps = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      ps.setAttribute('viewBox', '0 0 10 10');
      ps.innerHTML = '<path d="M2 1l7 4-7 4z"/>';
      pl.appendChild(ps);
      pl.appendChild(el('span', 't', fmtDur(it.dur)));
      stage.appendChild(pl);
      queuePeaks(it);
    } else if (it.type === 'vfx') {
      stage.classList.add('checker');
      if (it.kind === 'image') {
        var img = el('img');
        img.src = mediaUrl(it.path);
        img.alt = '';
        stage.appendChild(img);
      } else {
        var v = el('video');
        v.muted = true; v.loop = true; v.autoplay = true; v.playsInline = true;
        v.onerror = function () {
          v.remove();
          stage.appendChild(el('div', 'nopreview', 'No preview for this format — it still drops into Premiere fine.'));
        };
        v.onloadedmetadata = function () {
          if (!it.dur && v.duration > 0 && isFinite(v.duration)) { it.dur = v.duration; fx.duration(it.id, v.duration); renderFacts(); }
        };
        v.src = mediaUrl(it.path);
        stage.appendChild(v);
      }
    } else if (it.type === 'paste') {
      stage.classList.add('checker');
      if (S.clip && (S.clip.big || S.clip.thumb)) { var pimg = el('img'); pimg.src = S.clip.big || S.clip.thumb; pimg.alt = ''; stage.appendChild(pimg); }
    } else if (it.type === 'preset' && it.kfPos && it.kfPos.length) {
      var kf = el('div', 'kf');
      var clip = el('div', 'clip');
      clip.style.left = '0'; clip.style.right = '0';
      kf.appendChild(clip);
      it.kfPos.forEach(function (p) {
        var d = el('div', 'd');
        d.style.left = (p * 100) + '%';
        kf.appendChild(d);
      });
      stage.appendChild(kf);
      var cap = el('div', 'kf-caption');
      cap.appendChild(el('span', null, it.anchor === 2 ? '' : 'clip start'));
      cap.appendChild(el('span', null, it.anchor === 1 ? '' : 'clip end'));
      stage.appendChild(cap);
      var chips = el('div', 'chips');
      (it.components || []).slice(0, 5).forEach(function (c) { chips.appendChild(el('span', 'cchip', c)); });
      stage.appendChild(chips);
    } else {
      var big = el('div', 'big');
      big.appendChild(svg(iconType(it)));
      stage.appendChild(big);
      if (it.type === 'preset') {
        var chips2 = el('div', 'chips');
        (it.components || []).slice(0, 5).forEach(function (c) { chips2.appendChild(el('span', 'cchip', c)); });
        stage.appendChild(chips2);
      }
    }
    preview.appendChild(stage);

    var info = el('div', 'p-info');
    var head = el('div');
    head.appendChild(el('div', 'p-title', it.name));
    var c = crumbText(it);
    head.appendChild(el('div', 'p-crumb', Array.isArray(c) ? c.join(' / ') : c));
    info.appendChild(head);

    var dl = el('dl', 'facts');
    dl.id = 'facts';
    info.appendChild(dl);
    preview.appendChild(info);
    renderFacts();

    if (it.type === 'preset' && it.opaque) {
      info.appendChild(el('div', 'note', 'Some settings in this preset (masks, curves or text) can’t be copied by FX Drop and will use Premiere’s defaults.'));
    }
    preview.appendChild(renderDest(it));
    if (it.type === 'sfx') drawStageWave();
  }

  function renderFacts() {
    var it = sel();
    var dl = $('facts');
    if (!it || !dl) return;
    dl.textContent = '';
    if (it.type === 'paste') {
      if (S.clip) fact(dl, 'Size', S.clip.w + ' × ' + S.clip.h + ' px');
      fact(dl, 'Fits frame', S.settings.pasteFit === false ? 'No (100%)' : 'Yes');
      fact(dl, 'Slow zoom', S.settings.pasteMotion === false ? 'Off' : '100% → ' + (S.settings.pasteZoomTo || 105) + '%');
      fact(dl, 'Saved to', S.clip && S.clip.file ? 'Uses the copied file' : 'Your project folder › FX Drop Pastes');
      return;
    }
    if (it.type === 'sfx' || it.type === 'vfx') {
      fact(dl, 'Length', it.kind === 'image' ? 'Still image' : fmtDur(it.dur) || '—');
      fact(dl, 'Format', (it.ext || '').toUpperCase());
      fact(dl, 'Size', fmtSize(it.size));
      if (it.type === 'vfx' && it.kind === 'video') fact(dl, 'Sound', it.hasAudio === true ? 'Yes' : it.hasAudio === false ? 'No' : 'Unknown');
    } else if (it.type === 'preset') {
      if (it.keys) fact(dl, 'Timing', anchorText(it.anchor));
      fact(dl, 'Keyframes', it.keys ? String(it.keys) : 'None');
      fact(dl, 'Adds', (it.components || []).join(', '));
      fact(dl, 'For', it.media === 'audio' ? 'Audio clips' : it.adjDefault ? 'Adjustment layers' : 'Video clips');
    } else if (it.type === 'effect') {
      fact(dl, 'Type', it.media === 'audio' ? 'Audio effect' : 'Video effect');
      if (it.premiereFav) fact(dl, 'Favorite', 'In your ' + it.premiereFav + ' bin');
    }
    if (it.uses) fact(dl, 'Used', it.uses === 1 ? 'Once' : it.uses + ' times');
  }

  function renderDest(it) {
    var d = el('div', 'dest');
    var tc = S.status && S.status.timecode;
    function strong(t) { return el('strong', null, t); }
    function add() { for (var i = 0; i < arguments.length; i++) { var a = arguments[i]; d.appendChild(typeof a === 'string' ? document.createTextNode(a) : a); } }
    if (!S.connected) {
      d.classList.add('need');
      add('Premiere isn’t connected. Open Premiere Pro to drop this.');
      return d;
    }
    if (!S.status || !S.status.sequence) {
      d.classList.add('need');
      add('Open a sequence in Premiere first.');
      return d;
    }
    if (it.type === 'sfx') {
      add('Drops at ', strong(tc || 'the playhead'), ' on the lowest free audio track.');
    } else if (it.type === 'vfx' || it.type === 'paste') {
      add('Drops at ', strong(tc || 'the playhead'), ' above everything on the timeline.');
    } else {
      var media = it.media === 'mixed' ? 'any' : it.media;
      var n = selectionCount(media);
      var asLayer = it.type === 'preset' && it.adjDefault;
      if (asLayer) {
        add('Drops a new adjustment layer at ', strong(tc || 'the playhead'), ' with this preset.');
      } else if (n > 0) {
        add('Applies to ', strong(n + (n === 1 ? ' selected clip' : ' selected clips')), '.');
      } else {
        d.classList.add('need');
        add('Select ' + (media === 'audio' ? 'audio ' : media === 'video' ? 'video ' : '') + 'clips first');
        if (media !== 'audio') add(' — or press Shift+Enter to put it on an adjustment layer');
        add('.');
      }
    }
    return d;
  }

  // ------------------------------------------------------------ header, scopes, keys
  function renderCtx() {
    ctxEl.textContent = '';
    if (!S.connected) {
      var off = el('span', 'chip off');
      off.appendChild(el('span', 'dot'));
      off.appendChild(document.createTextNode('Premiere not connected'));
      off.title = 'Open Premiere Pro. If you just installed FX Drop, restart Premiere once.';
      off.onclick = function () { fx.openSettings(); };
      ctxEl.appendChild(off);
      return;
    }
    var st = S.status;
    if (!st || !st.sequence) { ctxEl.appendChild(el('span', 'chip', 'No sequence open')); return; }
    var n = selectionCount();
    if (n) ctxEl.appendChild(el('span', 'chip', n + ' selected'));
    if (st.timecode) {
      var t = el('span', 'chip');
      var ps = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      ps.setAttribute('viewBox', '0 0 10 10');
      ps.innerHTML = '<path d="M1 1h8L5 6z"/><rect x="4.4" y="5" width="1.2" height="5"/>';
      t.appendChild(ps);
      t.appendChild(document.createTextNode(st.timecode));
      t.title = 'Playhead in ' + st.sequence;
      ctxEl.appendChild(t);
    }
  }

  function renderScopes() {
    scopesEl.textContent = '';
    var counts = { all: S.items.length, star: 0 };
    S.items.forEach(function (it) { counts[it.type] = (counts[it.type] || 0) + 1; if (it.star) counts.star++; });
    SCOPES.forEach(function (sc, i) {
      var b = el('button', 'scope');
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-selected', S.scope === sc.id ? 'true' : 'false');
      b.style.setProperty('--accent', sc.accent);
      b.title = sc.label + ' (Ctrl+' + (i + 1) + ')';
      b.appendChild(document.createTextNode(sc.label));
      b.appendChild(el('span', 'n', (counts[sc.id] || 0).toLocaleString()));
      b.onmousedown = function (e) { e.preventDefault(); setScope(sc.id); };
      scopesEl.appendChild(b);
    });
  }

  function key(k, label) {
    var s = el('span');
    k.split(' ').forEach(function (part) { s.appendChild(el('kbd', null, part)); });
    s.appendChild(document.createTextNode(label));
    return s;
  }
  function renderKeys() {
    keysEl.textContent = '';
    var it = sel();
    if (!it) { keysEl.appendChild(key('Tab', 'Next tab')); return; }
    if (it.type === 'paste') {
      keysEl.appendChild(key('↵', 'Drop at playhead'));
      keysEl.appendChild(key('Ctrl V', 'Paste right away'));
      keysEl.appendChild(key('Tab', 'Next tab'));
      return;
    }
    if (it.type === 'sfx' || it.type === 'vfx') {
      keysEl.appendChild(key('↵', 'Drop at playhead'));
      keysEl.appendChild(key('⇧ ↵', 'Drop, keep open'));
      keysEl.appendChild(key('→', it.type === 'sfx' ? (S.playing === it.id ? 'Stop' : 'Play') : 'Sound on/off'));
    } else if (it.type === 'effect') {
      keysEl.appendChild(key('↵', 'Apply to selection'));
      if (it.media === 'video') keysEl.appendChild(key('⇧ ↵', 'On adjustment layer'));
    } else {
      if (it.adjDefault) {
        keysEl.appendChild(key('↵', 'Drop adjustment layer'));
        keysEl.appendChild(key('⇧ ↵', 'Apply to selection'));
      } else {
        keysEl.appendChild(key('↵', 'Apply to selection'));
        if (it.media !== 'audio') keysEl.appendChild(key('⇧ ↵', 'On adjustment layer'));
      }
    }
    keysEl.appendChild(key('Ctrl D', it.star ? 'Unstar' : 'Star'));
    keysEl.appendChild(key('Tab', 'Next tab'));
  }

  // ------------------------------------------------------------ actions
  var flashTimer = 0;
  function flash(text, sub, tone) {
    flashEl.textContent = '';
    flashEl.className = 'flash show' + (tone && tone !== 'ok' ? ' ' + tone : '');
    flashEl.appendChild(el('span', null, text));
    if (sub) flashEl.appendChild(el('span', 'sub', sub));
    clearTimeout(flashTimer);
    flashTimer = setTimeout(function () { flashEl.className = 'flash'; }, tone === 'error' ? 4500 : 2200);
  }

  function act(alt) {
    var it = sel();
    if (!it) return;
    var keepOpen = alt && (it.type === 'sfx' || it.type === 'vfx');
    stopAudio();
    fx.action(it.id, alt).then(function (res) {
      if (res && res.ok) {
        it.uses = (it.uses || 0) + 1;
        it.lastUsed = Date.now();
        if (keepOpen) flash(res.text, res.sub, res.tone);
      } else if (keepOpen) {
        flash(res ? res.error : 'Something went wrong', '', 'error');
      }
    });
  }

  function pasteImage() {
    for (var i = 0; i < S.rows.length; i++) if (S.rows[i].item === PASTE) { S.sel = i; break; }
    stopAudio();
    fx.action(PASTE.id, false);
  }

  function toggleStar() {
    var it = sel();
    if (!it) return;
    it.star = !it.star;
    fx.star(it.id, it.star);
    renderRows();
    renderScopes();
    renderKeys();
    renderFacts();
  }

  function setScope(id) {
    if (S.scope === id) return;
    S.scope = id;
    list.scrollTop = 0;
    refresh();
  }
  function cycleScope(dir) {
    var i = SCOPES.findIndex(function (s) { return s.id === S.scope; });
    setScope(SCOPES[(i + dir + SCOPES.length) % SCOPES.length].id);
  }

  function refresh(how) {
    buildRows();
    renderScopes();
    renderRows();
    renderPreview();
    renderKeys();
    renderCtx();
    schedulePreview(how || 'key');
  }

  function close(returnFocus) {
    if (!S.open) return;
    fx.hide(returnFocus !== false);
  }

  // ------------------------------------------------------------ events
  q.addEventListener('input', function () {
    S.query = q.value;
    list.scrollTop = 0;
    buildRows();
    renderRows();
    renderPreview();
    renderKeys();
    schedulePreview('type');
  });

  document.addEventListener('keydown', handleKey);
  function handleKey(e) {
    var k = e.key;
    if (k === 'ArrowDown' || k === 'ArrowUp') {
      e.preventDefault();
      setSel(nextItem(S.sel, k === 'ArrowDown' ? 1 : -1), 'key');
    } else if (k === 'PageDown' || k === 'PageUp') {
      e.preventDefault();
      var i = S.sel;
      for (var n = 0; n < 8; n++) i = nextItem(i, k === 'PageDown' ? 1 : -1);
      setSel(i, 'key');
    } else if (k === 'Enter') {
      e.preventDefault();
      act(e.shiftKey);
    } else if (k === 'Tab') {
      e.preventDefault();
      cycleScope(e.shiftKey ? -1 : 1);
    } else if (k === 'Escape') {
      e.preventDefault();
      if (q.value) { q.value = ''; q.dispatchEvent(new Event('input')); }
      else close(true);
    } else if (k === 'ArrowRight' && q.selectionStart === q.value.length && q.selectionEnd === q.value.length) {
      e.preventDefault();
      togglePlay();
    } else if (e.ctrlKey && !e.altKey && (k === 'v' || k === 'V') && S.clip) {
      e.preventDefault();
      pasteImage();
    } else if (e.ctrlKey && (k === 'd' || k === 'D')) {
      e.preventDefault();
      if (sel() && sel().type !== 'paste') toggleStar();
    } else if (e.ctrlKey && k === ',') {
      e.preventDefault();
      fx.openSettings();
    } else if (e.ctrlKey && k >= '1' && k <= '6') {
      e.preventDefault();
      setScope(SCOPES[+k - 1].id);
    } else if (e.ctrlKey && e.shiftKey && (k === 'r' || k === 'R')) {
      e.preventDefault();
      var it = sel();
      if (it && it.path) fx.reveal(it.id);
    }
  }

  // ------------------------------------------------------------ typing while Premiere keeps focus
  // On Windows the search box never takes focus from Premiere; FX Drop's helper passes the keys here.
  // Shortcuts go through handleKey like real key presses; everything else edits the search text.
  fx.onKey(function (ev) {
    if (!S.open) return;
    var e = { key: ev.key, shiftKey: !!ev.shift, ctrlKey: !!ev.ctrl, altKey: !!ev.alt, target: q,
      defaultPrevented: false, preventDefault: function () { this.defaultPrevented = true; } };
    handleKey(e);
    if (!e.defaultPrevented) editText(ev);
    drawCaret();
  });
  fx.onRemoteKeys(function (on) { S.remote = !!on; drawCaret(); if (!on) q.focus(); });

  function editText(ev) {
    var v = q.value, a = q.selectionStart, b = q.selectionEnd, k = ev.key;
    var ctrlOnly = ev.ctrl && !ev.alt; // Ctrl+Alt is AltGr on Danish keyboards (@, £, $ …)
    function put(val, pos, pos2) {
      q.value = val;
      q.setSelectionRange(pos, pos2 === undefined ? pos : pos2);
      S.anchor = null;
      q.dispatchEvent(new Event('input'));
    }
    function insert(t) { t = String(t || '').replace(/[\r\n\t]+/g, ' '); if (t) put(v.slice(0, a) + t + v.slice(b), a + t.length); }
    function wordLeft(i) { while (i > 0 && /\s/.test(v[i - 1])) i--; while (i > 0 && !/\s/.test(v[i - 1])) i--; return i; }
    function wordRight(i) { while (i < v.length && /\s/.test(v[i])) i++; while (i < v.length && !/\s/.test(v[i])) i++; return i; }
    function move(to, extend) {
      to = Math.max(0, Math.min(v.length, to));
      if (extend) {
        if (S.anchor === null) S.anchor = (to < a) ? b : a;
        q.setSelectionRange(Math.min(S.anchor, to), Math.max(S.anchor, to));
      } else { S.anchor = null; q.setSelectionRange(to, to); }
    }
    var here = (S.anchor !== null && S.anchor === a) ? b : a;
    if (ctrlOnly && (k === 'a' || k === 'A')) { S.anchor = 0; q.setSelectionRange(0, v.length); return; }
    if (ctrlOnly && (k === 'c' || k === 'C' || k === 'x' || k === 'X')) {
      if (a !== b) { fx.clipboardWrite(v.slice(a, b)); if (k === 'x' || k === 'X') put(v.slice(0, a) + v.slice(b), a); }
      return;
    }
    if (ctrlOnly && (k === 'v' || k === 'V')) { fx.clipboardRead().then(function (t) { v = q.value; a = q.selectionStart; b = q.selectionEnd; insert(t); drawCaret(); }); return; }
    if (k === 'Backspace') {
      if (a !== b) put(v.slice(0, a) + v.slice(b), a);
      else if (a > 0) { var s0 = ctrlOnly ? wordLeft(a) : a - 1; put(v.slice(0, s0) + v.slice(a), s0); }
      return;
    }
    if (k === 'Delete') {
      if (a !== b) put(v.slice(0, a) + v.slice(b), a);
      else if (a < v.length) { var e0 = ctrlOnly ? wordRight(a) : a + 1; put(v.slice(0, a) + v.slice(e0), a); }
      return;
    }
    if (k === 'ArrowLeft') { move(a !== b && !ev.shift ? a : (ctrlOnly ? wordLeft(here) : here - 1), ev.shift); return; }
    if (k === 'ArrowRight') { move(a !== b && !ev.shift ? b : (ctrlOnly ? wordRight(here) : here + 1), ev.shift); return; }
    if (k === 'Home') { move(0, ev.shift); return; }
    if (k === 'End') { move(v.length, ev.shift); return; }
    if (ctrlOnly) return; // other Ctrl shortcuts don't type
    if (ev.text && ev.text >= ' ' && ev.text !== '\u007f') insert(ev.text);
  }

  var measureCtx = document.createElement('canvas').getContext('2d');
  function textX(i) {
    var cs = getComputedStyle(q);
    measureCtx.font = cs.fontStyle + ' ' + cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
    var w = measureCtx.measureText(q.value.slice(0, i)).width;
    return q.offsetLeft + parseFloat(cs.paddingLeft || 0) + w - q.scrollLeft;
  }
  function drawCaret() {
    var caret = $('fcaret'), fsel = $('fsel');
    if (!S.remote || !S.open) { caret.hidden = true; fsel.hidden = true; return; }
    var a = q.selectionStart, b = q.selectionEnd;
    // keep the caret inside the visible part of the box
    var right = q.offsetLeft + q.clientWidth - 2;
    var x = textX(b);
    if (x > right) { q.scrollLeft += x - right; x = textX(b); }
    if (x < q.offsetLeft) { q.scrollLeft = Math.max(0, q.scrollLeft - (q.offsetLeft - x)); x = textX(b); }
    if (a !== b) {
      var xa = Math.max(q.offsetLeft, textX(a));
      fsel.style.left = xa + 'px';
      fsel.style.width = Math.max(2, Math.min(right, x) - xa) + 'px';
      fsel.hidden = !q.value;
      caret.hidden = true;
    } else {
      fsel.hidden = true;
      caret.hidden = false;
      caret.style.left = Math.round(x) + 'px';
      // restart the blink so the caret is visible right after typing
      caret.style.animation = 'none'; void caret.offsetWidth; caret.style.animation = '';
    }
  }
  q.addEventListener('mouseup', function () { S.anchor = null; drawCaret(); });
  q.addEventListener('select', drawCaret);

  list.addEventListener('scroll', function () { renderRows(); }, { passive: true });

  rowsEl.addEventListener('mousemove', function (e) {
    var row = e.target.closest('.row');
    if (!row) return;
    var i = +row.dataset.i;
    if (i !== S.sel) setSel(i, 'mouse');
  });
  rowsEl.addEventListener('click', function (e) {
    var row = e.target.closest('.row');
    if (!row) return;
    S.sel = +row.dataset.i;
    act(e.shiftKey);
  });
  rowsEl.addEventListener('dragstart', function (e) {
    var row = e.target.closest('.row');
    if (!row) return;
    var r = S.rows[+row.dataset.i];
    e.preventDefault();
    if (r && r.item && r.item.path) { stopAudio(); fx.startDrag(r.item.id); }
  });
  window.addEventListener('mouseup', function () { fx.dragEnd(); });
  // keep typing focus in the search box
  document.addEventListener('mousedown', function (e) {
    if (e.target !== q && !e.target.closest('.empty')) setTimeout(function () { q.focus(); }, 0);
  });
  $('gear').onclick = function () { fx.openSettings(); };

  // ------------------------------------------------------------ wiring to main
  function setItems(items) {
    S.items = items || [];
    S.byId = new Map();
    S.items.forEach(function (it) { Search.prepare(it); S.byId.set(it.id, it); });
  }

  fx.onCatalog(function (items) {
    var keep = sel() && sel().id;
    setItems(items);
    buildRows();
    if (keep) for (var i = 0; i < S.rows.length; i++) if (S.rows[i].item && S.rows[i].item.id === keep) { S.sel = i; break; }
    renderScopes(); renderRows(); renderPreview(); renderKeys();
  });

  fx.onOpen(function (d) {
    S.open = true;
    S.remote = !!d.remoteKeys;
    S.anchor = null;
    S.status = d.status; S.connected = d.connected;
    if (d.settings) S.settings = d.settings;
    shell.classList.remove('open');
    void shell.offsetWidth;
    shell.classList.add('open');
    q.focus();
    q.select();
    list.scrollTop = 0;
    refresh('open');
    drawCaret();
  });

  if (fx.onClip) fx.onClip(function (c) {
    S.clip = c || null;
    var keep = sel() && sel().id;
    buildRows();
    // a fresh copied image goes on top and is picked; otherwise keep what was selected
    var pasteOnTop = S.rows[1] && S.rows[1].item === PASTE;
    if (!pasteOnTop && keep && keep !== PASTE.id) for (var i = 0; i < S.rows.length; i++) if (S.rows[i].item && S.rows[i].item.id === keep) { S.sel = i; break; }
    renderRows(); renderPreview(); renderKeys();
  });

  fx.onStatus(function (d) {
    S.status = d.status; S.connected = d.connected;
    renderCtx();
    var keep = sel() && sel().id;
    if (!S.query.trim()) {
      buildRows();
      if (keep) for (var i = 0; i < S.rows.length; i++) if (S.rows[i].item && S.rows[i].item.id === keep) { S.sel = i; break; }
      renderRows();
    }
    renderPreview();
  });

  fx.onClosing(function () {
    S.open = false;
    fx.remember(S.query, S.scope);
    stopAudio();
    var v = preview.querySelector('video');
    if (v) v.pause();
    shell.classList.remove('open');
  });

  fx.ready().then(function (d) {
    S.settings = d.settings || {};
    S.connected = d.connected;
    S.status = d.status;
    S.scope = S.settings.lastScope || 'all';
    S.query = S.settings.lastQuery || '';
    q.value = S.query;
    setItems(d.items);
    refresh('open');
  });
})();
