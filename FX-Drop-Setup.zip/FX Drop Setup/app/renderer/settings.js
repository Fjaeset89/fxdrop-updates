(function () {
  'use strict';
  var fx = window.fx;
  var $ = function (id) { return document.getElementById(id); };
  var state = null;

  function prettyAccel(a) { return String(a || '').replace(/CommandOrControl|Control/g, 'Ctrl'); }

  // ---- pages (left menu)
  var PAGE_NAMES = {};
  Array.prototype.forEach.call(document.querySelectorAll('#nav button'), function (b) { PAGE_NAMES[b.dataset.go] = b.textContent.trim(); });
  var current = null;
  function showPage(id) {
    if (!document.querySelector('.page[data-page="' + id + '"]')) id = 'library';
    current = id;
    Array.prototype.forEach.call(document.querySelectorAll('.page'), function (p) { p.hidden = p.dataset.page !== id; });
    Array.prototype.forEach.call(document.querySelectorAll('#nav button'), function (b) { b.classList.toggle('on', b.dataset.go === id); });
    document.querySelector('main').scrollTop = 0;
    if (id === 'whatsnew' && state && state.whatsNew && state.whatsNew.unseen) {
      fx.whatsNewSeen();
      state.whatsNew.unseen = false;
      $('newdot').hidden = true;
    }
  }
  Array.prototype.forEach.call(document.querySelectorAll('#nav button'), function (b) { b.onclick = function () { showPage(b.dataset.go); }; });
  if (fx.onSettingsPage) fx.onSettingsPage(function (id) { showPage(id); });

  function cmpVer(a, b) {
    var x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (var i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0) ? -1 : 1;
    return 0;
  }
  function renderWhatsNew(w) {
    var box = $('whatsNewList');
    box.textContent = '';
    if (!w || !w.entries || !w.entries.length) return;
    function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x !== undefined) e.textContent = x; return e; }
    w.entries.forEach(function (v) {
      box.appendChild(el('div', 'wn-ver', 'Version ' + v.version));
      (v.items || []).forEach(function (it) {
        var card = el('div', 'wn');
        card.dataset.kind = it.kind || 'vfx';
        var t = el('div', 't');
        var fresh = w.seenBefore && cmpVer(v.version, w.seenBefore) > 0;
        t.appendChild(el('span', 'tag' + (fresh ? ' fresh' : ''), fresh ? 'New for you' : (it.tag || 'New')));
        t.appendChild(document.createTextNode(it.title));
        card.appendChild(t);
        card.appendChild(el('div', 'x', it.text));
        if (it.how || it.page) {
          var go = el('div', 'go');
          if (it.how) { var c = el('span', 'chip'); c.appendChild(document.createTextNode('Key ')); c.appendChild(el('b', null, it.how)); go.appendChild(c); }
          if (it.page && PAGE_NAMES[it.page]) { var l = el('button', 'link', 'Settings: ' + PAGE_NAMES[it.page] + ' →'); l.onclick = function () { showPage(it.page); }; go.appendChild(l); }
          card.appendChild(go);
        }
        box.appendChild(card);
      });
    });
  }

  function renderProfiles(p) {
    function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x !== undefined) e.textContent = x; return e; }
    var box = $('profList');
    if (!box || !p) return;
    if (box.contains(document.activeElement) && document.activeElement.type === 'text') return; // don't wipe a name being typed
    box.textContent = '';
    p.list.forEach(function (x) {
      var row = el('div', 'prof');
      var r = document.createElement('input'); r.type = 'radio'; r.name = 'prof'; r.checked = x.id === p.active; r.title = 'Use this profile';
      r.onchange = function () { fx.switchProfile(x.id); };
      var name = document.createElement('input'); name.type = 'text'; name.className = 'text'; name.maxLength = 30; name.value = x.name;
      name.onchange = function () { if (name.value.trim()) fx.renameProfile(x.id, name.value); else name.value = x.name; };
      name.onkeydown = function (e) { if (e.key === 'Enter') name.blur(); };
      var del = el('button', 'btn ghost', 'Delete');
      del.disabled = p.list.length < 2;
      del.onclick = function () {
        if (x.count && del.textContent === 'Delete') { del.textContent = 'Really delete?'; setTimeout(function () { del.textContent = 'Delete'; }, 3000); return; }
        fx.deleteProfile(x.id);
      };
      row.appendChild(r); row.appendChild(name); row.appendChild(el('span', 'n', x.count + ' starred')); row.appendChild(del);
      box.appendChild(row);
    });
  }
  $('profAdd').onclick = function () {
    var v = $('profName').value.trim();
    if (!v) { $('profName').focus(); return; }
    $('profName').value = '';
    fx.addProfile(v);
  };
  $('profName').onkeydown = function (e) { if (e.key === 'Enter') $('profAdd').onclick(); };

  function render(d) {
    state = d;
    renderProfiles(d.profiles);
    var s = d.settings;
    renderWhatsNew(d.whatsNew);
    $('newdot').hidden = !(d.whatsNew && d.whatsNew.unseen) || current === 'whatsnew';
    if (!current) showPage((location.hash || '').slice(1) || 'library');
    $('ver').textContent = 'Version ' + d.version;
    var st = $('status');
    st.className = 'status ' + (d.connected ? 'on' : 'off');
    st.textContent = '';
    var dot = document.createElement('span'); dot.className = 'dot';
    st.appendChild(dot);
    st.appendChild(document.createTextNode(d.connected ? 'Connected to Premiere' : 'Premiere not connected'));

    $('welcome').hidden = !!s.welcomeDone;
    $('wkey').textContent = prettyAccel(s.hotkey);
    $('restart').hidden = !d.needsRestart;

    var ul = $('folders');
    ul.textContent = '';
    if (!s.libraryFolders.length) {
      var li0 = document.createElement('li');
      li0.className = 'none';
      li0.textContent = 'No folders yet';
      ul.appendChild(li0);
    }
    s.libraryFolders.forEach(function (f, i) {
      var li = document.createElement('li');
      var p = document.createElement('span'); p.className = 'path'; p.textContent = f; p.title = f;
      li.appendChild(p);
      var open = document.createElement('button'); open.className = 'icon-btn'; open.title = 'Open folder'; open.textContent = '↗';
      open.onclick = function () { fx.openFolder(f); };
      li.appendChild(open);
      var rm = document.createElement('button'); rm.className = 'icon-btn'; rm.title = 'Remove from FX Drop (files stay on disk)'; rm.textContent = '×';
      rm.onclick = function () {
        var next = s.libraryFolders.slice(); next.splice(i, 1);
        fx.setSettings({ libraryFolders: next }).then(load);
      };
      li.appendChild(rm);
      ul.appendChild(li);
    });
    var c = d.counts || {};
    $('counts').textContent = d.scanning ? 'Scanning…' :
      (c.sfx || 0).toLocaleString() + ' sounds, ' + (c.vfx || 0).toLocaleString() + ' visuals, ' +
      (c.preset || 0).toLocaleString() + ' presets and ' + (c.effect || 0).toLocaleString() + ' Premiere effects ready to search.';

    $('usePremierePresets').checked = !!s.usePremierePresets;
    $('presetInfo').textContent = d.presetFile
      ? d.premierePresetCount + ' presets from ' + d.presetFile
      : 'Couldn’t find Premiere’s preset file. Choose it below.';

    if (!recording) $('hotkey').textContent = prettyAccel(s.hotkey);
    $('hotkeyError').hidden = !d.hotkeyError;
    $('hotkeyError').textContent = d.hotkeyError || '';
    $('hotkeyOnlyInPremiere').checked = !!s.hotkeyOnlyInPremiere;
    $('hotkeyOnlyInPremiere').disabled = !d.helperOk;

    $('autoPreview').checked = !!s.autoPreview;
    $('previewVolume').value = s.previewVolume;
    $('vfxIncludeAudio').checked = !!s.vfxIncludeAudio;
    $('adjSeconds').value = s.adjSeconds;
    $('sfxVolumeDb').value = s.sfxVolumeDb;
    $('pasteFit').checked = s.pasteFit !== false;
    $('smartPaste').checked = s.smartPaste !== false;
    $('pasteImagesCtrlV').checked = s.pasteImagesCtrlV !== false;
    ['smartPasteKey', 'smartCutKey', 'premierePasteKey'].forEach(function (id) { $(id).value = prettyKey(s[id]); });
    $('pasteMotion').checked = s.pasteMotion !== false;
    $('pasteZoomTo').value = s.pasteZoomTo || 105;
    $('pasteZoomTo').disabled = s.pasteMotion === false;
    $('adjSpanSelection').checked = !!s.adjSpanSelection;
    $('startWithWindows').checked = !!s.startWithWindows;
    $('keyframeTimeBase').value = s.keyframeTimeBase;

    renderUpdate(d.update, d.version);
    renderPlugin(d.premierePlugin || {});

    $('connDesc').textContent = d.connected
      ? 'FX Drop is talking to Premiere.'
      : d.extensionInstalled
        ? 'The Premiere extension is installed. Open (or restart) Premiere Pro and this turns green. You can also open Window › Extensions › FX Drop in Premiere to check it.'
        : 'The Premiere extension isn’t installed yet. Click “Reinstall Premiere extension”, then restart Premiere.';
  }

  function renderUpdate(u, version) {
    u = u || {};
    $('autoUpdate').checked = !!(state && state.settings.autoUpdate);
    $('autoUpdate').disabled = !u.enabled;
    $('checkUpdate').disabled = !u.enabled || u.status === 'checking' || u.status === 'downloading';
    $('installUpdate').hidden = !u.staged;
    if (u.staged) $('installUpdate').textContent = 'Install ' + u.staged + ' now';
    var t;
    if (!u.enabled) t = 'Updates are set up when FX Drop is installed with the installer.';
    else if (u.status === 'checking') t = 'Checking…';
    else if (u.status === 'downloading') t = 'Downloading version ' + u.latest + '…';
    else if (u.staged) t = 'Version ' + u.staged + ' is ready. It installs itself when you’re not using FX Drop (takes a few seconds).';
    else if (u.status === 'error' || u.status === 'needs-installer') t = u.error || 'Couldn’t check for updates.';
    else if (u.status === 'current') t = 'You have the newest version (' + version + ').';
    else t = 'FX Drop checks for new versions on its own every few hours.';
    $('updateDesc').textContent = t;
  }

  function renderPlugin(p) {
    var t;
    if (p.connected) t = 'Premiere plugin: connected. Presets and effects are one step in Premiere’s History, so one Ctrl+Z undoes them.';
    else if (p.ok) t = 'Premiere plugin: installed. Restart Premiere, then open Window › UXP Plugins › FX Drop once and dock the small panel anywhere. Premiere loads it every time after that.';
    else if (p.missing) t = 'Premiere plugin: Adobe’s plugin installer wasn’t found. Click “Install Premiere plugin” to install it through Creative Cloud.';
    else t = 'Premiere plugin: not installed yet. Until it is, FX Drop uses the classic connection (works, but Ctrl+Z can’t undo presets).';
    $('pluginDesc').textContent = t;
    $('installPlugin').textContent = p.ok ? 'Reinstall Premiere plugin' : 'Install Premiere plugin';
  }

  function load() { return fx.getSettings().then(render); }

  function bindToggle(id) {
    $(id).addEventListener('change', function () { var p = {}; p[id] = $(id).checked; fx.setSettings(p); });
  }
  ['usePremierePresets', 'hotkeyOnlyInPremiere', 'autoPreview', 'vfxIncludeAudio', 'adjSpanSelection', 'startWithWindows', 'autoUpdate', 'pasteFit', 'pasteMotion', 'smartPaste', 'pasteImagesCtrlV'].forEach(bindToggle);
  // key fields: click and press the keys (e.g. Alt+V)
  function prettyKey(a) { return String(a || '').replace(/Control|CommandOrControl/g, 'Ctrl'); }
  var KEY_DEFAULT = { smartPasteKey: 'Alt+V', smartCutKey: 'Control+Alt+X', premierePasteKey: 'Control+V' };
  ['smartPasteKey', 'smartCutKey', 'premierePasteKey'].forEach(function (id) {
    var f = $(id);
    f.addEventListener('keydown', function (e) {
      e.preventDefault();
      if (e.key === 'Escape') { f.blur(); return; }
      if (e.key === 'Backspace' || e.key === 'Delete') { f.value = prettyKey(KEY_DEFAULT[id]); var d = {}; d[id] = KEY_DEFAULT[id]; fx.setSettings(d); return; }
      var k = e.key;
      if (['Control', 'Shift', 'Alt', 'Meta'].indexOf(k) >= 0) return;
      if (/^[a-z0-9]$/i.test(k)) k = k.toUpperCase();
      else if (!/^F([1-9]|1[0-2])$/.test(k)) return;
      var parts = [];
      if (e.ctrlKey) parts.push('Control');
      if (e.altKey) parts.push('Alt');
      if (e.shiftKey) parts.push('Shift');
      if (!parts.length && !/^F/.test(k)) return; // a plain letter would block typing
      parts.push(k);
      var acc = parts.join('+');
      f.value = prettyKey(acc);
      var p = {}; p[id] = acc; fx.setSettings(p);
    });
  });
  $('pasteMotion').addEventListener('change', function () { $('pasteZoomTo').disabled = !$('pasteMotion').checked; });
  $('pasteZoomTo').addEventListener('change', function () {
    var v = parseFloat(String($('pasteZoomTo').value).replace(',', '.'));
    if (isNaN(v)) v = 105;
    v = Math.max(101, Math.min(150, Math.round(v)));
    $('pasteZoomTo').value = v;
    fx.setSettings({ pasteZoomTo: v });
  });
  $('previewVolume').addEventListener('change', function () { fx.setSettings({ previewVolume: +$('previewVolume').value }); });
  $('sfxVolumeDb').addEventListener('change', function () {
    var v = parseFloat(String($('sfxVolumeDb').value).replace(',', '.'));
    if (isNaN(v)) v = -6;
    v = Math.max(-40, Math.min(15, Math.round(v * 2) / 2));
    $('sfxVolumeDb').value = v;
    fx.setSettings({ sfxVolumeDb: v });
  });
  $('adjSeconds').addEventListener('change', function () {
    var v = Math.max(0.2, Math.min(600, +$('adjSeconds').value || 3));
    fx.setSettings({ adjSeconds: v });
  });
  $('keyframeTimeBase').addEventListener('change', function () { fx.setSettings({ keyframeTimeBase: $('keyframeTimeBase').value }); });

  $('addFolder').onclick = function () { fx.addFolder().then(load); };
  $('starter').onclick = function () { fx.createStarter().then(load); };
  $('rescan').onclick = function () { fx.rescan(); setTimeout(load, 800); };
  $('choosePreset').onclick = function () { fx.choosePresetFile().then(load); };
  $('tryPopup').onclick = function () { fx.tryPopup(); };
  $('openLog').onclick = function () { fx.openLog(); };
  $('installPlugin').onclick = function () {
    $('installPlugin').disabled = true;
    $('pluginDesc').textContent = 'Installing…';
    fx.installPlugin().then(function () { $('installPlugin').disabled = false; load(); }, function () { $('installPlugin').disabled = false; load(); });
  };
  $('checkUpdate').onclick = function () {
    $('checkUpdate').disabled = true;
    $('updateDesc').textContent = 'Checking…';
    fx.checkUpdate().then(load, load);
  };
  $('installUpdate').onclick = function () { $('installUpdate').disabled = true; fx.installUpdate(); };
  $('test').onclick = function () {
    $('test').disabled = true;
    fx.testConnection().then(function () { $('test').disabled = false; load(); });
  };
  $('reinstall').onclick = function () {
    $('reinstall').disabled = true;
    fx.reinstall().then(function (r) {
      $('reinstall').disabled = false;
      $('reinstall').textContent = r.ok ? 'Installed — restart Premiere' : 'Couldn’t install';
      load();
    });
  };
  $('done').onclick = function () {
    fx.setSettings({ welcomeDone: true }).then(function () { window.close(); });
  };

  // ---- shortcut recorder
  var recording = false;
  var CODE = { Space: 'Space', Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Backslash: '\\', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Enter: 'Enter', Tab: 'Tab', Insert: 'Insert', Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown' };
  function accelFrom(e) {
    var key = null;
    if (/^Key[A-Z]$/.test(e.code)) key = e.code.slice(3);
    else if (/^Digit[0-9]$/.test(e.code)) key = e.code.slice(5);
    else if (/^F([1-9]|1[0-9]|2[0-4])$/.test(e.code)) key = e.code;
    else if (/^Numpad[0-9]$/.test(e.code)) key = 'num' + e.code.slice(6);
    else if (CODE[e.code]) key = CODE[e.code];
    if (!key) return null;
    var mods = [];
    if (e.ctrlKey) mods.push('Control');
    if (e.altKey) mods.push('Alt');
    if (e.shiftKey) mods.push('Shift');
    if (e.metaKey) mods.push('Super');
    if (!mods.length && !/^F\d+$/.test(key)) return null;
    return mods.concat(key).join('+');
  }
  $('hotkey').onclick = function () {
    recording = true;
    $('hotkey').classList.add('rec');
    $('hotkey').textContent = 'Press keys…';
  };
  window.addEventListener('keydown', function (e) {
    if (!recording) return;
    e.preventDefault();
    if (e.key === 'Escape') { recording = false; $('hotkey').classList.remove('rec'); load(); return; }
    var acc = accelFrom(e);
    if (!acc) return;
    recording = false;
    $('hotkey').classList.remove('rec');
    fx.setSettings({ hotkey: acc }).then(load);
  }, true);

  fx.onSettingsChanged(load);
  load();
  setInterval(load, 5000);
})();
