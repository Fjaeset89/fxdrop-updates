(function () {
  'use strict';
  var fx = window.fx;
  var $ = function (id) { return document.getElementById(id); };
  var state = null;

  function prettyAccel(a) { return String(a || '').replace(/CommandOrControl|Control/g, 'Ctrl'); }

  function render(d) {
    state = d;
    var s = d.settings;
    $('ver').textContent = 'Version ' + d.version;
    var st = $('status');
    st.className = 'status ' + (d.connected ? 'on' : 'off');
    st.textContent = '';
    var dot = document.createElement('span'); dot.className = 'dot';
    st.appendChild(dot);
    st.appendChild(document.createTextNode(d.connected ? 'Connected to Premiere' : 'Premiere not connected'));

    $('welcome').hidden = !!s.welcomeDone;
    $('wkey').textContent = prettyAccel(s.hotkey);
    $('restart').hidden = !d.needsRestart;

    var ul = $('folders');
    ul.textContent = '';
    if (!s.libraryFolders.length) {
      var li0 = document.createElement('li');
      li0.className = 'none';
      li0.textContent = 'No folders yet';
      ul.appendChild(li0);
    }
    s.libraryFolders.forEach(function (f, i) {
      var li = document.createElement('li');
      var p = document.createElement('span'); p.className = 'path'; p.textContent = f; p.title = f;
      li.appendChild(p);
      var open = document.createElement('button'); open.className = 'icon-btn'; open.title = 'Open folder'; open.textContent = '↗';
      open.onclick = function () { fx.openFolder(f); };
      li.appendChild(open);
      var rm = document.createElement('button'); rm.className = 'icon-btn'; rm.title = 'Remove from FX Drop (files stay on disk)'; rm.textContent = '×';
      rm.onclick = function () {
        var next = s.libraryFolders.slice(); next.splice(i, 1);
        fx.setSettings({ libraryFolders: next }).then(load);
      };
      li.appendChild(rm);
      ul.appendChild(li);
    });
    var c = d.counts || {};
    $('counts').textContent = d.scanning ? 'Scanning…' :
      (c.sfx || 0).toLocaleString() + ' sounds, ' + (c.vfx || 0).toLocaleString() + ' visuals, ' +
      (c.preset || 0).toLocaleString() + ' presets and ' + (c.effect || 0).toLocaleString() + ' Premiere effects ready to search.';

    $('usePremierePresets').checked = !!s.usePremierePresets;
    $('presetInfo').textContent = d.presetFile
      ? d.premierePresetCount + ' presets from ' + d.presetFile
      : 'Couldn’t find Premiere’s preset file. Choose it below.';

    if (!recording) $('hotkey').textContent = prettyAccel(s.hotkey);
    $('hotkeyError').hidden = !d.hotkeyError;
    $('hotkeyError').textContent = d.hotkeyError || '';
    $('hotkeyOnlyInPremiere').checked = !!s.hotkeyOnlyInPremiere;
    $('hotkeyOnlyInPremiere').disabled = !d.helperOk;

    $('autoPreview').checked = !!s.autoPreview;
    $('previewVolume').value = s.previewVolume;
    $('vfxIncludeAudio').checked = !!s.vfxIncludeAudio;
    $('adjSeconds').value = s.adjSeconds;
    $('adjSpanSelection').checked = !!s.adjSpanSelection;
    $('startWithWindows').checked = !!s.startWithWindows;
    $('keyframeTimeBase').value = s.keyframeTimeBase;

    renderUpdate(d.update, d.version);
    renderPlugin(d.premierePlugin || {});

    $('connDesc').textContent = d.connected
      ? 'FX Drop is talking to Premiere.'
      : d.extensionInstalled
        ? 'The Premiere extension is installed. Open (or restart) Premiere Pro and this turns green. You can also open Window › Extensions › FX Drop in Premiere to check it.'
        : 'The Premiere extension isn’t installed yet. Click “Reinstall Premiere extension”, then restart Premiere.';
  }

  function renderUpdate(u, version) {
    u = u || {};
    $('autoUpdate').checked = !!(state && state.settings.autoUpdate);
    $('autoUpdate').disabled = !u.enabled;
    $('checkUpdate').disabled = !u.enabled || u.status === 'checking' || u.status === 'downloading';
    $('installUpdate').hidden = !u.staged;
    if (u.staged) $('installUpdate').textContent = 'Install ' + u.staged + ' now';
    var t;
    if (!u.enabled) t = 'Updates are set up when FX Drop is installed with the installer.';
    else if (u.status === 'checking') t = 'Checking…';
    else if (u.status === 'downloading') t = 'Downloading version ' + u.latest + '…';
    else if (u.staged) t = 'Version ' + u.staged + ' is ready. It installs itself when you’re not using FX Drop (takes a few seconds).';
    else if (u.status === 'error' || u.status === 'needs-installer') t = u.error || 'Couldn’t check for updates.';
    else if (u.status === 'current') t = 'You have the newest version (' + version + ').';
    else t = 'FX Drop checks for new versions on its own every few hours.';
    $('updateDesc').textContent = t;
  }

  function renderPlugin(p) {
    var t;
    if (p.connected) t = 'Premiere plugin: connected. Presets and effects are one step in Premiere’s History, so one Ctrl+Z undoes them.';
    else if (p.ok) t = 'Premiere plugin: installed. Restart Premiere, then open Window › UXP Plugins › FX Drop once and dock the small panel anywhere. Premiere loads it every time after that.';
    else if (p.missing) t = 'Premiere plugin: Adobe’s plugin installer wasn’t found. Click “Install Premiere plugin” to install it through Creative Cloud.';
    else t = 'Premiere plugin: not installed yet. Until it is, FX Drop uses the classic connection (works, but Ctrl+Z can’t undo presets).';
    $('pluginDesc').textContent = t;
    $('installPlugin').textContent = p.ok ? 'Reinstall Premiere plugin' : 'Install Premiere plugin';
  }

  function load() { return fx.getSettings().then(render); }

  function bindToggle(id) {
    $(id).addEventListener('change', function () { var p = {}; p[id] = $(id).checked; fx.setSettings(p); });
  }
  ['usePremierePresets', 'hotkeyOnlyInPremiere', 'autoPreview', 'vfxIncludeAudio', 'adjSpanSelection', 'startWithWindows', 'autoUpdate'].forEach(bindToggle);
  $('previewVolume').addEventListener('change', function () { fx.setSettings({ previewVolume: +$('previewVolume').value }); });
  $('adjSeconds').addEventListener('change', function () {
    var v = Math.max(0.2, Math.min(600, +$('adjSeconds').value || 3));
    fx.setSettings({ adjSeconds: v });
  });
  $('keyframeTimeBase').addEventListener('change', function () { fx.setSettings({ keyframeTimeBase: $('keyframeTimeBase').value }); });

  $('addFolder').onclick = function () { fx.addFolder().then(load); };
  $('starter').onclick = function () { fx.createStarter().then(load); };
  $('rescan').onclick = function () { fx.rescan(); setTimeout(load, 800); };
  $('choosePreset').onclick = function () { fx.choosePresetFile().then(load); };
  $('tryPopup').onclick = function () { fx.tryPopup(); };
  $('openLog').onclick = function () { fx.openLog(); };
  $('installPlugin').onclick = function () {
    $('installPlugin').disabled = true;
    $('pluginDesc').textContent = 'Installing…';
    fx.installPlugin().then(function () { $('installPlugin').disabled = false; load(); }, function () { $('installPlugin').disabled = false; load(); });
  };
  $('checkUpdate').onclick = function () {
    $('checkUpdate').disabled = true;
    $('updateDesc').textContent = 'Checking…';
    fx.checkUpdate().then(load, load);
  };
  $('installUpdate').onclick = function () { $('installUpdate').disabled = true; fx.installUpdate(); };
  $('test').onclick = function () {
    $('test').disabled = true;
    fx.testConnection().then(function () { $('test').disabled = false; load(); });
  };
  $('reinstall').onclick = function () {
    $('reinstall').disabled = true;
    fx.reinstall().then(function (r) {
      $('reinstall').disabled = false;
      $('reinstall').textContent = r.ok ? 'Installed — restart Premiere' : 'Couldn’t install';
      load();
    });
  };
  $('done').onclick = function () {
    fx.setSettings({ welcomeDone: true }).then(function () { window.close(); });
  };

  // ---- shortcut recorder
  var recording = false;
  var CODE = { Space: 'Space', Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Backslash: '\\', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Enter: 'Enter', Tab: 'Tab', Insert: 'Insert', Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown' };
  function accelFrom(e) {
    var key = null;
    if (/^Key[A-Z]$/.test(e.code)) key = e.code.slice(3);
    else if (/^Digit[0-9]$/.test(e.code)) key = e.code.slice(5);
    else if (/^F([1-9]|1[0-9]|2[0-4])$/.test(e.code)) key = e.code;
    else if (/^Numpad[0-9]$/.test(e.code)) key = 'num' + e.code.slice(6);
    else if (CODE[e.code]) key = CODE[e.code];
    if (!key) return null;
    var mods = [];
    if (e.ctrlKey) mods.push('Control');
    if (e.altKey) mods.push('Alt');
    if (e.shiftKey) mods.push('Shift');
    if (e.metaKey) mods.push('Super');
    if (!mods.length && !/^F\d+$/.test(key)) return null;
    return mods.concat(key).join('+');
  }
  $('hotkey').onclick = function () {
    recording = true;
    $('hotkey').classList.add('rec');
    $('hotkey').textContent = 'Press keys…';
  };
  window.addEventListener('keydown', function (e) {
    if (!recording) return;
    e.preventDefault();
    if (e.key === 'Escape') { recording = false; $('hotkey').classList.remove('rec'); load(); return; }
    var acc = accelFrom(e);
    if (!acc) return;
    recording = false;
    $('hotkey').classList.remove('rec');
    fx.setSettings({ hotkey: acc }).then(load);
  }, true);

  fx.onSettingsChanged(load);
  load();
  setInterval(load, 5000);
})();
