// FX Drop plugin for Premiere: keeps a connection to the FX Drop app and runs its commands
// (presets, effects) as single, undoable steps. This panel can stay small or hidden; it only
// needs to be part of your workspace so Premiere loads it at start.
'use strict';
const ppro = require('premierepro');
const config = require('./config.js');
const { createConnection } = require('./connection.js');
const { createOps } = require('./ops.js');

let premiereVersion = '';
try { premiereVersion = require('uxp').host.version; } catch (e) {}

function show(on, text) {
  try {
    document.getElementById('dot').className = on ? 'dot on' : 'dot';
    document.getElementById('sub').textContent = text;
  } catch (e) {}
}
const log = (...a) => { try { console.log('[FX Drop]', ...a); } catch (e) {} };

const ops = createOps(ppro, { version: config.version, storage: window.localStorage, log });
const handlers = {
  ping: async () => ({ version: config.version, premiere: premiereVersion, via: 'uxp' }),
  status: () => ops.status(),
  applyPreset: (a) => ops.applyPreset(a),
  applyEffect: (a) => ops.applyEffect(a),
};

const conn = createConnection({
  url: `ws://127.0.0.1:${config.port}`,
  token: config.token,
  version: config.version,
  premiere: premiereVersion,
  handlers,
  log,
});

setInterval(() => {
  show(conn.open, conn.open ? 'Connected – presets and effects undo in one step.' : 'Waiting for the FX Drop app…');
}, 1500);
