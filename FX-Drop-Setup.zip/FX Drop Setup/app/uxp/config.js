// Replaced with this computer's settings when FX Drop installs the plugin.
module.exports = { port: 47322, token: 'development-token', version: '0.0.0' };
