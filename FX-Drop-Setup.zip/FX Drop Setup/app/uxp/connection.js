// FX Drop plugin <-> FX Drop app connection (runs inside Premiere's UXP plugin system).
// Keeps a WebSocket open to the FX Drop app on this computer, proves who it is with the
// install token, then runs the commands the app sends and answers each one.
'use strict';

// urls: tried in turn until one works (Premiere's plugin system can be picky about addresses)
function createConnection({ url, urls, token, version, premiere, handlers, log }) {
  const list = urls && urls.length ? urls : [url];
  let ws = null;
  let authed = false;
  let retryMs = 1000;
  let stopped = false;
  let timer = null;
  let attempt = 0;
  let lastError = '';
  const can = Object.keys(handlers);

  function schedule() {
    if (stopped) return;
    clearTimeout(timer);
    timer = setTimeout(open, retryMs);
    retryMs = Math.min(retryMs * 2, 15000);
  }

  function make(u) {
    try { return new WebSocket(u); } catch (e) {
      lastError = (e && e.message) || String(e);
      try { return new WebSocket(u, 'fxdrop'); } catch (e2) { lastError = (e2 && e2.message) || String(e2); return null; }
    }
  }

  function open() {
    if (stopped) return;
    const u = list[attempt++ % list.length];
    const sock = make(u);
    if (!sock) { log('connect failed', u, lastError); schedule(); return; }
    ws = sock;
    authed = false;
    sock.onopen = () => {
      retryMs = 1000;
      lastError = '';
      sock.send(JSON.stringify({ type: 'hello', token, version, premiere, can }));
    };
    sock.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (!msg) return;
      if (msg.type === 'welcome') { authed = true; attempt--; return; } // keep using the address that worked
      if (msg.id === undefined || !msg.fn) return;
      run(msg);
    };
    let ended = false;
    const end = (ev) => {
      if (ended) return;
      ended = true;
      if (ws === sock) ws = null;
      authed = false;
      if (ev && ev.code === 1008) lastError = 'FX Drop refused the plugin (old install key) - reinstall it from FX Drop settings';
      else if (!lastError) lastError = 'no answer from ' + u + (ev && ev.code ? ' (' + ev.code + ')' : '');
      schedule();
    };
    sock.onclose = end;
    sock.onerror = (ev) => {
      lastError = 'cannot reach ' + u + (ev && ev.message ? ': ' + ev.message : '');
      // a close event normally follows; don't call close() here (some clients loop on it)
      setTimeout(() => end(null), 3000);
    };
  }

  // one command at a time, in order, so edits never interleave
  let queue = Promise.resolve();
  function run(msg) {
    queue = queue.then(async () => {
      const h = handlers[msg.fn];
      let reply;
      if (!h) reply = { id: msg.id, ok: false, code: 'UNKNOWN', error: 'Unknown command ' + msg.fn };
      else {
        try { reply = { id: msg.id, ok: true, result: await h(msg.args || {}) }; }
        catch (e) {
          reply = { id: msg.id, ok: false, code: (e && e.code) || 'ERROR', error: (e && e.message) || String(e) };
          if (!e || !e.code) log('command failed', msg.fn, e && (e.stack || e.message));
        }
      }
      try { if (ws) ws.send(JSON.stringify(reply)); } catch (e) {}
    });
  }

  open();
  return {
    stop() { stopped = true; clearTimeout(timer); try { ws && ws.close(); } catch (e) {} },
    get open() { return !!ws && authed; },
    get lastError() { return lastError; },
  };
}

module.exports = { createConnection };
