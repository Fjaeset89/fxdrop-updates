// FX Drop plugin <-> FX Drop app connection (runs inside Premiere's UXP plugin system).
// Keeps a WebSocket open to the FX Drop app on this computer, proves who it is with the
// install token, then runs the commands the app sends and answers each one.
'use strict';

function createConnection({ url, token, version, premiere, handlers, log }) {
  let ws = null;
  let retryMs = 1000;
  let stopped = false;
  let timer = null;
  const can = Object.keys(handlers);

  function schedule() {
    if (stopped) return;
    clearTimeout(timer);
    timer = setTimeout(open, retryMs);
    retryMs = Math.min(retryMs * 2, 15000);
  }

  function open() {
    if (stopped) return;
    try { ws = new WebSocket(url); } catch (e) { log('connect failed', e && e.message); schedule(); return; }
    ws.onopen = () => {
      retryMs = 1000;
      ws.send(JSON.stringify({ type: 'hello', token, version, premiere, can }));
    };
    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (!msg || msg.id === undefined || !msg.fn) return;
      run(msg);
    };
    ws.onclose = () => { ws = null; schedule(); };
    ws.onerror = () => { try { ws && ws.close(); } catch (e) {} };
  }

  // one command at a time, in order, so edits never interleave
  let queue = Promise.resolve();
  function run(msg) {
    queue = queue.then(async () => {
      const h = handlers[msg.fn];
      let reply;
      if (!h) reply = { id: msg.id, ok: false, code: 'UNKNOWN', error: 'Unknown command ' + msg.fn };
      else {
        try { reply = { id: msg.id, ok: true, result: await h(msg.args || {}) }; }
        catch (e) {
          reply = { id: msg.id, ok: false, code: (e && e.code) || 'ERROR', error: (e && e.message) || String(e) };
          if (!e || !e.code) log('command failed', msg.fn, e && (e.stack || e.message));
        }
      }
      try { if (ws) ws.send(JSON.stringify(reply)); } catch (e) {}
    });
  }

  open();
  return { stop() { stopped = true; clearTimeout(timer); try { ws && ws.close(); } catch (e) {} }, get open() { return !!ws; } };
}

module.exports = { createConnection };
