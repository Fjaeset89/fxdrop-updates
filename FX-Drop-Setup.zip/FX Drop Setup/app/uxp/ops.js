// FX Drop commands for Premiere's UXP plugin system.
// Everything one click does is collected and committed as ONE transaction, so it is a single
// step in Premiere's History panel ("FX Drop: <preset>") and Ctrl+Z removes all of it at once.
// Reads (which are async) happen first; then one synchronous locked block builds and commits.
'use strict';

const TPS = 254016000000;
const INTRINSIC = /^(AE\.ADBE (Motion|Opacity)|AE\.ADBE Time Remapping|audioVolume|audioChannelVolume|audioPanner)$/i;

function createOps(ppro, opts) {
  const log = (opts && opts.log) || (() => {});
  const version = (opts && opts.version) || '0';
  const C = ppro.Constants;
  // Learned on this Premiere build and remembered between sessions:
  //  appendThenSet - settings on a just-added effect can go in the same step as adding it
  //  oneStepKeys   - keyframing can be switched on and keys added in the same step
  //  autoKey       - switching keyframing on drops an extra key at the playhead (we remove it)
  //  strayRule     - where exactly that extra key lands (see strayTimes), so its removal goes
  //                  in the same step as the preset and one Ctrl+Z undoes everything
  const store = (opts && opts.storage) || null;
  const learned = (() => {
    const base = { oneStepKeys: null, appendThenSet: null, autoKey: null, strayRule: null };
    try { return Object.assign(base, JSON.parse((store && store.getItem('fxdrop.learned')) || '{}')); } catch (e) { return base; }
  })();
  function remember() { try { if (store) store.setItem('fxdrop.learned', JSON.stringify(learned)); } catch (e) {} }

  function fail(code, message) { return Object.assign(new Error(message), { code }); }
  function tick(sec) { return ppro.TickTime.createWithTicks(String(Math.round(sec * TPS))); }
  function secOf(t) {
    if (!t) return 0;
    if (typeof t.ticksNumber === 'number') return t.ticksNumber / TPS;
    if (t.ticks !== undefined) return Number(t.ticks) / TPS;
    return Number(t.seconds) || 0;
  }
  const lower = (s) => String(s || '').trim().toLowerCase();
  const now = () => Date.now();

  function isVideoItem(it) {
    if (ppro.VideoClipTrackItem && it instanceof ppro.VideoClipTrackItem) return true;
    if (ppro.AudioClipTrackItem && it instanceof ppro.AudioClipTrackItem) return false;
    return /video/i.test((it && it.constructor && it.constructor.name) || '');
  }

  async function context() {
    const project = await ppro.Project.getActiveProject();
    if (!project) throw fail('NO_PROJECT', 'Open a project in Premiere first.');
    const seq = await project.getActiveSequence();
    if (!seq) throw fail('NO_SEQUENCE', 'Open a sequence in the timeline first.');
    return { project, seq };
  }

  async function selectedItems(seq, media) {
    const sel = await seq.getSelection();
    const items = sel ? await sel.getTrackItems() : [];
    return (items || []).filter((it) => media === 'any' || (media === 'video') === isVideoItem(it));
  }

  // Runs `build(add, stats)` inside one locked, undoable transaction. `build` hands each change to
  // `add` as a function that makes it, so the same build can first run dry. Returns true if committed.
  // Premiere 26 wants every change created inside both lockedAccess and the transaction itself
  // (creating them earlier gives "The script object is no longer valid").
  function commit(project, label, build, stats) {
    let ok = false;
    let err = null;
    let started = false;
    project.lockedAccess(() => {
      lastOk = now();
      try {
        // dry run, already inside the lock: reads every setting and makes every keyframe value, but
        // creates no change. Stale objects mostly show up here - before any transaction exists, so a
        // refused preset doesn't leave an empty step in Premiere's History.
        let planned = 0;
        const dry = emptyStats();
        build((make) => { if (make) planned++; }, dry);
        if (!planned) { err = new Error('Premiere didn’t accept any of this preset’s settings' + (dry.error ? ' (' + dry.error + ')' : '')); return; }
        started = true;
        ok = project.executeTransaction((ca) => {
          // build everything first: if anything fails, nothing at all is handed to Premiere
          // (Premiere keeps whatever was already added to a transaction, even when it then fails)
          const actions = [];
          try {
            lastOk = now();
            stormStats = stats || null;
            build((make) => {
              if (!make) return;
              // While Premiere is busy it refuses single requests at random, even ones made a moment
              // ago in this same transaction. steady() asks again for the same change, a few times
              // with tiny pauses, which keeps the whole preset in this ONE step.
              let a = null;
              try { a = steady(make); } catch (e) { if (stats) soft(e, stats); else throw e; return; }
              if (a) actions.push(a);
            }, stats || emptyStats());
          } catch (e) { err = e; throw e; } // nothing was added: give Premiere nothing to record
          for (const a of actions) {
            if (ca.addAction(a) === false) throw Object.assign(new Error('Premiere refused part of the change.'), { code: 'ERROR' });
          }
        }, label);
      } catch (e) { err = err || e; }
      stormStats = null;
    });
    stormStats = null;
    if (err) { err.started = started; if (!err.phase) err.phase = started ? 'change' : 'check'; throw err; }
    return ok !== false;
  }
  const CALL_TRIES = 30;      // asks per request
  const STALL_MS = 150;       // gives up once nothing at all has gone through for this long
  // Any request to Premiere made while a change is being put together goes through steady(): during
  // Premiere's busy spells ("The script object is no longer valid", at random per request, also for
  // plain reads like making a keyframe value) it's asked again a few times instead of giving up.
  // A long preset (hundreds of keys) gets as long as it needs while requests keep going through;
  // a Premiere that refuses everything is given up on after STALL_MS (the try then starts over).
  let lastOk = 0, stormStats = null;
  function steady(fn) {
    for (let n = 0; ; n++) {
      try { const r = fn(); lastOk = now(); return r; } catch (e) {
        if (isStale(e) && n < CALL_TRIES && now() - lastOk < STALL_MS) {
          if (stormStats) stormStats.retried = (stormStats.retried || 0) + 1;
          spin(Math.min(4, n * 0.5));
          continue;
        }
        throw e;
      }
    }
  }
  const hiRes = () => (typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now());
  function spin(ms) { if (!(ms > 0)) return; const until = hiRes() + ms; while (hiRes() < until) { /* wait */ } }
  function emptyStats() { return { keys: 0, values: 0, skipped: 0, failed: 0 }; }

  // Premiere's own errors (not FX Drop's friendly ones) are worth one more try with fresh objects
  const premiereError = (e) => !e || !e.code || e.code === 'ERROR';
  // Premiere's objects for a clip go stale once that clip has been changed (by FX Drop, by an undo,
  // by a cut ...): every change made through them then fails with this message
  const isStale = (e) => /no longer valid/i.test(String((e && e.message) || e || ''));
  // A setting Premiere won't take is counted and skipped - unless the objects went stale, which means
  // nothing from this try can be trusted: then the whole preset starts over with fresh objects.
  function soft(e, stats) {
    if (isStale(e)) throw e;
    stats.failed++;
    if (!stats.error) stats.error = String((e && e.message) || e).slice(0, 160);
  }

  // ---------------------------------------------------------------- finding the clips
  // The selection only tells WHICH clips are selected: Premiere keeps handing back the same clip
  // objects from it, and once a clip has been changed those are stale until the clip is clicked
  // again. The track's own list of clips is always current, so the clips are looked up there.
  //   tracks    - selected clips, looked up again on their own track (default)
  //   scan      - every clip on every track that says it's selected
  //   selection - the selection's own objects (what FX Drop did before)
  const HOW = ['tracks', 'scan', 'selection'];
  function clipType() { const T = C && C.TrackItemType; return T && T.CLIP !== undefined && T.CLIP !== null ? T.CLIP : null; }
  async function trackClips(seq, video, index, cache) {
    const key = (video ? 'v' : 'a') + index;
    if (cache && cache.has(key)) return cache.get(key);
    const track = video ? await seq.getVideoTrack(index) : await seq.getAudioTrack(index);
    const list = track ? ((await track.getTrackItems(clipType(), false)) || []).filter(Boolean) : [];
    const out = { list, starts: new Array(list.length) };
    if (cache) cache.set(key, out);
    return out;
  }
  async function startAt(t, i) {
    if (t.starts[i] === undefined) t.starts[i] = await t.list[i].getStartTime().then(secOf, () => null);
    return t.starts[i];
  }
  // where a clip sits, so it can be found again after a change
  async function placeOf(item) {
    const [index, start] = await Promise.all([item.getTrackIndex(), item.getStartTime()]);
    const i = Number(index);
    if (!(i >= 0)) throw new Error('no track index');
    return { video: isVideoItem(item), index: i, start: secOf(start) };
  }
  // the current object for the clip that sits at `at` (null when there's none). A track lists its
  // clips in time order, so a handful of reads finds it even on a track with hundreds of cuts.
  async function clipAt(seq, at, cache) {
    if (!at || clipType() === null) return null;
    const t = await trackClips(seq, at.video, at.index, cache);
    const same = (x) => x !== null && Math.abs(x - at.start) < 1e-6;
    const found = (k) => { at.k = k; at.n = t.list.length; return t.list[k]; };
    let lo = 0, hi = t.list.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const x = await startAt(t, mid);
      if (x === null) break;
      if (same(x)) return found(mid);
      if (x < at.start) lo = mid + 1; else hi = mid - 1;
    }
    // not in time order after all: read them all
    const all = await Promise.all(t.list.map((_, i) => startAt(t, i)));
    const k = all.findIndex(same);
    return k >= 0 ? found(k) : null;
  }
  // Right before a change: the clip's object straight from its track's list, so only one read
  // (its effect list) lies between getting it and using it. Premiere can make objects stale at any
  // moment while it's busy (just after an edit or an undo, while it redraws), so the shorter that
  // gap, the better.
  async function current(seq, plan) {
    const at = plan.at;
    if (!at || at.k === undefined || clipType() === null) return plan.item;
    const track = at.video ? await seq.getVideoTrack(at.index) : await seq.getAudioTrack(at.index);
    const list = track ? ((await track.getTrackItems(clipType(), false)) || []) : [];
    return list.length === at.n && list[at.k] ? list[at.k] : plan.item;
  }
  const placed = new WeakMap(); // clip object -> where it sits (filled while finding the clips)
  async function clipsFor(seq, media, how) {
    if (how === 'selection' || clipType() === null) return selectedItems(seq, media);
    if (how === 'tracks') {
      const sel = await selectedItems(seq, media);
      const cache = new Map();
      const out = [];
      for (const it of sel) {
        const at = await placeOf(it);
        const hit = await clipAt(seq, at, cache);
        if (!hit) throw new Error('selected clip not found on its track');
        placed.set(hit, at);
        out.push(hit);
      }
      return out;
    }
    const kinds = media === 'audio' ? [false] : media === 'video' ? [true] : [true, false];
    const out = [];
    for (const video of kinds) {
      const n = Number(video ? await seq.getVideoTrackCount() : await seq.getAudioTrackCount()) || 0;
      for (let i = 0; i < n; i++) {
        const t = await trackClips(seq, video, i, null);
        const sel = await Promise.all(t.list.map((it) => it.getIsSelected().then((x) => !!x, () => false)));
        for (let j = 0; j < t.list.length; j++) {
          if (!sel[j]) continue;
          const start = await startAt(t, j);
          if (start !== null) placed.set(t.list[j], { video, index: i, start, k: j, n: t.list.length });
          out.push(t.list[j]);
        }
      }
    }
    return out;
  }
  // the ways to try, the one that worked last time first
  function order() { const first = HOW.includes(learned.handles) ? learned.handles : HOW[0]; return [first, ...HOW.filter((h) => h !== first)]; }

  function lockedRead(project, fn) {
    let out;
    project.lockedAccess(() => { out = fn(); });
    return out;
  }

  // ---------------------------------------------------------------- status
  async function status() {
    const out = { version, via: 'uxp', project: null, sequence: null, playhead: null, timecode: null, selection: { video: 0, audio: 0 } };
    const project = await ppro.Project.getActiveProject();
    if (!project) return out;
    out.project = project.name;
    try { out.projectPath = project.path ? String(project.path) : null; } catch (e) {}
    const seq = await project.getActiveSequence();
    if (!seq) return out;
    out.sequence = seq.name;
    const [pos, tb, items] = await Promise.all([seq.getPlayerPosition(), seq.getTimebase().catch(() => null), selectedItems(seq, 'any').catch(() => [])]);
    out.playhead = secOf(pos);
    const tpf = Number(tb);
    if (tpf > 0) {
      const fps = TPS / tpf;
      const f = Math.round(out.playhead * fps);
      const nf = Math.round(fps);
      const pad = (n) => String(n).padStart(2, '0');
      out.timecode = `${pad(Math.floor(f / (nf * 3600)))}:${pad(Math.floor(f / (nf * 60)) % 60)}:${pad(Math.floor(f / nf) % 60)}:${pad(f % nf)}`;
    }
    for (const it of items) { if (isVideoItem(it)) out.selection.video++; else out.selection.audio++; }
    return out;
  }

  async function listEffects() {
    const [v, a] = await Promise.all([
      ppro.VideoFilterFactory.getDisplayNames().catch(() => []),
      ppro.AudioFilterFactory.getDisplayNames().catch(() => []),
    ]);
    return { video: v || [], audio: a || [] };
  }

  // ---------------------------------------------------------------- preset helpers
  function closeTo(a, b) { return Math.abs(Number(a) - Number(b)) <= 1e-6 * Math.max(1, Math.abs(Number(b))); }

  // same matching as the classic extension: by name, then unnamed settings by their place
  function mapParams(params, presetParams, stats, compName) {
    const names = params.map((p) => lower(steady(() => p.displayName)));
    const used = params.map(() => false);
    const n = presetParams.length;
    const hitOf = [];
    for (let j = 0; j < n; j++) {
      const want = lower(presetParams[j].name);
      let hit = -1;
      if (want) {
        if (j < params.length && !used[j] && names[j] === want) hit = j;
        for (let k = 0; hit < 0 && k < params.length; k++) if (!used[k] && names[k] === want) hit = k;
      }
      if (hit >= 0) used[hit] = true;
      hitOf.push(hit);
    }
    for (let j = 0; j < n;) {
      if (hitOf[j] >= 0) { j++; continue; }
      let b = j;
      while (b < n && hitOf[b] < 0) b++;
      const lo = j > 0 ? hitOf[j - 1] : -1;
      const hi = b < n ? hitOf[b] : params.length;
      const free = [];
      for (let k = lo + 1; k < hi; k++) if (!used[k]) free.push(k);
      if (lo < hi && free.length === b - j) free.forEach((k, m) => { hitOf[j + m] = k; used[k] = true; });
      j = b;
    }
    const ls = [], lp = [];
    for (let j = 0; j < n; j++) if (hitOf[j] < 0 && !lower(presetParams[j].name)) ls.push(j);
    for (let k = 0; k < params.length; k++) if (!used[k] && !names[k]) lp.push(k);
    if (ls.length && ls.length === lp.length) ls.forEach((j, m) => { hitOf[j] = lp[m]; used[lp[m]] = true; });
    const pairs = [], missed = [];
    for (let j = 0; j < n; j++) {
      if (hitOf[j] >= 0) pairs.push([params[hitOf[j]], presetParams[j]]);
      else if (presetParams[j].kind !== 'arb') missed.push(j + ':' + (presetParams[j].name || '?'));
    }
    if (missed.length) (stats.unmapped = stats.unmapped || []).push(`${compName} [${missed.join(', ')}] params=${names.join('|')}`);
    return pairs;
  }

  function toValue(p, v) {
    if (p.kind === 'color') {
      if (!v) return null;
      return new ppro.Color(v.r / 255, v.g / 255, v.b / 255, (v.a === undefined ? 255 : v.a) / 255);
    }
    if (Array.isArray(v)) return new ppro.PointF(Number(v[0]), Number(v[1]));
    return v;
  }

  function interpMode(i) {
    const M = (C && C.InterpolationMode) || {};
    if (i === 4) return M.HOLD;
    if (i === 2 || i === 3 || i === 5) return M.BEZIER;
    return null; // linear is the default, nothing to set
  }

  function keyTimes(p, comp, info) {
    return p.keys.map((key) => {
      let off;
      if (comp.anchor === 1) off = key.t;
      else if (comp.anchor === 2) off = info.dur - (comp.anchorLen - key.t);
      else off = comp.anchorLen > 0 ? (key.t / comp.anchorLen) * info.dur : key.t;
      return info.base + off * info.speed;
    });
  }

  // the changes that put one preset setting on one property (each handed to `add` as a maker)
  function paramActions(param, p, comp, info, stats, add, { keysOnly, valuesOnly, same } = {}) {
    if (p.kind === 'arb') { stats.skipped++; return; }
    let varying = false;
    try { varying = !!steady(() => param.isTimeVarying()); } catch (e) { if (isStale(e)) throw e; }
    if (p.keys && p.keys.length) {
      if (valuesOnly) return;
      if (p.kind === 'color') { stats.skipped++; return; }
      const times = keyTimes(p, comp, info);
      if (varying) add(() => param.createSetTimeVaryingAction(false)); // clear old keys
      if (!keysOnly || varying) add(() => param.createSetTimeVaryingAction(true));
      p.keys.forEach((key, i) => {
        let kf;
        try {
          kf = steady(() => { const k = param.createKeyframe(toValue(p, key.v)); k.position = tick(times[i]); return k; });
        } catch (e) { soft(e, stats); return; }
        add(() => param.createAddKeyframeAction(kf));
        const mode = interpMode(key.i);
        if (mode !== null && mode !== undefined) add(() => param.createSetInterpolationAtKeyframeAction(tick(times[i]), mode));
        stats.keys++;
      });
      // Premiere drops a key of its own when keyframing is switched on. Removing it in the same step
      // isn't accepted, so when it lies outside the preset's keys give it the value the clip has
      // there anyway - then it changes nothing and the preset stays one Ctrl+Z.
      const n = neutralKey(p, comp, info);
      if (n) {
        try {
          const kf = steady(() => { const k = param.createKeyframe(toValue(p, n.v)); k.position = tick(n.t); return k; });
          add(() => param.createAddKeyframeAction(kf));
        } catch (e) { if (isStale(e)) throw e; }
      }
      return;
    }
    if (keysOnly) return;
    if (p.value === null || p.value === undefined) return;
    if (same && same.has(p)) { stats.same = (stats.same || 0) + 1; return; } // already that value
    let kf;
    try { kf = steady(() => param.createKeyframe(toValue(p, p.value))); } catch (e) { soft(e, stats); return; }
    if (varying) add(() => param.createSetTimeVaryingAction(false));
    add(() => param.createSetValueAction(kf, true));
    stats.values++;
  }

  async function clipInfo(item, timeBase, playhead) {
    const [start, end, inPt, speed] = await Promise.all([item.getStartTime(), item.getEndTime(), item.getInPoint(), item.getSpeed().catch(() => 1)]);
    const s = secOf(start), e = secOf(end);
    const sp = Number(speed) > 0 ? Number(speed) : 1;
    const info = { start: s, dur: e - s, base: timeBase === 'sequence' ? s : secOf(inPt), speed: timeBase === 'sequence' ? 1 : sp, inPoint: secOf(inPt), realSpeed: sp };
    info.playhead = playhead;
    // the playhead in this clip's keyframe time (where Premiere drops its own key)
    info.cti = playhead === null ? null : info.base + (playhead - s) * info.speed;
    return info;
  }

  // Places where Premiere might drop its own key when keyframing is switched on. Which one this
  // Premiere uses is learned from the first preset (stats.strayRule) and remembered.
  const STRAY_RULES = ['cti', 'ctiClamped', 'mediaPlayhead', 'mediaPlayheadClamped', 'rel', 'relClamped', 'seq', 'inPoint', 'zero', 'clipStart'];
  function strayCandidates(info) {
    const clamp = (t, a, b) => Math.min(Math.max(t, a), b);
    const c = { inPoint: info.inPoint, zero: 0, clipStart: info.start };
    if (info.playhead !== null && info.playhead !== undefined) {
      const rel = info.playhead - info.start;
      c.cti = info.cti;
      c.ctiClamped = clamp(info.cti, info.base, info.base + info.dur * info.speed);
      c.mediaPlayhead = info.inPoint + rel * info.realSpeed;
      c.mediaPlayheadClamped = clamp(c.mediaPlayhead, info.inPoint, info.inPoint + info.dur * info.realSpeed);
      c.rel = rel;
      c.relClamped = clamp(rel, 0, info.dur);
      c.seq = info.playhead;
    }
    return c;
  }
  // where Premiere's own key will land and the value that makes it harmless (null if it can't be)
  function neutralKey(p, comp, info) {
    const st = strayTime(info);
    if (st === null || !p.keys || !p.keys.length) return null;
    const times = keyTimes(p, comp, info);
    if (times.some((t) => Math.abs(t - st) < 0.001)) return null;
    let iMin = 0, iMax = 0;
    times.forEach((t, i) => { if (t < times[iMin]) iMin = i; if (t > times[iMax]) iMax = i; });
    if (st < times[iMin]) return { t: st, v: p.keys[iMin].v };
    if (st > times[iMax]) return { t: st, v: p.keys[iMax].v };
    // between two keys: the value the animation has there anyway - exact on a straight line or a hold
    // (an eased stretch can't be matched exactly, so then it's removed in a second step instead)
    const M = (C && C.InterpolationMode) || {};
    const seq = times.map((t, i) => i).sort((a, b) => times[a] - times[b]);
    for (let j = 0; j + 1 < seq.length; j++) {
      const a = seq[j], b = seq[j + 1];
      if (!(st > times[a] && st < times[b])) continue;
      const ma = interpMode(p.keys[a].i), mb = interpMode(p.keys[b].i);
      const linear = (m) => m === null || m === undefined;
      if (!linear(ma) && ma === M.HOLD) return { t: st, v: p.keys[a].v };
      if (linear(ma) && (linear(mb) || mb === M.HOLD)) {
        const v = lerp(p.keys[a].v, p.keys[b].v, (st - times[a]) / (times[b] - times[a]));
        return v === null ? null : { t: st, v };
      }
      return null;
    }
    return null;
  }
  function lerp(x, y, f) {
    if (typeof x === 'number' && typeof y === 'number') return x + (y - x) * f;
    if (Array.isArray(x) && Array.isArray(y) && x.length === y.length) return x.map((xi, i) => Number(xi) + (Number(y[i]) - Number(xi)) * f);
    return null;
  }
  function strayTime(info) {
    const rule = learned.strayRule || (learned.autoKey === true ? 'cti' : null);
    if (!rule) return null;
    const t = strayCandidates(info)[rule];
    return typeof t === 'number' && isFinite(t) ? t : null;
  }

  async function chainComponents(chain) {
    const count = steady(() => chain.getComponentCount());
    const comps = [];
    for (let i = 0; i < count; i++) comps.push(steady(() => chain.getComponentAtIndex(i)));
    const names = await Promise.all(comps.map((c) => Promise.all([c.getMatchName().catch(() => ''), c.getDisplayName().catch(() => '')])));
    return comps.map((c, i) => ({ comp: c, matchName: names[i][0], displayName: names[i][1] }));
  }

  // An effect's settings. A just-created effect that isn't on a clip yet may not offer them at all
  // (Premiere's audio effects don't) - then returns null and they're set once it's on the clip.
  function paramsOf(component) {
    if (!component) return null;
    if (typeof component.getParamCount === 'function' && typeof component.getParam === 'function') {
      const out = [];
      const n = steady(() => component.getParamCount());
      for (let i = 0; i < n; i++) out.push(steady(() => component.getParam(i)));
      return out;
    }
    if (typeof component.getParam === 'function') {
      const out = [];
      for (let i = 0; i < 200; i++) {
        let prm = null;
        try { prm = steady(() => component.getParam(i)); } catch (e) { if (isStale(e)) throw e; break; }
        if (!prm) break;
        out.push(prm);
      }
      return out.length ? out : null;
    }
    return null;
  }
  function describeObject(o) {
    try { return Object.getOwnPropertyNames(Object.getPrototypeOf(o) || {}).filter((k) => k !== 'constructor').slice(0, 30).join(','); } catch (e) { return '?'; }
  }

  // Did the settings land on the component that's now in the clip? (Checks one set value or key.)
  async function landed(component, pairs) {
    for (const [param, p] of pairs) {
      try {
        if (p.keys && p.keys.length) return (param.getKeyframeListAsTickTimes() || []).length >= p.keys.length;
        if (p.kind === 'bool' || p.kind === 'float' || p.kind === 'int') {
          const kf = await param.getStartValue();
          const v = kf && kf.value !== undefined ? (kf.value.value !== undefined ? kf.value.value : kf.value) : kf;
          if (typeof p.value === 'boolean') return !!v === p.value;
          if (typeof p.value === 'number') return closeTo(v, p.value);
        }
      } catch (e) { return null; }
    }
    return null; // nothing checkable
  }

  // ---------------------------------------------------------------- applyPreset
  // Tries the ways of finding the clips in turn, straight away (no waiting): a stale object fails in
  // a millisecond, and the next way usually works. Never touches the classic route: anything Premiere
  // doesn't record as one History step would make Ctrl+Z undo the user's own earlier edits instead.
  // Tries again straight away, then with short pauses: Premiere refuses changes in bursts while it's
  // busy (just after an edit or an undo). A refused try costs a few milliseconds and changes nothing.
  // tries with fresh objects; the later ones wait longer so a longer busy spell in Premiere is ridden out
  const PAUSES = [0, 0, 40, 80, 150, 250, 400, 600, 800];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function tries() {
    const [a, b] = order();
    return PAUSES.map((ms, i) => ({ ms, how: i === PAUSES.length - 1 ? 'selection' : i % 2 ? b : a }));
  }
  const why = (how, e) => {
    const where = (e && e.stack ? String(e.stack).split('\n').slice(1, 3).map((l) => l.trim().replace(/^at /, '').replace(/\(.*[\\/]/, '(')).join(' < ') : '');
    return how + '/' + ((e && e.phase) || 'read') + ': ' + String((e && e.message) || e).slice(0, 100) + (where ? ' @ ' + where.slice(0, 120) : '');
  };

  async function applyPreset(args) {
    const t0 = now();
    const tried = [];
    for (const { ms, how } of tries()) {
      if (ms) await sleep(ms);
      const seen = {};
      try {
        const r = await applyPresetOnce(args, how, seen);
        if (tried.length) { r.stats.attempts = tried.length + 1; r.stats.tried = tried; }
        r.stats.handles = how;
        if (learned.handles !== how && how !== 'selection') { learned.handles = how; remember(); }
        r.stats.learned = Object.assign({}, learned);
        r.stats.ms.total = now() - t0;
        return r;
      } catch (e) {
        if (!premiereError(e)) throw e;
        tried.push(why(how, e));
        log('preset via', how, 'failed:', e && e.message);
        if (e.started) {
          // Premiere had begun taking the change. Only go on when it provably kept nothing:
          // a second try would otherwise add the preset's effects twice.
          if (await changed(seen.plans)) throw fail('PARTIAL', 'Premiere only took part of the preset. Press Ctrl+Z once and try again.');
        }
      }
    }
    log('preset refused every way', tried.join(' | '));
    throw Object.assign(fail('PREMIERE_REFUSED', 'Premiere didn’t take the preset, so nothing changed. Try again – if it keeps happening, restart Premiere.'), { detail: tried.join(' | ') + ' (' + (now() - t0) + 'ms)' });
  }

  // true when any clip's list of effects is different from before (or can't be read)
  async function changed(plans) {
    if (!plans || !plans.length) return false;
    if (!plans.some((p) => p.parts.some((x) => x.fresh))) return false; // settings only: trying again is harmless
    try {
      const { seq } = await context();
      const cache = new Map();
      for (const plan of plans) {
        const item = (await clipAt(seq, plan.at, cache)) || plan.item;
        const chain = await item.getComponentChain();
        if (steady(() => chain.getComponentCount()) !== plan.count) return true;
      }
      return false;
    } catch (e) { return true; }
  }

  async function applyPresetOnce(args, how, seen) {
    const t0 = now();
    lastOk = t0;
    const preset = args.preset;
    const { project, seq } = await context();
    const media = preset.media === 'mixed' ? 'any' : preset.media;
    const items = await clipsFor(seq, media, how);
    if (!items.length) throw fail('NO_SELECTION', 'Select ' + (media === 'audio' ? 'audio ' : media === 'video' ? 'video ' : '') + 'clips in the timeline first.');
    const stats = { keys: 0, values: 0, skipped: 0, failed: 0, missing: [], partial: false, steps: 0, ms: {} };
    let playhead = null;
    try { playhead = secOf(await seq.getPlayerPosition()); } catch (e) {}

    // 1. reads: clip timing, existing components, new effect components
    const plans = [];
    seen.plans = plans;
    for (const item of items) {
      const video = isVideoItem(item);
      const m = video ? 'video' : 'audio';
      const comps = preset.components.filter((c) => c.media === m);
      if (!comps.length) continue;
      const [info, chain, at] = await Promise.all([clipInfo(item, args.timeBase, playhead), item.getComponentChain(), placed.get(item) || placeOf(item).catch(() => null)]);
      const existing = await chainComponents(chain);
      const plan = { item, info, chain, at, count: existing.length, parts: [] };
      for (const c of comps) {
        if (c.intrinsic) {
          let k = existing.findIndex((e) => e.matchName === c.matchName);
          if (k < 0) k = existing.findIndex((e) => lower(e.displayName) === lower(c.displayName));
          if (k < 0) { stats.missing.push(c.displayName); continue; }
          plan.parts.push({ c, component: existing[k].comp, matchName: existing[k].matchName, index: k, fresh: false });
        } else {
          let component = null;
          try {
            component = video
              ? await ppro.VideoFilterFactory.createComponent(c.matchName)
              : await ppro.AudioFilterFactory.createComponentByDisplayName(c.displayName, item);
          } catch (e) { component = null; }
          if (!component && video) {
            try { component = await ppro.VideoFilterFactory.createComponent(c.displayName); } catch (e) {}
          }
          if (!component) { stats.missing.push(c.displayName); continue; }
          plan.parts.push({ c, component, fresh: true });
          if (c.hasPrivateData) stats.partial = true;
        }
      }
      if (plan.parts.length) plans.push(plan);
    }
    if (!plans.length) throw fail('PRESET_FAILED', stats.missing.length ? 'Missing effect: ' + stats.missing[0] : 'Nothing in this preset fits those clips.');
    // settings a clip already has don't need changing: fewer change requests for Premiere to refuse
    await markSame(plans);
    // the clips and their effect lists once more, as late as possible (see current())
    await Promise.all(plans.map(async (plan) => {
      plan.item = await current(seq, plan);
      plan.chain = await plan.item.getComponentChain();
    }));
    stats.ms.read = now() - t0;

    // 2. one transaction: add the effects, set every setting, place every keyframe
    const t1 = now();
    const label = 'FX Drop: ' + (preset.name || 'preset');
    // settings go in this same step whenever Premiere allows it; the rest follow in a second step
    const keysOk = learned.oneStepKeys !== false;
    const oneStep = keysOk && learned.appendThenSet !== false;
    const buildMain = (add, st) => {
      for (const plan of plans) {
        // the clip's effects, fetched right here inside the lock
        if (steady(() => plan.chain.getComponentCount()) !== plan.count) throw new Error('The clip changed while FX Drop was reading it.');
        for (const part of plan.parts) {
          if (part.fresh) add(() => plan.chain.createAppendComponentAction(part.component));
          else part.component = steady(() => plan.chain.getComponentAtIndex(part.index));
          const params = paramsOf(part.component);
          if (!params && part.fresh && !st.freeComponent) st.freeComponent = describeObject(part.component);
          part.pairs = params ? mapParams(params, part.c.params, st, part.c.displayName) : null;
          part.deferred = !params || !(part.fresh ? oneStep : keysOk);
          if (!part.deferred) for (const [param, p] of part.pairs) paramActions(param, p, part.c, plan.info, st, add, { same: part.same });
        }
      }
    };
    const ok = commit(project, label, buildMain, stats);
    stats.steps = 1;
    if (!ok) throw Object.assign(new Error('Premiere refused the change.'), { code: 'ERROR', started: true });
    // the preset is in. Everything below only tidies up, and never turns this into a failure.
    try {
      await finishPreset(project, label, plans, stats);
    } catch (e) {
      stats.tidyError = (e && e.message) || String(e);
      log('tidy-up after preset failed', stats.tidyError);
    }
    remember();
    stats.ms.write = now() - t1;
    return { applied: plans.length, total: items.length, stats };
  }

  function sameValue(cur, want) {
    if (cur && typeof cur === 'object' && cur.value !== undefined && !(Array.isArray(want) && cur.x !== undefined)) cur = cur.value;
    if (typeof want === 'boolean') return typeof cur === 'boolean' ? cur === want : (typeof cur === 'number' ? !!cur === want : false);
    if (typeof want === 'number') return typeof cur === 'number' && closeTo(cur, want);
    if (Array.isArray(want) && want.length === 2 && cur && typeof cur === 'object') {
      const x = cur.x !== undefined ? cur.x : cur[0], y = cur.y !== undefined ? cur.y : cur[1];
      return typeof x === 'number' && typeof y === 'number' && Math.abs(x - want[0]) < 1e-5 && Math.abs(y - want[1]) < 1e-5;
    }
    return false;
  }
  async function markSame(plans) {
    let changes = 0, sameN = 0;
    for (const plan of plans) {
      for (const part of plan.parts) {
        if (part.fresh) { changes++; continue; }
        part.same = new Set();
        try {
          const pairs = mapParams(paramsOf(part.component) || [], part.c.params, {}, part.c.displayName);
          await Promise.all(pairs.map(async ([param, p]) => {
            if (p.keys && p.keys.length) { changes++; return; }
            if (p.kind === 'arb' || p.value === null || p.value === undefined) return;
            let varying = true;
            try { varying = !!steady(() => param.isTimeVarying()); } catch (e) { varying = true; }
            if (!varying) {
              const kf = await param.getStartValue().catch(() => null);
              if (kf && sameValue(kf.value !== undefined ? kf.value : kf, p.value)) { part.same.add(p); sameN++; return; }
            }
            changes++;
          }));
        } catch (e) { part.same = new Set(); }
      }
    }
    // nothing would change at all: still make the (harmless) step, so one Ctrl+Z after it never
    // reaches back to an earlier edit of the user's
    if (!changes && sameN) for (const plan of plans) for (const part of plan.parts) if (part.same) part.same.clear();
  }

  // After a change Premiere's objects for those clips are stale: look the clips up again and find
  // each part's effect on them (a just-added effect is one of the last in the clip's list).
  async function refresh(plans) {
    const { seq } = await context();
    const cache = new Map();
    for (const plan of plans) {
      let item = null;
      try { item = await clipAt(seq, plan.at, cache); } catch (e) { item = null; }
      plan.item = item || plan.item;
      plan.chain = await plan.item.getComponentChain();
      const now2 = await chainComponents(plan.chain);
      const fresh = plan.parts.filter((p) => p.fresh);
      const grew = now2.length === plan.count + fresh.length;
      const tail = grew ? now2.slice(now2.length - fresh.length) : [];
      fresh.forEach((p, i) => { p.target = tail[i] ? tail[i].comp : null; });
      for (const p of plan.parts) {
        if (p.fresh) continue;
        const hit = (now2[p.index] && now2[p.index].matchName === p.matchName) ? now2[p.index] : now2.find((e) => e.matchName === p.matchName);
        p.target = hit ? hit.comp : null;
      }
    }
  }
  const pairsOf = (part) => mapParams(paramsOf(part.target) || [], part.c.params, {}, part.c.displayName);

  async function finishPreset(project, label, plans, stats) {
    // 3. check it landed on the clips; if this Premiere build needs it, finish in a second step
    await refresh(plans);
    const fixups = [];
    for (const plan of plans) {
      for (const part of plan.parts) {
        if (!part.target) continue;
        const good = part.deferred ? false : await landed(part.target, pairsOf(part));
        if (good === false) {
          fixups.push({ plan, part });
          // settings put on a just-created effect didn't stay with it: next time set them afterwards
          if (!part.deferred && part.fresh) { learned.appendThenSet = false; remember(); }
        } else if (good === true && part.fresh && !part.deferred) {
          learned.appendThenSet = true; remember();
          if (part.pairs && part.pairs.some(([, p]) => p.keys && p.keys.length)) learned.oneStepKeys = true;
        }
      }
    }
    if (fixups.length) {
      log('preset needed a second step on this Premiere build', fixups.length);
      const stats2 = emptyStats();
      commit(project, label, (add, st) => {
        for (const f of fixups) for (const [param, p] of pairsOf(f.part)) paramActions(param, p, f.part.c, f.plan.info, st, add);
      }, stats2);
      stats.steps = 2;
      for (const k of ['keys', 'values', 'skipped', 'failed']) stats[k] += stats2[k];
      // keyframes that still didn't land: switch keyframing on first, then add keys
      await refresh(plans);
      const missingKeys = () => {
        const out = [];
        for (const f of fixups) {
          if (!f.part.target) continue;
          for (const pair of pairsOf(f.part)) if (pair[1].keys && pair[1].keys.length && (pair[0].getKeyframeListAsTickTimes() || []).length < pair[1].keys.length) out.push({ f, pair });
        }
        return out;
      };
      if (missingKeys().length) {
        learned.oneStepKeys = false;
        commit(project, label, (add) => { for (const s of missingKeys()) add(() => s.pair[0].createSetTimeVaryingAction(true)); });
        await refresh(plans);
        commit(project, label, (add, st) => {
          for (const s of missingKeys()) paramActions(s.pair[0], s.pair[1], s.f.part.c, s.f.plan.info, st, add, { keysOnly: true });
        });
        stats.steps = 4;
      }
      await refresh(plans);
    }
    // 4. keys Premiere added on its own (at the playhead) - remove, and learn to do it in step one
    const strays = [];
    for (const plan of plans) {
      for (const part of plan.parts) {
        if (!part.target) continue;
        for (const [param, p] of pairsOf(part)) {
          if (!p.keys || !p.keys.length) continue;
          const want = keyTimes(p, part.c, plan.info);
          const n = neutralKey(p, part.c, plan.info);
          if (n) want.push(n.t);
          let have = [];
          try { have = (param.getKeyframeListAsTickTimes() || []).map(secOf); } catch (e) { continue; }
          for (const t of have) {
            if (want.some((w) => Math.abs(w - t) < 0.001)) continue;
            // our own key, nudged onto a frame by Premiere - not a stray
            const near = want.find((w) => Math.abs(w - t) < 0.042);
            if (near !== undefined && !have.some((h) => Math.abs(h - near) < 0.001)) continue;
            const cand = strayCandidates(plan.info);
            strays.push({ param, t, rules: STRAY_RULES.filter((r) => typeof cand[r] === 'number' && Math.abs(cand[r] - t) < 0.002), info: plan.info });
          }
        }
      }
    }
    if (strays.length) {
      // learn where Premiere puts its own key, so next time it's removed in the same step
      const rule = STRAY_RULES.find((r) => strays.every((x) => x.rules.includes(r)));
      if (rule && learned.autoKey !== false) { learned.strayRule = rule; learned.autoKey = true; }
      commit(project, label, (add) => { for (const x of strays) add(() => x.param.createRemoveKeyframeAction(tick(x.t))); });
      stats.steps++;
      stats.strayKeys = strays.length;
      const i0 = strays[0].info;
      stats.strayAt = { t: +strays[0].t.toFixed(4), rule: rule || null, playhead: i0.playhead, start: i0.start, inPoint: i0.inPoint, base: i0.base, speed: i0.realSpeed };
    }
  }

  // ---------------------------------------------------------------- applyEffect (one effect by name)
  let effectNames = null;
  async function matchNameFor(displayName) {
    if (!effectNames) {
      const [d, m] = await Promise.all([ppro.VideoFilterFactory.getDisplayNames(), ppro.VideoFilterFactory.getMatchNames()]);
      effectNames = { d: d || [], m: m || [] };
    }
    const want = lower(displayName);
    if (effectNames.d.length === effectNames.m.length) {
      const i = effectNames.d.findIndex((x) => lower(x) === want);
      if (i >= 0) return effectNames.m[i];
    }
    return null;
  }

  async function applyEffect(args) {
    let last = null;
    for (const { ms, how } of tries()) {
      if (ms) await sleep(ms);
      const seen = {};
      try {
        const r = await applyEffectOnce(args, how, seen);
        if (learned.handles !== how) { learned.handles = how; remember(); }
        return r;
      } catch (e) {
        if (!premiereError(e)) throw e;
        last = e;
        log('effect via', how, 'failed:', e && e.message);
        if (e.started && await changed(seen.plans)) return { applied: seen.plans.length, total: seen.plans.length }; // it's on: never add it twice
      }
    }
    throw fail('PREMIERE_REFUSED', 'Premiere didn’t take the effect, so nothing changed. Try again – if it keeps happening, restart Premiere.' + (last && last.message ? '' : ''));
  }

  async function applyEffectOnce(args, how, seen) {
    lastOk = now();
    const { project, seq } = await context();
    const items = await clipsFor(seq, args.media, how);
    if (!items.length) throw fail('NO_SELECTION', 'Select ' + (args.media === 'audio' ? 'audio' : 'video') + ' clips in the timeline first.');
    const plans = [];
    seen.plans = plans;
    for (const item of items) {
      let comp = null;
      try {
        if (args.media === 'audio') comp = await ppro.AudioFilterFactory.createComponentByDisplayName(args.name, item);
        else {
          if (args.matchName) { try { comp = await ppro.VideoFilterFactory.createComponent(args.matchName); } catch (e) { comp = null; } }
          const mn = comp ? null : await matchNameFor(args.name).catch(() => null);
          if (mn) {
            comp = await ppro.VideoFilterFactory.createComponent(mn);
            // make sure the name lookup really gave the effect that was asked for
            const dn = comp && typeof comp.getDisplayName === 'function' ? await comp.getDisplayName().catch(() => null) : null;
            if (dn && lower(dn) !== lower(args.name)) comp = null;
          }
        }
      } catch (e) { comp = null; }
      if (!comp) throw fail('USE_CLASSIC', 'Effect lookup not available in the plugin');
      const [chain, at] = await Promise.all([item.getComponentChain(), placed.get(item) || placeOf(item).catch(() => null)]);
      plans.push({ item, chain, at, count: steady(() => chain.getComponentCount()), comp, parts: [{ fresh: true }] });
    }
    await Promise.all(plans.map(async (plan) => {
      plan.item = await current(seq, plan);
      plan.chain = await plan.item.getComponentChain();
    }));
    const ok = commit(project, 'FX Drop: ' + args.name, (add) => { for (const a of plans) add(() => a.chain.createAppendComponentAction(a.comp)); });
    if (!ok) throw Object.assign(new Error('Premiere refused the change.'), { code: 'ERROR', started: true });
    return { applied: plans.length, total: items.length };
  }

  return { status, listEffects, applyPreset, applyEffect, _learned: learned, _mapParams: mapParams };
}

module.exports = { createOps, TPS };
