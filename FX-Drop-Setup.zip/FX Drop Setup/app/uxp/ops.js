// FX Drop commands for Premiere's UXP plugin system.
// Everything one click does is collected and committed as ONE transaction, so it is a single
// step in Premiere's History panel ("FX Drop: <preset>") and Ctrl+Z removes all of it at once.
// Reads (which are async) happen first; then one synchronous locked block builds and commits.
'use strict';

const TPS = 254016000000;
const INTRINSIC = /^(AE\.ADBE (Motion|Opacity)|AE\.ADBE Time Remapping|audioVolume|audioChannelVolume|audioPanner)$/i;

function createOps(ppro, opts) {
  const log = (opts && opts.log) || (() => {});
  const version = (opts && opts.version) || '0';
  const C = ppro.Constants;
  // Learned on this Premiere build and remembered between sessions:
  //  appendThenSet - settings on a just-added effect can go in the same step as adding it
  //  oneStepKeys   - keyframing can be switched on and keys added in the same step
  //  autoKey       - switching keyframing on drops an extra key at the playhead (we remove it)
  //  strayRule     - where exactly that extra key lands (see strayTimes), so its removal goes
  //                  in the same step as the preset and one Ctrl+Z undoes everything
  const store = (opts && opts.storage) || null;
  const learned = (() => {
    const base = { oneStepKeys: null, appendThenSet: null, autoKey: null, strayRule: null };
    try { return Object.assign(base, JSON.parse((store && store.getItem('fxdrop.learned')) || '{}')); } catch (e) { return base; }
  })();
  function remember() { try { if (store) store.setItem('fxdrop.learned', JSON.stringify(learned)); } catch (e) {} }

  function fail(code, message) { return Object.assign(new Error(message), { code }); }
  function tick(sec) { return ppro.TickTime.createWithTicks(String(Math.round(sec * TPS))); }
  function secOf(t) {
    if (!t) return 0;
    if (typeof t.ticksNumber === 'number') return t.ticksNumber / TPS;
    if (t.ticks !== undefined) return Number(t.ticks) / TPS;
    return Number(t.seconds) || 0;
  }
  const lower = (s) => String(s || '').trim().toLowerCase();
  const now = () => Date.now();

  function isVideoItem(it) {
    if (ppro.VideoClipTrackItem && it instanceof ppro.VideoClipTrackItem) return true;
    if (ppro.AudioClipTrackItem && it instanceof ppro.AudioClipTrackItem) return false;
    return /video/i.test((it && it.constructor && it.constructor.name) || '');
  }

  async function context() {
    const project = await ppro.Project.getActiveProject();
    if (!project) throw fail('NO_PROJECT', 'Open a project in Premiere first.');
    const seq = await project.getActiveSequence();
    if (!seq) throw fail('NO_SEQUENCE', 'Open a sequence in the timeline first.');
    return { project, seq };
  }

  async function selectedItems(seq, media) {
    const sel = await seq.getSelection();
    const items = sel ? await sel.getTrackItems() : [];
    return (items || []).filter((it) => media === 'any' || (media === 'video') === isVideoItem(it));
  }

  // Runs `build(add)` inside one locked, undoable transaction. Returns true if committed.
  // Premiere 26 wants every change created inside both lockedAccess and the transaction itself
  // (creating them earlier gives "The script object is no longer valid").
  function commit(project, label, build) {
    let ok = false;
    let err = null;
    project.lockedAccess(() => {
      try {
        ok = project.executeTransaction((ca) => {
          try { build((a) => { if (a) ca.addAction(a); }); } catch (e) { err = e; throw e; }
        }, label);
      } catch (e) { err = err || e; }
    });
    if (err) throw err;
    return ok !== false;
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // Premiere's own errors (not FX Drop's friendly ones) are worth one more try with fresh objects
  const premiereError = (e) => !e || !e.code || e.code === 'ERROR';

  function lockedRead(project, fn) {
    let out;
    project.lockedAccess(() => { out = fn(); });
    return out;
  }

  // ---------------------------------------------------------------- status
  async function status() {
    const out = { version, via: 'uxp', project: null, sequence: null, playhead: null, timecode: null, selection: { video: 0, audio: 0 } };
    const project = await ppro.Project.getActiveProject();
    if (!project) return out;
    out.project = project.name;
    const seq = await project.getActiveSequence();
    if (!seq) return out;
    out.sequence = seq.name;
    const [pos, tb, items] = await Promise.all([seq.getPlayerPosition(), seq.getTimebase().catch(() => null), selectedItems(seq, 'any').catch(() => [])]);
    out.playhead = secOf(pos);
    const tpf = Number(tb);
    if (tpf > 0) {
      const fps = TPS / tpf;
      const f = Math.round(out.playhead * fps);
      const nf = Math.round(fps);
      const pad = (n) => String(n).padStart(2, '0');
      out.timecode = `${pad(Math.floor(f / (nf * 3600)))}:${pad(Math.floor(f / (nf * 60)) % 60)}:${pad(Math.floor(f / nf) % 60)}:${pad(f % nf)}`;
    }
    for (const it of items) { if (isVideoItem(it)) out.selection.video++; else out.selection.audio++; }
    return out;
  }

  async function listEffects() {
    const [v, a] = await Promise.all([
      ppro.VideoFilterFactory.getDisplayNames().catch(() => []),
      ppro.AudioFilterFactory.getDisplayNames().catch(() => []),
    ]);
    return { video: v || [], audio: a || [] };
  }

  // ---------------------------------------------------------------- preset helpers
  function closeTo(a, b) { return Math.abs(Number(a) - Number(b)) <= 1e-6 * Math.max(1, Math.abs(Number(b))); }

  // same matching as the classic extension: by name, then unnamed settings by their place
  function mapParams(params, presetParams, stats, compName) {
    const names = params.map((p) => lower(p.displayName));
    const used = params.map(() => false);
    const n = presetParams.length;
    const hitOf = [];
    for (let j = 0; j < n; j++) {
      const want = lower(presetParams[j].name);
      let hit = -1;
      if (want) {
        if (j < params.length && !used[j] && names[j] === want) hit = j;
        for (let k = 0; hit < 0 && k < params.length; k++) if (!used[k] && names[k] === want) hit = k;
      }
      if (hit >= 0) used[hit] = true;
      hitOf.push(hit);
    }
    for (let j = 0; j < n;) {
      if (hitOf[j] >= 0) { j++; continue; }
      let b = j;
      while (b < n && hitOf[b] < 0) b++;
      const lo = j > 0 ? hitOf[j - 1] : -1;
      const hi = b < n ? hitOf[b] : params.length;
      const free = [];
      for (let k = lo + 1; k < hi; k++) if (!used[k]) free.push(k);
      if (lo < hi && free.length === b - j) free.forEach((k, m) => { hitOf[j + m] = k; used[k] = true; });
      j = b;
    }
    const ls = [], lp = [];
    for (let j = 0; j < n; j++) if (hitOf[j] < 0 && !lower(presetParams[j].name)) ls.push(j);
    for (let k = 0; k < params.length; k++) if (!used[k] && !names[k]) lp.push(k);
    if (ls.length && ls.length === lp.length) ls.forEach((j, m) => { hitOf[j] = lp[m]; used[lp[m]] = true; });
    const pairs = [], missed = [];
    for (let j = 0; j < n; j++) {
      if (hitOf[j] >= 0) pairs.push([params[hitOf[j]], presetParams[j]]);
      else if (presetParams[j].kind !== 'arb') missed.push(j + ':' + (presetParams[j].name || '?'));
    }
    if (missed.length) (stats.unmapped = stats.unmapped || []).push(`${compName} [${missed.join(', ')}] params=${names.join('|')}`);
    return pairs;
  }

  function toValue(p, v) {
    if (p.kind === 'color') {
      if (!v) return null;
      return new ppro.Color(v.r / 255, v.g / 255, v.b / 255, (v.a === undefined ? 255 : v.a) / 255);
    }
    if (Array.isArray(v)) return new ppro.PointF(Number(v[0]), Number(v[1]));
    return v;
  }

  function interpMode(i) {
    const M = (C && C.InterpolationMode) || {};
    if (i === 4) return M.HOLD;
    if (i === 2 || i === 3 || i === 5) return M.BEZIER;
    return null; // linear is the default, nothing to set
  }

  function keyTimes(p, comp, info) {
    return p.keys.map((key) => {
      let off;
      if (comp.anchor === 1) off = key.t;
      else if (comp.anchor === 2) off = info.dur - (comp.anchorLen - key.t);
      else off = comp.anchorLen > 0 ? (key.t / comp.anchorLen) * info.dur : key.t;
      return info.base + off * info.speed;
    });
  }

  // actions that put one preset setting on one property
  function paramActions(param, p, comp, info, stats, add, { keysOnly, valuesOnly } = {}) {
    if (p.kind === 'arb') { stats.skipped++; return; }
    if (p.keys && p.keys.length) {
      if (valuesOnly) return;
      if (p.kind === 'color') { stats.skipped++; return; }
      const times = keyTimes(p, comp, info);
      let varying = false;
      try { varying = !!param.isTimeVarying(); } catch (e) {}
      if (varying) add(param.createSetTimeVaryingAction(false)); // clear old keys
      if (!keysOnly || varying) add(param.createSetTimeVaryingAction(true));
      p.keys.forEach((key, i) => {
        try {
          const kf = param.createKeyframe(toValue(p, key.v));
          kf.position = tick(times[i]);
          add(param.createAddKeyframeAction(kf));
          const mode = interpMode(key.i);
          if (mode !== null && mode !== undefined) add(param.createSetInterpolationAtKeyframeAction(tick(times[i]), mode));
          stats.keys++;
        } catch (e) { stats.failed++; }
      });
      // Premiere drops a key of its own when keyframing is switched on. Removing it in the same step
      // isn't accepted, so when it lies outside the preset's keys give it the value the clip has
      // there anyway - then it changes nothing and the preset stays one Ctrl+Z.
      const n = neutralKey(p, comp, info);
      if (n) {
        try {
          const kf = param.createKeyframe(toValue(p, n.v));
          kf.position = tick(n.t);
          add(param.createAddKeyframeAction(kf));
        } catch (e) {}
      }
      return;
    }
    if (keysOnly) return;
    if (p.value === null || p.value === undefined) return;
    try {
      let varying = false;
      try { varying = !!param.isTimeVarying(); } catch (e) {}
      if (varying) add(param.createSetTimeVaryingAction(false));
      add(param.createSetValueAction(param.createKeyframe(toValue(p, p.value)), true));
      stats.values++;
    } catch (e) { stats.failed++; }
  }

  async function clipInfo(item, timeBase, playhead) {
    const [start, end, inPt, speed] = await Promise.all([item.getStartTime(), item.getEndTime(), item.getInPoint(), item.getSpeed().catch(() => 1)]);
    const s = secOf(start), e = secOf(end);
    const sp = Number(speed) > 0 ? Number(speed) : 1;
    const info = { start: s, dur: e - s, base: timeBase === 'sequence' ? s : secOf(inPt), speed: timeBase === 'sequence' ? 1 : sp, inPoint: secOf(inPt), realSpeed: sp };
    info.playhead = playhead;
    // the playhead in this clip's keyframe time (where Premiere drops its own key)
    info.cti = playhead === null ? null : info.base + (playhead - s) * info.speed;
    return info;
  }

  // Places where Premiere might drop its own key when keyframing is switched on. Which one this
  // Premiere uses is learned from the first preset (stats.strayRule) and remembered.
  const STRAY_RULES = ['cti', 'ctiClamped', 'mediaPlayhead', 'mediaPlayheadClamped', 'rel', 'relClamped', 'seq', 'inPoint', 'zero', 'clipStart'];
  function strayCandidates(info) {
    const clamp = (t, a, b) => Math.min(Math.max(t, a), b);
    const c = { inPoint: info.inPoint, zero: 0, clipStart: info.start };
    if (info.playhead !== null && info.playhead !== undefined) {
      const rel = info.playhead - info.start;
      c.cti = info.cti;
      c.ctiClamped = clamp(info.cti, info.base, info.base + info.dur * info.speed);
      c.mediaPlayhead = info.inPoint + rel * info.realSpeed;
      c.mediaPlayheadClamped = clamp(c.mediaPlayhead, info.inPoint, info.inPoint + info.dur * info.realSpeed);
      c.rel = rel;
      c.relClamped = clamp(rel, 0, info.dur);
      c.seq = info.playhead;
    }
    return c;
  }
  // where Premiere's own key will land and the value that makes it harmless (null if it can't be)
  function neutralKey(p, comp, info) {
    const st = strayTime(info);
    if (st === null || !p.keys || !p.keys.length) return null;
    const times = keyTimes(p, comp, info);
    if (times.some((t) => Math.abs(t - st) < 0.001)) return null;
    let iMin = 0, iMax = 0;
    times.forEach((t, i) => { if (t < times[iMin]) iMin = i; if (t > times[iMax]) iMax = i; });
    if (st < times[iMin]) return { t: st, v: p.keys[iMin].v };
    if (st > times[iMax]) return { t: st, v: p.keys[iMax].v };
    return null;
  }
  function strayTime(info) {
    const rule = learned.strayRule || (learned.autoKey === true ? 'cti' : null);
    if (!rule) return null;
    const t = strayCandidates(info)[rule];
    return typeof t === 'number' && isFinite(t) ? t : null;
  }

  async function chainComponents(chain) {
    const count = chain.getComponentCount();
    const comps = [];
    for (let i = 0; i < count; i++) comps.push(chain.getComponentAtIndex(i));
    const names = await Promise.all(comps.map((c) => Promise.all([c.getMatchName().catch(() => ''), c.getDisplayName().catch(() => '')])));
    return comps.map((c, i) => ({ comp: c, matchName: names[i][0], displayName: names[i][1] }));
  }

  function paramsOf(component) {
    const out = [];
    const n = component.getParamCount();
    for (let i = 0; i < n; i++) out.push(component.getParam(i));
    return out;
  }

  // Did the settings land on the component that's now in the clip? (Checks one set value or key.)
  async function landed(component, pairs) {
    for (const [param, p] of pairs) {
      try {
        if (p.keys && p.keys.length) return (param.getKeyframeListAsTickTimes() || []).length >= p.keys.length;
        if (p.kind === 'bool' || p.kind === 'float' || p.kind === 'int') {
          const kf = await param.getStartValue();
          const v = kf && kf.value !== undefined ? (kf.value.value !== undefined ? kf.value.value : kf.value) : kf;
          if (typeof p.value === 'boolean') return !!v === p.value;
          if (typeof p.value === 'number') return closeTo(v, p.value);
        }
      } catch (e) { return null; }
    }
    return null; // nothing checkable
  }

  // ---------------------------------------------------------------- applyPreset
  async function applyPreset(args) {
    let last = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await applyPresetOnce(args, attempt);
      } catch (e) {
        if (!premiereError(e)) throw e;
        last = e;
        log('preset attempt', attempt + 1, 'failed:', e && e.message);
        // a learned shortcut may be what Premiere refused - drop it before trying again
        if (attempt === 0 && (learned.strayRule || learned.autoKey)) { learned.strayRule = null; learned.autoKey = null; remember(); }
        await sleep(150 * (attempt + 1));
      }
    }
    // the plugin couldn't do it (nothing was changed) - let the classic route apply it instead
    throw fail('USE_CLASSIC', 'Premiere plugin: ' + ((last && last.message) || 'failed'));
  }

  async function applyPresetOnce(args, attempt) {
    const t0 = now();
    const preset = args.preset;
    const { project, seq } = await context();
    const media = preset.media === 'mixed' ? 'any' : preset.media;
    const items = await selectedItems(seq, media);
    if (!items.length) throw fail('NO_SELECTION', 'Select ' + (media === 'audio' ? 'audio ' : media === 'video' ? 'video ' : '') + 'clips in the timeline first.');
    const stats = { keys: 0, values: 0, skipped: 0, failed: 0, missing: [], partial: false, steps: 0, ms: {} };
    let playhead = null;
    try { playhead = secOf(await seq.getPlayerPosition()); } catch (e) {}

    // 1. reads: clip timing, existing components, new effect components
    const plans = [];
    for (const item of items) {
      const video = isVideoItem(item);
      const m = video ? 'video' : 'audio';
      const comps = preset.components.filter((c) => c.media === m);
      if (!comps.length) continue;
      const [info, chain] = await Promise.all([clipInfo(item, args.timeBase, playhead), item.getComponentChain()]);
      const existing = await chainComponents(chain);
      const plan = { item, info, chain, parts: [] };
      for (const c of comps) {
        if (c.intrinsic) {
          const hit = existing.find((e) => e.matchName === c.matchName) || existing.find((e) => lower(e.displayName) === lower(c.displayName));
          if (!hit) { stats.missing.push(c.displayName); continue; }
          plan.parts.push({ c, component: hit.comp, fresh: false });
        } else {
          let component = null;
          try {
            component = video
              ? await ppro.VideoFilterFactory.createComponent(c.matchName)
              : await ppro.AudioFilterFactory.createComponentByDisplayName(c.displayName, item);
          } catch (e) { component = null; }
          if (!component && video) {
            try { component = await ppro.VideoFilterFactory.createComponent(c.displayName); } catch (e) {}
          }
          if (!component) { stats.missing.push(c.displayName); continue; }
          plan.parts.push({ c, component, fresh: true });
          if (c.hasPrivateData) stats.partial = true;
        }
      }
      if (plan.parts.length) plans.push(plan);
    }
    if (!plans.length) throw fail('PRESET_FAILED', stats.missing.length ? 'Missing effect: ' + stats.missing[0] : 'Nothing in this preset fits those clips.');
    stats.ms.read = now() - t0;

    // 2. one transaction: add the effects, set every setting, place every keyframe
    const t1 = now();
    const label = 'FX Drop: ' + (preset.name || 'preset');
    const oneStep = learned.oneStepKeys !== false && learned.appendThenSet !== false;
    const buildMain = (add) => {
      for (const k of ['keys', 'values', 'skipped', 'failed']) stats[k] = 0;
      delete stats.unmapped;
      for (const plan of plans) {
        for (const part of plan.parts) {
          if (part.fresh) add(plan.chain.createAppendComponentAction(part.component));
          part.pairs = mapParams(paramsOf(part.component), part.c.params, stats, part.c.displayName);
          if (oneStep) for (const [param, p] of part.pairs) paramActions(param, p, part.c, plan.info, stats, add);
        }
      }
    };
    const ok = commit(project, label, buildMain);
    stats.steps = 1;
    if (attempt) stats.attempts = attempt + 1;
    if (!ok) throw Object.assign(new Error('Premiere refused the change.'), { code: 'ERROR' });
    // the preset is in. Everything below only tidies up, and never turns this into a failure.
    try {
      await finishPreset(project, label, plans, oneStep, stats);
    } catch (e) {
      stats.tidyError = (e && e.message) || String(e);
      log('tidy-up after preset failed', stats.tidyError);
    }
    remember();
    stats.learned = Object.assign({}, learned);
    stats.ms.write = now() - t1;
    stats.ms.total = now() - t0;
    return { applied: plans.length, total: items.length, stats };
  }

  async function finishPreset(project, label, plans, oneStep, stats) {

    // 3. check it landed on the clips; if this Premiere build needs it, finish in a second step
    const fixups = [];
    for (const plan of plans) {
      const fresh = plan.parts.filter((p) => p.fresh);
      let now2 = null;
      if (fresh.length) {
        now2 = await chainComponents(plan.chain);
        // the appended components are the last ones in the chain, in order
        const tail = now2.slice(now2.length - fresh.length);
        fresh.forEach((p, i) => { p.inChain = tail[i] && tail[i].comp; });
      }
      for (const part of plan.parts) {
        const target = part.fresh ? part.inChain : part.component;
        if (!target) continue;
        const sameObject = target === part.component;
        let good = oneStep ? await landed(target, sameObject ? part.pairs : mapParams(paramsOf(target), part.c.params, {}, part.c.displayName)) : false;
        if (good === false) {
          fixups.push({ plan, part, target });
        } else if (good === true && part.fresh) {
          learned.appendThenSet = true; remember();
          if (part.pairs.some(([, p]) => p.keys && p.keys.length)) learned.oneStepKeys = true;
        }
      }
    }
    if (fixups.length) {
      log('preset needed a second step on this Premiere build', fixups.length);
      if (oneStep) learned.appendThenSet = false;
      const stats2 = { keys: 0, values: 0, skipped: 0, failed: 0 };
      commit(project, label, (add) => {
        for (const f of fixups) {
          f.pairs2 = mapParams(paramsOf(f.target), f.part.c.params, {}, f.part.c.displayName);
          for (const [param, p] of f.pairs2) paramActions(param, p, f.part.c, f.plan.info, stats2, add);
        }
      });
      stats.steps = 2;
      // keyframes that still didn't land: switch keyframing on first, then add keys
      const stillMissing = [];
      for (const f of fixups) {
        const keyed = f.pairs2.filter(([, p]) => p.keys && p.keys.length);
        for (const pair of keyed) if ((pair[0].getKeyframeListAsTickTimes() || []).length < pair[1].keys.length) stillMissing.push({ f, pair });
      }
      if (stillMissing.length) {
        learned.oneStepKeys = false;
        commit(project, label, (add) => { for (const s of stillMissing) add(s.pair[0].createSetTimeVaryingAction(true)); });
        commit(project, label, (add) => {
          for (const s of stillMissing) paramActions(s.pair[0], s.pair[1], s.f.part.c, s.f.plan.info, { keys: 0, values: 0, skipped: 0, failed: 0 }, add, { keysOnly: true });
        });
        stats.steps = 4;
      }
    }
    // 4. keys Premiere added on its own (at the playhead) - remove, and learn to do it in step one
    const strays = [];
    for (const plan of plans) {
      for (const part of plan.parts) {
        const target = part.fresh ? (part.inChain || part.component) : part.component;
        const pairs = (part.fresh && part.inChain && part.inChain !== part.component) ? mapParams(paramsOf(target), part.c.params, {}, part.c.displayName) : part.pairs;
        for (const [param, p] of pairs || []) {
          if (!p.keys || !p.keys.length) continue;
          const want = keyTimes(p, part.c, plan.info);
          const n = neutralKey(p, part.c, plan.info);
          if (n) want.push(n.t);
          let have = [];
          try { have = (param.getKeyframeListAsTickTimes() || []).map(secOf); } catch (e) { continue; }
          for (const t of have) {
            if (want.some((w) => Math.abs(w - t) < 0.001)) continue;
            // our own key, nudged onto a frame by Premiere - not a stray
            const near = want.find((w) => Math.abs(w - t) < 0.042);
            if (near !== undefined && !have.some((h) => Math.abs(h - near) < 0.001)) continue;
            const cand = strayCandidates(plan.info);
            strays.push({ param, t, rules: STRAY_RULES.filter((r) => typeof cand[r] === 'number' && Math.abs(cand[r] - t) < 0.002), info: plan.info });
          }
        }
      }
    }
    if (strays.length) {
      // learn where Premiere puts its own key, so next time it's removed in the same step
      const rule = STRAY_RULES.find((r) => strays.every((x) => x.rules.includes(r)));
      if (rule && learned.autoKey !== false) { learned.strayRule = rule; learned.autoKey = true; }
      commit(project, label, (add) => { for (const x of strays) add(x.param.createRemoveKeyframeAction(tick(x.t))); });
      stats.steps++;
      stats.strayKeys = strays.length;
      const i0 = strays[0].info;
      stats.strayAt = { t: +strays[0].t.toFixed(4), rule: rule || null, playhead: i0.playhead, start: i0.start, inPoint: i0.inPoint, base: i0.base, speed: i0.realSpeed };
    }
  }

  // ---------------------------------------------------------------- applyEffect (one effect by name)
  let effectNames = null;
  async function matchNameFor(displayName) {
    if (!effectNames) {
      const [d, m] = await Promise.all([ppro.VideoFilterFactory.getDisplayNames(), ppro.VideoFilterFactory.getMatchNames()]);
      effectNames = { d: d || [], m: m || [] };
    }
    const want = lower(displayName);
    if (effectNames.d.length === effectNames.m.length) {
      const i = effectNames.d.findIndex((x) => lower(x) === want);
      if (i >= 0) return effectNames.m[i];
    }
    return null;
  }

  async function applyEffect(args) {
    const { project, seq } = await context();
    const items = await selectedItems(seq, args.media);
    if (!items.length) throw fail('NO_SELECTION', 'Select ' + (args.media === 'audio' ? 'audio' : 'video') + ' clips in the timeline first.');
    const adds = [];
    for (const item of items) {
      let comp = null;
      try {
        if (args.media === 'audio') comp = await ppro.AudioFilterFactory.createComponentByDisplayName(args.name, item);
        else {
          const mn = await matchNameFor(args.name);
          if (mn) {
            comp = await ppro.VideoFilterFactory.createComponent(mn);
            // make sure the name lookup really gave the effect that was asked for
            const dn = comp ? await comp.getDisplayName().catch(() => null) : null;
            if (dn && lower(dn) !== lower(args.name)) comp = null;
          }
        }
      } catch (e) { comp = null; }
      if (!comp) throw fail('USE_CLASSIC', 'Effect lookup not available in the plugin');
      adds.push({ chain: await item.getComponentChain(), comp });
    }
    let ok = false;
    try { ok = commit(project, 'FX Drop: ' + args.name, (add) => { for (const a of adds) add(a.chain.createAppendComponentAction(a.comp)); }); } catch (e) { ok = false; }
    if (!ok) throw fail('USE_CLASSIC', 'Premiere plugin could not add the effect');
    return { applied: adds.length, total: items.length };
  }

  return { status, listEffects, applyPreset, applyEffect, _learned: learned, _mapParams: mapParams };
}

module.exports = { createOps, TPS };
