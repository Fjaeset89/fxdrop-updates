# FX Drop uninstaller - run via "Uninstall FX Drop.cmd"
$ErrorActionPreference = 'Continue'
Write-Host ''
Write-Host '  Removing FX Drop' -ForegroundColor White
Get-Process -Name 'FX Drop' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 600
$dest = Join-Path $env:LOCALAPPDATA 'Programs\FX Drop'
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
$cepDest = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.fxdrop'
if (Test-Path $cepDest) { Remove-Item $cepDest -Recurse -Force }
$lnk = Join-Path ([Environment]::GetFolderPath('Programs')) 'FX Drop.lnk'
if (Test-Path $lnk) { Remove-Item $lnk -Force }
$run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
foreach ($name in @('com.fxdrop.app', 'FX Drop', 'electron.app.FX Drop')) {
  Remove-ItemProperty -Path $run -Name $name -ErrorAction SilentlyContinue
}
$cache = Join-Path $env:LOCALAPPDATA 'FX Drop Setup'
if (Test-Path $cache) { Remove-Item $cache -Recurse -Force }
Write-Host '  Done. Your FX library and settings were left untouched.' -ForegroundColor Green
Write-Host '  (Settings live in %APPDATA%\FX Drop if you want to delete them too.)' -ForegroundColor DarkGray
Write-Host ''
Start-Sleep -Seconds 4
