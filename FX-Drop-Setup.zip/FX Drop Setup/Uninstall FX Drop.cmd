@echo off
title Removing FX Drop
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
